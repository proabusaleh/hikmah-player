# Phase 42 — Manual Device QA Checklist

Record device model, Android/iOS version, app build/version, date, tester, result, and reproduction steps for every failure.

## Playback and queue
- [ ] Start audio, pause/resume, seek, next/previous, and switch tracks rapidly.
- [ ] Finish a track naturally; exactly one next-track transition occurs.
- [ ] Repeat Off stops after the last queued track without an error banner.
- [ ] Repeat One repeats the current track; Repeat All wraps to the first queue item.
- [ ] Empty queue and removed-current-track states do not crash.
- [ ] Restore the app after force-close/relaunch and confirm documented resume behavior.

## Background and interruptions
- [ ] Start audio and lock the screen for at least 30 minutes.
- [ ] Verify notification/lock-screen play, pause, next, and previous controls.
- [ ] Receive a phone call or trigger another audio app; verify interruption recovery.
- [ ] Unplug wired/Bluetooth headphones during playback and reconnect.
- [ ] Verify audio focus behavior when navigation or another audio app requests focus.

## Permissions and network
- [ ] Import media with permission granted, denied, and later granted from Settings.
- [ ] Verify Android 13+ granular media permission behavior and Android 14+ selected-media behavior.
- [ ] Play downloaded/cached media in airplane mode.
- [ ] Handle a missing, moved, or unreadable media file without crashing.

## Release candidate
- [ ] Install the EAS preview build on a clean device.
- [ ] Verify icon, splash screen, RTL Arabic text, TalkBack traversal, and small-screen layout.
- [ ] Check logs for unhandled exceptions and repeated completion events.
- [ ] Attach test/coverage reports and record known issues before store submission.
