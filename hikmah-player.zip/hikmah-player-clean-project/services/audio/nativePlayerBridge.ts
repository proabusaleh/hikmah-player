import { Platform } from 'react-native';
import { requireNativeModule, EventSubscription } from 'expo-modules-core';

export type ForegroundPlaybackStatus = {
  active: boolean;
  loaded: boolean;
  playing: boolean;
  state: 'idle' | 'buffering' | 'playing' | 'paused' | 'stopped' | 'ended' | 'error' | string;
  positionMs: number;
  durationMs: number;
  uri?: string | null;
  title?: string;
  artist?: string;
};

export type NativePlayerStatus = {
  loaded: boolean;
  playing?: boolean;
  positionMs?: number;
  durationMs?: number;
  audioSessionId?: number;
  uri?: string | null;
};

type NativePlayerModule = {
  load(uri: string): Promise<NativePlayerStatus & { loaded: true; audioSessionId: number }>;
  play(): boolean;
  pause(): boolean;
  stop(): boolean;
  seekTo(positionMs: number): { positionMs: number; durationMs: number };
  getStatus(): NativePlayerStatus;
  getAudioSessionId(): number;
  release(): boolean;
  addListener(eventName: 'playbackStatus' | 'audioFocus' | 'mediaSessionAction', listener: (event: Record<string, unknown>) => void): EventSubscription;
  setMediaMetadata(title: string, artist: string, album: string): Promise<boolean>;
  setMediaSessionActive(active: boolean): boolean;
  updateMediaSessionState(state: string): boolean;
  abandonAudioFocus(): boolean;
  startForegroundPlayback(uri: string, title: string, artist: string): boolean;
  sendForegroundPlaybackCommand(action: string, positionMs: number): boolean;
  getForegroundPlaybackStatus(): ForegroundPlaybackStatus;
};

let cached: NativePlayerModule | null | undefined;
function nativeModule(): NativePlayerModule | null {
  if (Platform.OS !== 'android') return null;
  if (cached !== undefined) return cached;
  try { cached = requireNativeModule<NativePlayerModule>('HikmahNativePlayer'); }
  catch { cached = null; }
  return cached;
}

export function isNativePlayerAvailable(): boolean { return nativeModule() !== null; }

function requiredModule(): NativePlayerModule {
  const mod = nativeModule();
  if (!mod) throw new Error('HikmahNativePlayer is available only in an Android development/release build containing the local native module.');
  return mod;
}

export async function loadNativePlayer(uri: string) {
  if (!uri.trim()) throw new Error('A media URI is required.');
  const result = await requiredModule().load(uri);
  if (!Number.isInteger(result.audioSessionId) || result.audioSessionId <= 0) {
    throw new Error('Native player loaded but did not provide a valid audio session ID.');
  }
  return result;
}
export function playNativePlayer() { return requiredModule().play(); }
export function pauseNativePlayer() { return requiredModule().pause(); }
export function stopNativePlayer() { return requiredModule().stop(); }
export function seekNativePlayer(positionMs: number) {
  if (!Number.isFinite(positionMs) || positionMs < 0) throw new Error('Seek position must be a non-negative number.');
  return requiredModule().seekTo(Math.floor(positionMs));
}
export function getNativePlayerStatus() { return requiredModule().getStatus(); }
export function getNativePlayerAudioSessionId() {
  const id = requiredModule().getAudioSessionId();
  return Number.isInteger(id) && id > 0 ? id : null;
}
export function subscribeNativePlayerStatus(listener: (event: Record<string, unknown>) => void) {
  return requiredModule().addListener('playbackStatus', listener);
}
export function subscribeNativeAudioFocus(listener: (event: Record<string, unknown>) => void) {
  return requiredModule().addListener('audioFocus', listener);
}
export function abandonNativeAudioFocus() { return nativeModule()?.abandonAudioFocus() ?? false; }
export function releaseNativePlayer() { return nativeModule()?.release() ?? false; }

/** Updates the Android system media metadata. Available only in a native Android build. */
export function setNativeMediaMetadata(title: string, artist = 'Unknown artist', album = '') {
  return requiredModule().setMediaMetadata(title, artist, album);
}
export function setNativeMediaSessionActive(active: boolean) {
  return requiredModule().setMediaSessionActive(active);
}
export function updateNativeMediaSessionState(state: 'playing' | 'paused' | 'buffering' | 'stopped' | 'ended') {
  return requiredModule().updateMediaSessionState(state);
}
export function subscribeNativeMediaSessionActions(listener: (event: Record<string, unknown>) => void) {
  return requiredModule().addListener('mediaSessionAction', listener);
}

/** Starts the opt-in Android foreground-service player. This is a separate native player instance, not the expo-audio instance. */
export function startNativeForegroundPlayback(uri: string, title = 'Hikmah Player', artist = 'Unknown artist') {
  if (!uri.trim()) throw new Error('A media URI is required.');
  return requiredModule().startForegroundPlayback(uri, title, artist);
}

/** Sends play, pause, seek, or stop to the opt-in foreground-service player. */
export function sendNativeForegroundPlaybackCommand(action: 'play' | 'pause' | 'seek' | 'stop' | 'next' | 'previous', positionMs = 0) {
  if (!Number.isFinite(positionMs) || positionMs < 0) throw new Error('Position must be a non-negative number.');
  return requiredModule().sendForegroundPlaybackCommand(action, Math.floor(positionMs));
}


/** Reads status from the Android foreground-service player (not the expo-audio player). */
export function getNativeForegroundPlaybackStatus(): ForegroundPlaybackStatus {
  return requiredModule().getForegroundPlaybackStatus();
}
