import { Platform } from 'react-native';
import type { MediaItem } from '@/types/media';
import {
  sendNativeForegroundPlaybackCommand,
  startNativeForegroundPlayback,
  getNativeForegroundPlaybackStatus,
  subscribeNativeMediaSessionActions,
  type ForegroundPlaybackStatus,
} from './nativePlayerBridge';
import { playbackDiagnostics } from '@/services/playback/playbackDiagnostics';

/**
 * Opt-in adapter for the Android foreground-service playback engine.
 * Do not use it simultaneously with audioService/expo-audio for the same track.
 * The adapter deliberately does not silently switch engines: callers must opt in.
 */
export class ForegroundPlaybackAdapter {
  private active = false;
  private currentItem: MediaItem | null = null;
  private statusTimer: ReturnType<typeof setInterval> | null = null;
  private statusListeners = new Set<(status: ForegroundPlaybackStatus) => void>();
  private queue: MediaItem[] = [];
  private queueIndex = -1;
  private actionSubscription: { remove: () => void } | null = null;

  get isActive() { return this.active; }
  get currentTrack() { return this.currentItem; }
  get queuedItems() { return [...this.queue]; }
  get currentQueueIndex() { return this.queueIndex; }

  /** Set the queue owned by the foreground-service playback engine. This does not mutate the app's expo-audio queue. */
  setQueue(items: MediaItem[], startIndex = 0) {
    if (!Array.isArray(items)) throw new Error('Queue must be an array of media items.');
    if (items.some((item) => !item?.url?.trim())) throw new Error('Every queued item must have a playable URL.');
    if (items.some((item) => item.type !== 'audio')) throw new Error('Foreground service queue supports audio items only.');
    if (!Number.isFinite(startIndex)) throw new Error('Queue start index must be a finite number.');
    this.queue = [...items];
    this.queueIndex = this.queue.length ? Math.max(0, Math.min(this.queue.length - 1, Math.floor(startIndex))) : -1;
  }

  getStatus(): ForegroundPlaybackStatus {
    return getNativeForegroundPlaybackStatus();
  }

  subscribeStatus(listener: (status: ForegroundPlaybackStatus) => void, intervalMs = 500): () => void {
    const syncedListener = (status: ForegroundPlaybackStatus) => {
      this.active = status.active;
      if (!status.active) this.currentItem = null;
      listener(status);
    };
    this.statusListeners.add(syncedListener);
    try { syncedListener(this.getStatus()); } catch { /* Native module may not be present in Expo Go. */ }
    if (this.statusTimer === null) {
      const safeInterval = Math.max(250, Math.min(2000, Math.floor(intervalMs)));
      this.statusTimer = setInterval(() => {
        let status: ForegroundPlaybackStatus;
        try { status = this.getStatus(); } catch { return; }
        for (const subscriber of this.statusListeners) {
          try { subscriber(status); } catch { /* One UI subscriber must not break others. */ }
        }
        if (!status.active && this.statusListeners.size === 0) this.clearStatusTimer();
      }, safeInterval);
    }
    return () => {
      this.statusListeners.delete(syncedListener);
      if (this.statusListeners.size === 0) this.clearStatusTimer();
    };
  }

  private clearStatusTimer() {
    if (this.statusTimer !== null) clearInterval(this.statusTimer);
    this.statusTimer = null;
  }

  async start(item: MediaItem): Promise<void> {
    if (Platform.OS !== 'android') throw new Error('Foreground service playback is Android-only.');
    if (!item.url?.trim()) throw new Error('The selected track has no playable URL.');
    if (item.type !== 'audio') throw new Error('Foreground service playback supports audio items only.');
    playbackDiagnostics.record('foreground.start.request', { engine: 'foreground-service', details: { mediaType: item.type } });
    const accepted = startNativeForegroundPlayback(item.url, item.title || 'Hikmah Player', item.artistOrSpeaker || 'Unknown artist');
    if (!accepted) {
      playbackDiagnostics.record('foreground.start.rejected', { level: 'error', engine: 'foreground-service' });
      throw new Error('Android foreground service could not be started. Rebuild the native app and try while the app is visible.');
    }
    playbackDiagnostics.record('foreground.start.accepted', { engine: 'foreground-service' });
    this.currentItem = item;
    this.active = true;
    const index = this.queue.findIndex((queued) => queued.id === item.id);
    if (index >= 0) this.queueIndex = index;
    this.ensureActionSubscription();
  }

  /** Starts the selected item in the foreground service and updates its queue index. */
  async playTrackAt(index: number): Promise<void> {
    if (!Number.isInteger(index) || index < 0 || index >= this.queue.length) throw new Error('Queue index is out of range.');
    this.queueIndex = index;
    await this.start(this.queue[index]);
  }

  async next(): Promise<void> {
    if (this.queueIndex < 0 || this.queueIndex + 1 >= this.queue.length) { this.stop(); return; }
    await this.playTrackAt(this.queueIndex + 1);
  }

  async previous(): Promise<void> {
    if (this.queueIndex <= 0) {
      if (this.queue.length && this.queueIndex === 0) await this.playTrackAt(0);
      return;
    }
    await this.playTrackAt(this.queueIndex - 1);
  }

  play() { this.assertActive(); playbackDiagnostics.record('foreground.command.play', { engine: 'foreground-service' }); return sendNativeForegroundPlaybackCommand('play'); }
  pause() { this.assertActive(); playbackDiagnostics.record('foreground.command.pause', { engine: 'foreground-service' }); return sendNativeForegroundPlaybackCommand('pause'); }
  seekTo(positionMs: number) { this.assertActive(); playbackDiagnostics.record('foreground.command.seek', { engine: 'foreground-service', details: { positionMs: Number.isFinite(positionMs) ? Math.max(0, positionMs) : 0 } }); return sendNativeForegroundPlaybackCommand('seek', positionMs); }
  stop() {
    if (!this.active) return false;
    const result = sendNativeForegroundPlaybackCommand('stop');
    this.active = false;
    this.currentItem = null;
    this.queueIndex = -1;
    playbackDiagnostics.record('foreground.command.stop', { engine: 'foreground-service' });
    return result;
  }


  dispose() {
    this.clearStatusTimer();
    this.statusListeners.clear();
    this.actionSubscription?.remove();
    this.actionSubscription = null;
  }

  private ensureActionSubscription() {
    if (this.actionSubscription) return;
    try {
      this.actionSubscription = subscribeNativeMediaSessionActions((event) => {
        // Only consume commands emitted by the foreground-service MediaSession/notification.
        if (event.source !== 'foreground_service') return;
        const action = String(event.action || '');
        if (action === 'next') void this.runActionSafely(() => this.next());
        else if (action === 'previous') void this.runActionSafely(() => this.previous());
        else if (action === 'play' && this.active) this.play();
        else if (action === 'pause' && this.active) this.pause();
        else if (action === 'seek' && this.active) this.seekTo(Number(event.positionMs || 0));
        else if (action === 'stop') {
          this.active = false;
          this.currentItem = null;
          this.queueIndex = -1;
        }
      });
    } catch { /* Native module is absent in Expo Go or an unsupported build. */ }
  }

  /** Prevent async notification actions from creating unhandled promise rejections. */
  private async runActionSafely(action: () => Promise<void>) {
    try { await action(); } catch {
      // The next status poll will surface the native player's actual state.
    }
  }

  private assertActive() {
    if (!this.active) throw new Error('Foreground playback has not been started for a track.');
  }
}

export const foregroundPlaybackAdapter = new ForegroundPlaybackAdapter();
