import type { EqualizerPreset } from '@/store/useSettingsStore';

export const EQUALIZER_PRESETS: readonly EqualizerPreset[] = [
  'flat',
  'bass',
  'vocal',
  'treble',
  'classical',
  'rock',
] as const;

export interface EqualizerPreferences {
  preset: EqualizerPreset;
  bassBoostEnabled: boolean;
  bassBoostLevel: number;
}

export function normalizeBassBoostLevel(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}

export function isEqualizerPreset(value: unknown): value is EqualizerPreset {
  return typeof value === 'string' && EQUALIZER_PRESETS.includes(value as EqualizerPreset);
}

/**
 * expo-audio does not expose a parametric equalizer or bass-boost DSP API.
 * This module validates persisted preferences only; it intentionally does not
 * pretend to apply audio effects. Integrate a native DSP implementation before
 * presenting these preferences as active sound processing.
 */
export function normalizeEqualizerPreferences(
  input: Partial<EqualizerPreferences>,
): EqualizerPreferences {
  return {
    preset: isEqualizerPreset(input.preset) ? input.preset : 'flat',
    bassBoostEnabled: input.bassBoostEnabled === true,
    bassBoostLevel: normalizeBassBoostLevel(input.bassBoostLevel ?? 35),
  };
}
