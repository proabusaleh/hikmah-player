import {
  loadNativePlayer,
  playNativePlayer,
  pauseNativePlayer,
  stopNativePlayer,
  seekNativePlayer,
  getNativePlayerStatus,
  releaseNativePlayer,
  type NativePlayerStatus,
} from './nativePlayerBridge';
import { releaseNativeAudioEffects } from './nativeAudioEffects';

export type NativeSessionState = 'idle' | 'loading' | 'ready' | 'playing' | 'paused' | 'stopped' | 'error';
export type NativeSessionSnapshot = {
  state: NativeSessionState;
  uri: string | null;
  audioSessionId: number | null;
  durationMs: number;
  positionMs: number;
  error: string | null;
};

const initialSnapshot = (): NativeSessionSnapshot => ({
  state: 'idle', uri: null, audioSessionId: null, durationMs: 0, positionMs: 0, error: null,
});

/** Lifecycle-safe opt-in facade for the Android native player. It does not replace expo-audio. */
export class NativePlaybackSession {
  private snapshot: NativeSessionSnapshot = initialSnapshot();
  private operation: Promise<unknown> = Promise.resolve();
  private disposed = false;

  getSnapshot(): NativeSessionSnapshot { return { ...this.snapshot }; }

  private serialize<T>(work: () => Promise<T> | T): Promise<T> {
    const next = this.operation.then(work, work);
    this.operation = next.then(() => undefined, () => undefined);
    return next;
  }

  load(uri: string): Promise<NativeSessionSnapshot> {
    return this.serialize(async () => {
      if (this.disposed) throw new Error('Native playback session has been disposed. Create a new session to load media.');
      if (!uri.trim()) throw new Error('A non-empty media URI is required.');
      this.snapshot = { ...initialSnapshot(), state: 'loading', uri: uri.trim() };
      try {
        // Detach effects before the old player's audio session is released.
        releaseNativeAudioEffects();
        releaseNativePlayer();
        const loaded = await loadNativePlayer(uri.trim());
        this.snapshot = {
          state: 'ready', uri: uri.trim(), audioSessionId: loaded.audioSessionId,
          durationMs: Math.max(0, loaded.durationMs ?? 0), positionMs: 0, error: null,
        };
      } catch (error) {
        this.snapshot = { ...initialSnapshot(), state: 'error', error: error instanceof Error ? error.message : 'Could not load media.' };
        throw error;
      }
      return this.getSnapshot();
    });
  }

  play(): Promise<NativeSessionSnapshot> {
    return this.serialize(() => {
      this.ensureLoaded(); playNativePlayer(); this.refreshFromStatus('playing'); return this.getSnapshot();
    });
  }

  pause(): Promise<NativeSessionSnapshot> {
    return this.serialize(() => {
      this.ensureLoaded(); pauseNativePlayer(); this.refreshFromStatus('paused'); return this.getSnapshot();
    });
  }

  stop(): Promise<NativeSessionSnapshot> {
    return this.serialize(() => {
      this.ensureLoaded(); stopNativePlayer(); this.refreshFromStatus('stopped'); return this.getSnapshot();
    });
  }

  seek(positionMs: number): Promise<NativeSessionSnapshot> {
    return this.serialize(() => {
      this.ensureLoaded();
      if (!Number.isFinite(positionMs) || positionMs < 0) throw new Error('Seek position must be a non-negative number.');
      const result = seekNativePlayer(Math.floor(positionMs));
      this.snapshot = { ...this.snapshot, positionMs: Math.max(0, result.positionMs), durationMs: Math.max(0, result.durationMs) };
      return this.getSnapshot();
    });
  }

  refresh(): Promise<NativeSessionSnapshot> {
    return this.serialize(() => { this.ensureLoaded(); this.refreshFromStatus(); return this.getSnapshot(); });
  }

  dispose(): Promise<void> {
    return this.serialize(() => {
      if (this.disposed) return;
      this.disposed = true;
      // Effects must be released before their player session disappears.
      releaseNativeAudioEffects();
      releaseNativePlayer();
      this.snapshot = initialSnapshot();
    });
  }

  private ensureLoaded() {
    if (this.disposed) throw new Error('Native playback session has been disposed.');
    if (!this.snapshot.audioSessionId || !this.snapshot.uri) throw new Error('No media is loaded. Call load(uri) first.');
  }

  private refreshFromStatus(forcedState?: NativeSessionState) {
    const status: NativePlayerStatus = getNativePlayerStatus();
    this.snapshot = {
      ...this.snapshot,
      state: forcedState ?? (status.playing ? 'playing' : this.snapshot.state === 'playing' ? 'paused' : this.snapshot.state),
      positionMs: Math.max(0, status.positionMs ?? this.snapshot.positionMs),
      durationMs: Math.max(0, status.durationMs ?? this.snapshot.durationMs),
      audioSessionId: status.audioSessionId && status.audioSessionId > 0 ? status.audioSessionId : this.snapshot.audioSessionId,
    };
  }
}

export function createNativePlaybackSession() { return new NativePlaybackSession(); }
