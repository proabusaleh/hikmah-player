import { applyNativeAudioEffects, getEqualizerPresetLevels, releaseNativeAudioEffects, type NativeAudioEffectResult } from './nativeAudioEffects';
import { loadNativePlayer, releaseNativePlayer } from './nativePlayerBridge';

export type NativePlaybackEffectsConfig = {
  equalizerPreset: string;
  equalizerEnabled: boolean;
  bassBoostEnabled: boolean;
  bassBoostLevel: number;
};

export type NativePlaybackLoadResult = {
  loaded: true;
  durationMs: number;
  audioSessionId: number;
  effects: NativeAudioEffectResult | null;
  effectsError: string | null;
};

/**
 * Phase 13 opt-in coordinator. It uses the Phase 12 native MediaPlayer only;
 * it does not replace the app's existing expo-audio engine automatically.
 */
export async function loadNativePlaybackWithEffects(
  uri: string,
  config: NativePlaybackEffectsConfig,
): Promise<NativePlaybackLoadResult> {
  const loaded = await loadNativePlayer(uri);
  let effects: NativeAudioEffectResult | null = null;
  let effectsError: string | null = null;

  try {
    effects = await applyNativeAudioEffects({
      audioSessionId: loaded.audioSessionId,
      presetLevels: config.equalizerEnabled
        ? getEqualizerPresetLevels(config.equalizerPreset)
        : [],
      bassBoostEnabled: config.bassBoostEnabled,
      bassBoostLevel: config.bassBoostLevel,
    });
  } catch (error) {
    effectsError = error instanceof Error ? error.message : 'Native audio effects could not be applied.';
  }

  return {
    loaded: true,
    durationMs: loaded.durationMs,
    audioSessionId: loaded.audioSessionId,
    effects,
    effectsError,
  };
}

/** Release effect handles before releasing the player session they were attached to. */
export function releaseNativePlaybackWithEffects(): { effectsReleased: boolean; playerReleased: boolean } {
  const effectsReleased = releaseNativeAudioEffects();
  const playerReleased = releaseNativePlayer();
  return { effectsReleased, playerReleased };
}
