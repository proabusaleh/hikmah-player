import type { NativeAudioEffectCapabilities } from './nativeAudioEffects';

export type AudioEffectsIntegrationState =
  | 'unsupported-platform'
  | 'native-module-missing'
  | 'session-id-required'
  | 'ready-to-apply';

export type AudioEffectsDiagnostics = {
  state: AudioEffectsIntegrationState;
  canApplyEffects: boolean;
  title: string;
  detail: string;
};

/** Keep module availability separate from actual playback-session readiness. */
export function getAudioEffectsDiagnostics(
  capabilities: NativeAudioEffectCapabilities | null,
  audioSessionId: number | null | undefined,
  platform: string,
): AudioEffectsDiagnostics {
  if (platform !== 'android') {
    return { state: 'unsupported-platform', canApplyEffects: false, title: 'Android only', detail: 'Native equalizer effects are currently implemented for Android only.' };
  }
  if (!capabilities?.supported || (!capabilities.equalizer && !capabilities.bassBoost)) {
    return { state: 'native-module-missing', canApplyEffects: false, title: 'Module unavailable', detail: 'Install a custom Android build that includes the HikmahAudioEffects module.' };
  }
  if (!Number.isInteger(audioSessionId) || (audioSessionId ?? 0) <= 0) {
    return { state: 'session-id-required', canApplyEffects: false, title: 'Playback integration needed', detail: 'The current playback engine has not supplied a valid Android audio session ID. Effects are not active.' };
  }
  return { state: 'ready-to-apply', canApplyEffects: true, title: 'Session available', detail: 'A valid audio session ID is available; native effects can be applied.' };
}
