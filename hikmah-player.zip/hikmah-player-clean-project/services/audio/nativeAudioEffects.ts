import { Platform } from 'react-native';
import { requireNativeModule } from 'expo-modules-core';

export type NativeAudioEffectCapabilities = {
  platform: string;
  supported: boolean;
  equalizer: boolean;
  bassBoost: boolean;
  requiresAudioSessionId: boolean;
};

export type NativeAudioEffectResult = {
  applied: boolean;
  sessionId: number;
  equalizerEnabled: boolean;
  bassBoostEnabled: boolean;
  bandsApplied: number;
};

export type NativeAudioEffectsModule = {
  getCapabilities(): NativeAudioEffectCapabilities;
  applyEffects(
    sessionId: number,
    presetLevels: number[],
    bassEnabled: boolean,
    bassLevel: number,
  ): Promise<NativeAudioEffectResult>;
  release(): boolean;
};

let moduleInstance: NativeAudioEffectsModule | null | undefined;

function getModule(): NativeAudioEffectsModule | null {
  if (Platform.OS !== 'android') return null;
  if (moduleInstance !== undefined) return moduleInstance;
  try {
    moduleInstance = requireNativeModule<NativeAudioEffectsModule>('HikmahAudioEffects');
  } catch {
    // Expo Go and old native builds won't contain the custom module.
    moduleInstance = null;
  }
  return moduleInstance;
}

export function getNativeAudioEffectCapabilities(): NativeAudioEffectCapabilities {
  const native = getModule();
  if (!native) {
    return {
      platform: Platform.OS,
      supported: false,
      equalizer: false,
      bassBoost: false,
      requiresAudioSessionId: true,
    };
  }
  try {
    return native.getCapabilities();
  } catch {
    return {
      platform: Platform.OS,
      supported: false,
      equalizer: false,
      bassBoost: false,
      requiresAudioSessionId: true,
    };
  }
}

/** Applies real Android effects only when the playback engine supplies its real audio session ID. */
export async function applyNativeAudioEffects(args: {
  audioSessionId: number | null | undefined;
  presetLevels: number[];
  bassBoostEnabled: boolean;
  bassBoostLevel: number;
}): Promise<NativeAudioEffectResult> {
  const native = getModule();
  if (!native) throw new Error('Native audio effects are unavailable in this build. Install a development/release build containing the HikmahAudioEffects module.');
  if (!Number.isInteger(args.audioSessionId) || (args.audioSessionId ?? 0) <= 0) {
    throw new Error('The playback engine has not provided a valid audio session ID. Effects were not applied.');
  }
  if (args.presetLevels.some((level) => !Number.isFinite(level) || level < -1 || level > 1)) {
    throw new Error('Equalizer band values must be finite numbers between -1 and 1.');
  }
  const bassLevel = Math.max(0, Math.min(100, Math.round(args.bassBoostLevel)));
  return native.applyEffects(
    args.audioSessionId as number,
    args.presetLevels,
    args.bassBoostEnabled,
    bassLevel,
  );
}

export function releaseNativeAudioEffects(): boolean {
  const native = getModule();
  if (!native) return false;
  try {
    return native.release();
  } catch {
    return false;
  }
}

/** Normalized five-band presets expected by the Android Equalizer bridge. */
export const EQUALIZER_PRESET_LEVELS: Record<string, number[]> = {
  flat: [0, 0, 0, 0, 0],
  bass: [0.85, 0.65, 0.25, 0, -0.1],
  vocal: [-0.25, 0.05, 0.55, 0.45, 0.1],
  treble: [-0.15, -0.05, 0.15, 0.55, 0.8],
  classical: [0.2, 0.1, -0.05, 0.2, 0.45],
  rock: [0.65, 0.35, -0.1, 0.35, 0.65],
};

export function getEqualizerPresetLevels(preset: string): number[] {
  const levels = EQUALIZER_PRESET_LEVELS[preset];
  return levels ? [...levels] : [...EQUALIZER_PRESET_LEVELS.flat];
}
