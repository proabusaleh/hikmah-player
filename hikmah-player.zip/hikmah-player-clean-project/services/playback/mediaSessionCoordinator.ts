import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import {
  getNativePlayerStatus,
  pauseNativePlayer,
  playNativePlayer,
  seekNativePlayer,
  stopNativePlayer,
  subscribeNativePlayerStatus,
} from '@/services/audio/nativePlayerBridge';

type MediaAction = 'play' | 'pause' | 'stop' | 'seek-forward' | 'seek-back';

/**
 * Coordinates notification action intents with the opt-in Android native player.
 * This is not an Android MediaSession/foreground-service implementation; Expo local
 * notification actions are best-effort and are not equivalent to lock-screen controls.
 */
export const MediaSessionCoordinator = {
  async handleAction(action: MediaAction): Promise<boolean> {
    if (Platform.OS !== 'android') return false;
    try {
      switch (action) {
        case 'play': playNativePlayer(); return true;
        case 'pause': pauseNativePlayer(); return true;
        case 'stop': stopNativePlayer(); return true;
        case 'seek-forward': {
          const status = getNativePlayerStatus();
          if (!status.loaded) return false;
          seekNativePlayer(Math.min((status.positionMs ?? 0) + 15_000, status.durationMs ?? Number.MAX_SAFE_INTEGER));
          return true;
        }
        case 'seek-back': {
          const status = getNativePlayerStatus();
          if (!status.loaded) return false;
          seekNativePlayer(Math.max(0, (status.positionMs ?? 0) - 15_000));
          return true;
        }
      }
    } catch (error) {
      console.warn('[MediaSessionCoordinator] Action unavailable:', error);
      return false;
    }
  },

  /** Subscribe to native status changes; caller must call remove() on unmount. */
  subscribe(listener: (event: Record<string, unknown>) => void) {
    return subscribeNativePlayerStatus(listener);
  },

  /** Acknowledge an Expo notification response for a future action-category hookup. */
  async consumeNotificationResponse(response: Notifications.NotificationResponse): Promise<boolean> {
    const action = response.actionIdentifier;
    if (action === 'play' || action === 'pause' || action === 'stop' || action === 'seek-forward' || action === 'seek-back') {
      return this.handleAction(action);
    }
    return false;
  },
};
