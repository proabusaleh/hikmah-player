/** Small in-memory playback event recorder for QA and support diagnostics.
 * It deliberately excludes media URLs, titles, artist names, and other user content.
 */
export type PlaybackDiagnosticLevel = 'info' | 'warning' | 'error';
export type PlaybackDiagnosticEvent = {
  id: number;
  at: number;
  level: PlaybackDiagnosticLevel;
  event: string;
  engine?: string;
  details?: Record<string, string | number | boolean | null>;
};

const DEFAULT_CAPACITY = 100;
const SAFE_KEY = /^[a-zA-Z][a-zA-Z0-9_]{0,39}$/;
const SECRET_KEY = /(url|uri|title|artist|speaker|token|password|authorization|cookie|path|filename|message|stack)/i;

function sanitizeDetails(input?: Record<string, unknown>) {
  if (!input) return undefined;
  const output: Record<string, string | number | boolean | null> = {};
  for (const [key, value] of Object.entries(input)) {
    if (!SAFE_KEY.test(key) || SECRET_KEY.test(key)) continue;
    if (value === null || typeof value === 'boolean') output[key] = value;
    else if (typeof value === 'number' && Number.isFinite(value)) output[key] = value;
    else if (typeof value === 'string') output[key] = value.slice(0, 80);
  }
  return Object.keys(output).length ? output : undefined;
}

export class PlaybackDiagnostics {
  private events: PlaybackDiagnosticEvent[] = [];
  private nextId = 1;
  private readonly capacity: number;
  constructor(capacity = DEFAULT_CAPACITY, private readonly clock: () => number = Date.now) {
    this.capacity = Number.isFinite(capacity) ? Math.max(1, Math.min(1000, Math.floor(capacity))) : DEFAULT_CAPACITY;
  }
  record(event: string, options: { level?: PlaybackDiagnosticLevel; engine?: string; details?: Record<string, unknown> } = {}) {
    const cleanEvent = String(event || 'unknown').replace(/[^a-zA-Z0-9_.:-]/g, '').slice(0, 80) || 'unknown';
    const cleanEngine = options.engine?.replace(/[^a-zA-Z0-9_.:-]/g, '').slice(0, 40);
    const entry: PlaybackDiagnosticEvent = {
      id: this.nextId++, at: this.safeNow(), level: options.level ?? 'info', event: cleanEvent,
      ...(cleanEngine ? { engine: cleanEngine } : {}),
      ...(sanitizeDetails(options.details) ? { details: sanitizeDetails(options.details) } : {}),
    };
    this.events.push(entry);
    if (this.events.length > this.capacity) this.events.splice(0, this.events.length - this.capacity);
    return { ...entry, ...(entry.details ? { details: { ...entry.details } } : {}) };
  }
  snapshot() { return this.events.map((entry) => ({ ...entry, ...(entry.details ? { details: { ...entry.details } } : {}) })); }
  clear() { this.events = []; }
  summary() {
    const result = { total: this.events.length, errors: 0, warnings: 0, latestEvent: null as string | null };
    for (const entry of this.events) {
      if (entry.level === 'error') result.errors++;
      if (entry.level === 'warning') result.warnings++;
    }
    result.latestEvent = this.events[this.events.length - 1]?.event ?? null;
    return result;
  }
  private safeNow() { const value = this.clock(); return Number.isFinite(value) ? value : 0; }
}

export const playbackDiagnostics = new PlaybackDiagnostics();
