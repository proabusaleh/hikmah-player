/** Prevent duplicate native end-of-track notifications from advancing twice. */
export class TrackCompletionGuard {
  private completedTrackId: string | null = null;

  /** Returns true once for each non-empty track id until reset or another id arrives. */
  shouldHandle(trackId: string | null | undefined): boolean {
    if (!trackId) return false;
    if (this.completedTrackId === trackId) return false;
    this.completedTrackId = trackId;
    return true;
  }

  reset(): void {
    this.completedTrackId = null;
  }
}
