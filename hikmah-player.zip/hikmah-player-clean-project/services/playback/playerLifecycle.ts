import { Image } from 'expo-image';
import {
  AppState,
  Dimensions,
  NativeEventEmitter,
  NativeModules,
  Platform,
  type AppStateStatus,
} from 'react-native';

import { audioService } from '@/services/audio/audioService';
import { subscribeNativeAudioFocus, subscribeNativePlayerStatus } from '@/services/audio/nativePlayerBridge';
import { playbackDiagnostics } from '@/services/playback/playbackDiagnostics';
import { useContinueWatchingStore } from '@/store/useContinueWatchingStore';
import { usePlayerStore } from '@/store/usePlayerStore';

// ─── Player Lifecycle Manager ────────────────────────
class PlayerLifecycleManager {
  private appStateSubscription: ReturnType<typeof AppState.addEventListener> | null = null;
  private memoryWarningSubscription: { remove: () => void } | null = null;
  private dimensionSubscription: ReturnType<typeof Dimensions.addEventListener> | null = null;
  private isInBackground = false;
  private wasPlayingBeforeBackground = false;
  private orientationChangeTimeout: ReturnType<typeof setTimeout> | null = null;
  private nativeFocusSubscription: { remove: () => void } | null = null;
  private nativeStatusSubscription: { remove: () => void } | null = null;

  /**
   * Initialize all lifecycle listeners
   */
  initialize(): void {
    this.setupAppStateListener();
    this.setupMemoryWarningListener();
    this.setupOrientationListener();
    this.setupNativeAudioInterruptionListeners();
    if (__DEV__) {
      console.log('[PlayerLifecycle] Initialized');
    }
  }

  /**
   * Clean up all listeners
   */
  destroy(): void {
    if (this.appStateSubscription) {
      this.appStateSubscription.remove();
      this.appStateSubscription = null;
    }
    if (this.memoryWarningSubscription) {
      this.memoryWarningSubscription.remove();
      this.memoryWarningSubscription = null;
    }
    if (this.dimensionSubscription) {
      this.dimensionSubscription.remove();
      this.dimensionSubscription = null;
    }
    this.nativeFocusSubscription?.remove();
    this.nativeFocusSubscription = null;
    this.nativeStatusSubscription?.remove();
    this.nativeStatusSubscription = null;
    if (this.orientationChangeTimeout) {
      clearTimeout(this.orientationChangeTimeout);
      this.orientationChangeTimeout = null;
    }
    if (__DEV__) {
      console.log('[PlayerLifecycle] Destroyed');
    }
  }

  // ── Android audio focus / noisy-route synchronization ──
  private setupNativeAudioInterruptionListeners(): void {
    if (Platform.OS !== 'android') return;
    try {
      this.nativeFocusSubscription = subscribeNativeAudioFocus((event) => {
        const state = typeof event.state === 'string' ? event.state : 'unknown';
        playbackDiagnostics.record('audio_focus.changed', {
          level: state === 'lost' || state === 'request_denied' ? 'warning' : 'info',
          engine: 'foreground-service',
          details: { focusState: state },
        });
        // The native Android player handles focus requests and transient auto-resume.
        // Keep the JS store observational; never issue a second play/pause command here.
      });
      this.nativeStatusSubscription = subscribeNativePlayerStatus((event) => {
        const { playbackEngine, currentTrack, status } = usePlayerStore.getState();
        if (playbackEngine !== 'foreground-service' || !currentTrack) return;
        const state = typeof event.state === 'string' ? event.state : '';
        const reason = typeof event.reason === 'string' ? event.reason : '';
        if (reason === 'headphones_disconnected') {
          usePlayerStore.getState().updateStatus('paused');
          playbackDiagnostics.record('audio_route.disconnected', {
            level: 'warning', engine: 'foreground-service', details: { statusBefore: status },
          });
          return;
        }
        if (reason === 'audio_focus_transient_loss' || reason === 'audio_focus_loss') {
          usePlayerStore.getState().updateStatus('paused');
          playbackDiagnostics.record('audio_focus.playback_paused', {
            level: 'warning', engine: 'foreground-service', details: { transient: reason === 'audio_focus_transient_loss' },
          });
          return;
        }
        if (state === 'playing' || state === 'paused' || state === 'buffering' || state === 'stopped' || state === 'error') {
          usePlayerStore.getState().updateStatus(state);
        }
      });
    } catch (error) {
      playbackDiagnostics.record('audio_focus.listeners_unavailable', {
        level: 'warning', engine: 'foreground-service',
        details: { platform: Platform.OS, errorType: error instanceof Error ? error.name : 'unknown' },
      });
    }
  }

  // ── App State (Background/Foreground) ──
  private setupAppStateListener(): void {
    this.appStateSubscription = AppState.addEventListener('change', this.handleAppStateChange);
  }

  private handleAppStateChange = async (nextState: AppStateStatus): Promise<void> => {
    const { status, currentTrack } = usePlayerStore.getState();

    switch (nextState) {
      case 'background':
      case 'inactive':
        this.isInBackground = true;
        this.wasPlayingBeforeBackground = status === 'playing';

        // For VIDEO: pause when going to background (save battery)
        // For AUDIO: continue playing (background audio)
        if (currentTrack?.type === 'video' && status === 'playing') {
          await audioService.pause();
          usePlayerStore.getState().updateStatus('paused');
        }

        // Save progress immediately
        this.saveCurrentProgress();
        break;

      case 'active':
        this.isInBackground = false;

        // Resume video if it was playing before background
        if (
          currentTrack?.type === 'video' &&
          this.wasPlayingBeforeBackground &&
          status === 'paused'
        ) {
          await audioService.play();
          usePlayerStore.getState().updateStatus('playing');
        }
        this.wasPlayingBeforeBackground = false;
        break;
      default:
        break;
    }
  };

  // ── Memory Warning ──
  private setupMemoryWarningListener(): void {
    // Stock React Native has no cross-platform memory-warning event;
    // listen on Android's DeviceEventManager where available (best-effort).
    if (Platform.OS === 'android') {
      try {
        if (NativeModules.DeviceEventManager) {
          const emitter = new NativeEventEmitter(NativeModules.DeviceEventManager);
          this.memoryWarningSubscription = emitter.addListener(
            'memoryWarning',
            this.handleMemoryWarning
          );
        }
      } catch {
        // Fallback: no native memory warning listener
      }
    }
  }

  private handleMemoryWarning = async (): Promise<void> => {
    console.warn('[PlayerLifecycle] Memory warning received!');

    // Release non-essential resources
    const { status } = usePlayerStore.getState();

    // If not playing, unload the player entirely
    if (status === 'idle' || status === 'stopped') {
      await audioService.unload();
    }

    // Clear image caches
    try {
      await Image.clearMemoryCache();
    } catch {
      // Ignore
    }
  };

  // ── Orientation Changes ──
  private setupOrientationListener(): void {
    this.dimensionSubscription = Dimensions.addEventListener('change', this.handleDimensionChange);
  }

  private handleDimensionChange = ({
    window,
  }: {
    window: { width: number; height: number };
  }): void => {
    // Debounce orientation changes to prevent rapid re-renders. Playback/audio-focus
    // subscriptions are independent of orientation and must remain active across rotation.
    if (this.orientationChangeTimeout) {
      clearTimeout(this.orientationChangeTimeout);
    }

    this.orientationChangeTimeout = setTimeout(() => {
      const isLandscape = window.width > window.height;
      if (__DEV__) {
        console.log(`[PlayerLifecycle] Orientation: ${isLandscape ? 'Landscape' : 'Portrait'}`);
      }

      // Notify store about orientation for UI adjustments
      // (VideoPlayerView reads this via useScreenOrientation hook)
    }, 150); // 150ms debounce
  };

  // ── Progress Save ──
  private saveCurrentProgress(): void {
    const { currentTrack, position, duration } = usePlayerStore.getState();
    if (!currentTrack || position <= 0 || duration <= 0) return;

    try {
      // Player position is ms, progress records are seconds
      void useContinueWatchingStore.getState().saveProgress({
        mediaId: currentTrack.id,
        title: currentTrack.title,
        thumbnailUrl: currentTrack.thumbnailUrl,
        mediaType: currentTrack.type,
        sourceUrl: currentTrack.url,
        position: position / 1000,
        duration: duration / 1000,
        speakerOrArtist: currentTrack.artistOrSpeaker,
      });
    } catch {
      // Silent fail during lifecycle events
    }
  }
}

export const playerLifecycle = new PlayerLifecycleManager();
