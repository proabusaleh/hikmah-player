/** Typed contract for the Android MediaSession/foreground-service bridge planned for Phase 18.
 * This file deliberately does not pretend Expo local notifications are a system MediaSession.
 */
export type MediaSessionMetadata = {
  mediaId: string;
  title: string;
  artist?: string;
  album?: string;
  artworkUri?: string;
  durationMs?: number;
};

export type MediaSessionPlaybackState = 'none' | 'buffering' | 'playing' | 'paused' | 'stopped' | 'error';
export type MediaSessionTransportAction = 'play' | 'pause' | 'next' | 'previous' | 'seek-to';

export type MediaSessionSnapshot = {
  metadata: MediaSessionMetadata | null;
  state: MediaSessionPlaybackState;
  positionMs: number;
  speed: number;
  availableActions: MediaSessionTransportAction[];
};

const ACTIONS = new Set<MediaSessionTransportAction>(['play', 'pause', 'next', 'previous', 'seek-to']);

export function createMediaSessionSnapshot(input: Partial<MediaSessionSnapshot> = {}): MediaSessionSnapshot {
  const positionMs = Number.isFinite(input.positionMs) ? Math.max(0, Math.floor(input.positionMs as number)) : 0;
  const speed = Number.isFinite(input.speed) ? Math.max(0, Math.min(4, input.speed as number)) : 1;
  const availableActions = Array.isArray(input.availableActions)
    ? [...new Set(input.availableActions.filter((item): item is MediaSessionTransportAction => ACTIONS.has(item)))]
    : ['play', 'pause', 'next', 'previous'];
  return {
    metadata: input.metadata?.mediaId && input.metadata.title ? input.metadata : null,
    state: input.state ?? 'none',
    positionMs,
    speed,
    availableActions,
  };
}

export function clampSeekPosition(positionMs: number, durationMs?: number): number {
  if (!Number.isFinite(positionMs)) return 0;
  const position = Math.max(0, Math.floor(positionMs));
  return Number.isFinite(durationMs) && (durationMs as number) >= 0
    ? Math.min(position, Math.floor(durationMs as number))
    : position;
}
