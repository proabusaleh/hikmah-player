import type { LocalMediaItem } from '@/types/library';

export type SmartPlaylistId = 'recently-played' | 'most-played' | 'recently-added' | 'favorites';

export interface SmartPlaylistDefinition {
  id: SmartPlaylistId;
  title: string;
  description: string;
  emoji: string;
}

export const SMART_PLAYLISTS: SmartPlaylistDefinition[] = [
  { id: 'recently-played', title: 'Recently Played', description: 'Pick up where you left off', emoji: '🕘' },
  { id: 'most-played', title: 'Most Played', description: 'Your most listened-to media', emoji: '🔥' },
  { id: 'recently-added', title: 'Recently Added', description: 'The newest items in your library', emoji: '✨' },
  { id: 'favorites', title: 'Favorites', description: 'Everything you have starred', emoji: '💚' },
];

/** Derive smart playlists from library metadata; nothing is duplicated or separately persisted. */
export function getSmartPlaylistItems(
  media: LocalMediaItem[],
  playlistId: SmartPlaylistId,
  now = Date.now(),
): LocalMediaItem[] {
  const stableNewestFirst = (a: LocalMediaItem, b: LocalMediaItem) =>
    b.addedAt - a.addedAt || a.title.localeCompare(b.title);

  switch (playlistId) {
    case 'recently-played':
      return media
        .filter((item) => item.lastPlayed !== null)
        .sort((a, b) => (b.lastPlayed ?? 0) - (a.lastPlayed ?? 0))
        .slice(0, 50);
    case 'most-played':
      return media
        .filter((item) => item.playCount > 0)
        .sort((a, b) => b.playCount - a.playCount || (b.lastPlayed ?? 0) - (a.lastPlayed ?? 0))
        .slice(0, 50);
    case 'recently-added':
      return media
        .filter((item) => Number.isFinite(item.addedAt) && item.addedAt <= now)
        .sort(stableNewestFirst)
        .slice(0, 50);
    case 'favorites':
      return media.filter((item) => item.favorite).sort(stableNewestFirst);
    default: {
      const exhaustive: never = playlistId;
      return exhaustive;
    }
  }
}
