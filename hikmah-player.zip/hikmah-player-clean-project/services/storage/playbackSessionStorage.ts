import AsyncStorage from '@react-native-async-storage/async-storage';
import { MediaItem } from '@/types/media';

const STORAGE_KEY = '@hikmah-player/playback-session-v1';
const SCHEMA_VERSION = 1;
const MAX_QUEUE_ITEMS = 500;

export interface PlaybackSessionSnapshot {
  version: number;
  savedAt: number;
  queue: MediaItem[];
  currentIndex: number;
  position: number;
  duration: number;
  playbackSpeed: number;
  volume: number;
  isMuted: boolean;
  isShuffled: boolean;
  repeatMode: 'off' | 'all' | 'one';
}

const finiteNonNegative = (value: unknown): number =>
  typeof value === 'number' && Number.isFinite(value) ? Math.max(0, value) : 0;

const isMediaItem = (value: unknown): value is MediaItem => {
  if (!value || typeof value !== 'object') return false;
  const item = value as Partial<MediaItem>;
  return typeof item.id === 'string' && typeof item.title === 'string' &&
    typeof item.url === 'string' && (item.type === 'audio' || item.type === 'video');
};

export const PlaybackSessionStorage = {
  async save(snapshot: Omit<PlaybackSessionSnapshot, 'version' | 'savedAt'>): Promise<void> {
    const queue = snapshot.queue.filter(isMediaItem).slice(0, MAX_QUEUE_ITEMS);
    const currentIndex = queue.length
      ? Math.min(Math.max(0, Math.trunc(snapshot.currentIndex)), queue.length - 1)
      : -1;
    const safeSpeed = Number.isFinite(snapshot.playbackSpeed)
      ? Math.min(3, Math.max(0.25, snapshot.playbackSpeed)) : 1;
    const safeVolume = Number.isFinite(snapshot.volume)
      ? Math.min(1, Math.max(0, snapshot.volume)) : 1;
    const payload: PlaybackSessionSnapshot = {
      version: SCHEMA_VERSION,
      savedAt: Date.now(),
      queue,
      currentIndex,
      position: finiteNonNegative(snapshot.position),
      duration: finiteNonNegative(snapshot.duration),
      playbackSpeed: safeSpeed,
      volume: safeVolume,
      isMuted: Boolean(snapshot.isMuted),
      isShuffled: Boolean(snapshot.isShuffled),
      repeatMode: snapshot.repeatMode === 'all' || snapshot.repeatMode === 'one' ? snapshot.repeatMode : 'off',
    };
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  },

  async load(): Promise<PlaybackSessionSnapshot | null> {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw) as Partial<PlaybackSessionSnapshot>;
      if (parsed.version !== SCHEMA_VERSION || !Array.isArray(parsed.queue)) return null;
      const queue = parsed.queue.filter(isMediaItem).slice(0, MAX_QUEUE_ITEMS);
      const currentIndex = queue.length && Number.isInteger(parsed.currentIndex)
        ? Math.min(Math.max(0, parsed.currentIndex as number), queue.length - 1)
        : -1;
      return {
        version: SCHEMA_VERSION,
        savedAt: finiteNonNegative(parsed.savedAt),
        queue,
        currentIndex,
        position: finiteNonNegative(parsed.position),
        duration: finiteNonNegative(parsed.duration),
        playbackSpeed: Number.isFinite(parsed.playbackSpeed)
          ? Math.min(3, Math.max(0.25, parsed.playbackSpeed as number)) : 1,
        volume: Number.isFinite(parsed.volume)
          ? Math.min(1, Math.max(0, parsed.volume as number)) : 1,
        isMuted: Boolean(parsed.isMuted),
        isShuffled: Boolean(parsed.isShuffled),
        repeatMode: parsed.repeatMode === 'all' || parsed.repeatMode === 'one' ? parsed.repeatMode : 'off',
      };
    } catch {
      return null;
    }
  },

  async clear(): Promise<void> {
    await AsyncStorage.removeItem(STORAGE_KEY);
  },
};
