/** Helpers for presenting native expo-video audio/subtitle tracks safely. */
export type SelectableTrack = {
  id?: string | number;
  language?: string | null;
  label?: string | null;
  title?: string | null;
  type?: string | null;
};

export type TrackOption<T extends SelectableTrack> = {
  key: string;
  label: string;
  track: T | null;
};

export function formatTrackLabel(track: SelectableTrack, index: number, kind: 'audio' | 'subtitle'): string {
  const parts = [track.label, track.title, track.language, track.type]
    .filter((value): value is string => typeof value === 'string' && value.trim().length > 0)
    .map((value) => value.trim());
  const unique = [...new Set(parts)];
  return unique.length ? unique.join(' · ') : `${kind === 'audio' ? 'Audio' : 'Subtitle'} ${index + 1}`;
}

export function makeTrackOptions<T extends SelectableTrack>(tracks: readonly T[] | null | undefined, kind: 'audio' | 'subtitle'): TrackOption<T>[] {
  const options: TrackOption<T>[] = [{ key: 'off', label: kind === 'subtitle' ? 'Off' : 'Default', track: null }];
  (tracks ?? []).forEach((track, index) => {
    const identity = track.id ?? track.language ?? track.label ?? index;
    options.push({ key: String(identity), label: formatTrackLabel(track, index, kind), track });
  });
  return options;
}
