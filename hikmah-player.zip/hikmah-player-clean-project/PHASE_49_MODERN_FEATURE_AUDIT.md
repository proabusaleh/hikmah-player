# Phase 49 — Modern Feature Audit & Acceptance Checklist

## Purpose

This phase reconciles the README roadmap with features already present in source. Source presence is not proof of a successful device experience; all runtime claims remain subject to device QA.

## Source audit

### Mini-player across tabs — implemented in source; device validation pending

- `src/app/_layout.tsx` mounts `MiniPlayer` while the user is in the tabs group and a track is active.
- `src/components/player/MiniPlayer.tsx` displays track info, progress, playback controls, and navigates to `/player` when tapped.
- The mini-player uses the shared playback hook/store, so controls read and update the same player state.

### Playback speed presets — implemented in source; device validation pending

- `src/app/player/index.tsx` defines speed options from `0.5×` through `2.0×`.
- The player store exposes `setPlaybackSpeed`; playback-session persistence includes the selected speed.
- Verify that the native engine applies each selected rate and that queue progression remains correct after changing rates.

### Sleep timer — implemented in source; enhanced fade-out/end-of-track modes remain future work

- `hooks/useSleepTimer.ts` and `store/usePlayerStore.ts` provide a timer and background/foreground elapsed-time handling.
- Fade-out and end-of-track scheduling are not claimed by this phase.

## Device acceptance checklist

- [ ] Start a local audio file; confirm mini-player appears on Home, Library, Downloads, Favorites, and Settings.
- [ ] Switch tabs repeatedly; verify title, progress, play/pause, and next remain synchronized.
- [ ] Tap mini-player; verify full player opens and state is unchanged.
- [ ] Test playback rates `0.5×`, `0.75×`, `1×`, `1.25×`, `1.5×`, and `2×` on a real device.
- [ ] Change speed, skip tracks, and let a track end; verify no queue stall or duplicate advance.
- [ ] Background the app and return; confirm position and selected speed remain correct.
- [ ] Repeat with screen locked and with audio focus interruption if supported by the test device.
- [ ] Record device model, Android version, build ID, test result, and reproduction notes in the Phase 44 QA report template.

## Scope boundaries

This phase updates feature-status documentation and adds a static source audit. It does not certify Android playback, build an APK, or claim that device acceptance tests have run.
