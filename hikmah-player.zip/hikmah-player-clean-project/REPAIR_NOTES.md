# Repair notes

This archive contains a first-pass reliability/configuration cleanup based on source inspection.

## Changes made
- Removed the duplicate `expo-audio` config plugin entry while retaining the configured entry.
- Removed the iOS microphone usage string because the app config disables microphone permission; verify no shipped feature records audio before release.
- Corrected README permission table formatting and clarified the network/update wording.
- Updated the deployment checklist to use the icon/splash paths configured in `app.json`.
- Added a GitHub Actions workflow for Expo dependency validation, TypeScript, lint, and Jest.
- Added `PRIVACY_POLICY.md` as a draft. Replace the contact placeholder and verify all disclosures before publishing it.

## Not yet verified
- No native Android/iOS build or device test was run while preparing this archive.
- CI may expose existing type, lint, dependency, or test failures; fix those based on actual logs.
- Confirm Android/iOS permissions against the app's runtime behavior and current store requirements.
- Do not increment the app version or publish a release until the checks and device tests pass.

## Reliability hardening follow-up

See `QUALITY_HARDENING.md` for the detailed changes and remaining device-validation work. This pass adds stale playback-load protection and recoverable player errors, validates local file sources, makes scanner IDs stable, adds batched ID/path-aware library upserts, and guards download cancellation races. Full typecheck/lint/test execution remains unverified because dependency installation did not complete in this environment.


## Phase 6 — Subtitle and audio tracks
- Added a Tracks tab to video settings, native audio/subtitle selection controls, safe labels, empty states, and helper unit tests.
- This phase has not been built or run on device in this environment; validate Expo Video track API typings and real media behavior before release. External subtitle file loading is not included.

## Phase 9 — Native audio effects
- Added an Android Expo local module backed by `android.media.audiofx.Equalizer` and `BassBoost`.
- Added a JavaScript bridge with capability detection, input validation, and graceful unsupported-build fallback.
- Important: the current `expo-audio` player does not expose its Android audio session ID, so effects are not yet wired into normal playback. See `PHASE_9_NATIVE_AUDIO_EFFECTS.md` before representing effects as active.
- Native Android build and physical-device validation remain outstanding.

## Phase 11 — Audio effects integration diagnostics
Added `services/audio/audioEffectsDiagnostics.ts` and connected Settings to its explicit status model. The diagnostic reports module presence separately from session readiness. Unit tests cover unsupported platform, missing module, missing session ID, and valid session ID. Native effects still do not affect active playback until a real session ID is supplied by the playback engine.

## Phase 12 — Native Player Session Bridge
- Added isolated Android `MediaPlayer` Expo module and a typed TypeScript bridge exposing the real session ID.
- This is not yet wired into the app's existing `expo-audio` playback service; existing EQ/Bass Boost therefore remain inactive for normal playback.
- See `PHASE_12_NATIVE_PLAYER_SESSION_BRIDGE.md` for build steps and known limitations.

## Phase 13 — Native playback/effects coordinator
- Added an opt-in coordinator to apply effects against the real audio session returned by the Phase 12 native MediaPlayer bridge.
- Effect application errors are surfaced separately from media load success.
- The coordinator is not automatically connected to existing expo-audio playback; device/build validation is still required.

## Phase 14 — Native playback lifecycle
- Added an opt-in serialized native playback session facade with state snapshots and defensive validation.
- Effects are released before the native player during session replacement/disposal.
- Remaining release blockers: asynchronous native preparation, Android audio focus/interruption handling, actual app UI integration, and device validation.

## Phase 15 — Android audio focus
- Native `MediaPlayer` requests audio focus before play, handles permanent/transient/duckable focus changes, and pauses on `ACTION_AUDIO_BECOMING_NOISY`.
- Added JS subscriptions for native audio-focus events and explicit focus abandonment.
- Native path remains opt-in; existing `expo-audio` UI is not automatically migrated.
- Build and physical-device verification remain required.

## Phase 16 — Background playback/media controls readiness
- Added `services/playback/mediaSessionCoordinator.ts` for native player transport action routing and status subscriptions.
- Added `PHASE_16_BACKGROUND_PLAYBACK_MEDIA_CONTROLS.md` documenting implementation boundaries and required MediaSession/foreground-service work.
- Note: this is coordination readiness, not a finished foreground service or system lock-screen media notification. The primary `expo-audio` path is not automatically switched to the native player.

## Phase 17 — MediaSession Contract
- Added a typed contract for media metadata, playback state, transport actions, and seek bounds.
- Added unit tests for defensive normalization.
- This is preparation only; real Android MediaSession and foreground service are still pending.

## Phase 18 — Android MediaSession
- Added framework MediaSession metadata/state and a media-style notification to the opt-in native player module.
- Added typed bridge methods and a `mediaSessionAction` event for transport controls.
- Foreground service and automatic integration with the app's `expo-audio` playback remain outstanding; see `PHASE_18_ANDROID_MEDIA_SESSION.md`.

## Phase 19 — Foreground service path
- Added `HikmahPlaybackService` for opt-in service-owned audio playback with a media notification and framework MediaSession.
- Added `startNativeForegroundPlayback` and `sendNativeForegroundPlaybackCommand` bridge methods.
- This service uses a separate MediaPlayer; it is not yet wired to the app's existing expo-audio queue/UI. See `PHASE_19_FOREGROUND_SERVICE.md`.

## Phase 20 — Playback UI Adapter
- Added an opt-in typed adapter for the Android foreground-service engine.
- Existing expo-audio playback remains the default and is not automatically switched.
- The app must choose one playback engine per track to avoid duplicate audio.
- UI progress synchronization and queue-aware service actions remain follow-up work; native build/device tests are still required.


## Phase 21 — Native playback status synchronization
- Added a service status snapshot (state, playing, position, duration, URI, title, artist) exposed through the native module.
- Added a typed JS bridge and a subscription API with bounded polling; the polling timer is removed when the last subscriber unsubscribes.
- This is an opt-in native-service adapter, not a completed app-wide migration. TypeScript/Kotlin/device validation remains required.


## Phase 22 — queue and notification controls
- Added service-side Next/Previous notification actions and MediaSession callbacks.
- Routed service actions over a package-scoped broadcast to the native module event bridge.
- Added opt-in foreground adapter queue navigation.
- Validation limitation: archive integrity and static source review only; native build/device testing not run.

## Phase 23 — Main player store integration
- Added opt-in `playbackEngine` routing to the shared Zustand player store; `expo-audio` remains the default.
- Routed common playback controls and queue navigation to the foreground-service adapter when selected, with native status/progress subscription.
- Foreground service supports audio-only queues. Playback speed, volume and mute are explicitly unsupported in this engine for now.
- See `PHASE_23_MAIN_PLAYER_STORE_INTEGRATION.md` for API usage and limitations.


## Phase 24 — Playback reliability
- Guarded the `useAudioPlayback` event listener so stale expo-audio events cannot overwrite foreground-service state.
- Progress polling now checks engine ownership both before and after asynchronous status reads.
- Shuffle and unshuffle now sync the selected queue with the foreground adapter.
- Progress updates reject non-finite values and normalize position/duration.

## Phase 25 — Playback Integration Testing
- Added `__tests__/integration/playbackEngineIntegration.test.ts` for engine routing, video-queue rejection, pause routing, and native cleanup on engine switch.
- Added `PHASE_25_PLAYBACK_INTEGRATION_TESTING.md` with automated commands, Android device checklist, acceptance criteria, and explicit unverified items.
- Automated tests and native builds were not run in this environment because dependencies are not installed.


## Phase 26 — Background Playback QA
- Validate queue start indexes against NaN/Infinity.
- Ignore stale native status events after playback-engine changes.
- Normalize native progress and clear UI state when foreground playback becomes inactive/stopped/ended.
- Catch async notification navigation failures to avoid unhandled promise rejections.
- Added `__tests__/services/foregroundPlaybackAdapter.test.ts`; execute Jest and Android device checklist before release.

## Phase 27 — Playback Diagnostics & Regression Tests
- Added bounded, privacy-conscious in-memory playback diagnostics and unit tests for retention, summaries, timestamps, and sensitive-field filtering.
- Diagnostics are currently an opt-in utility, not yet wired into all engine transitions and not uploaded or persisted.
- See `PHASE_27_PLAYBACK_DIAGNOSTICS_REGRESSION_TESTS.md` for verification commands and limitations.

## Phase 28 — Playback Diagnostics Integration
- Added privacy-conscious diagnostic event hooks to the player store, expo-audio events, and Android foreground playback adapter/status sync.
- Added reusable QA panel at `src/components/player/PlaybackDiagnosticsPanel.tsx` with counts, event list, refresh, and clear.
- Added regression coverage for sanitized store status diagnostics.
- See `PHASE_28_PLAYBACK_DIAGNOSTICS_INTEGRATION.md` for local commands and device QA. Automated tests and TypeScript checks were not executed in this environment.

## Phase 29 — Playback Settings & Diagnostics Access
- Gated the playback diagnostics panel behind `__DEV__` in Settings.
- Added user-initiated sanitized JSON report sharing through the native share sheet.
- Added `PHASE_29_PLAYBACK_SETTINGS_DIAGNOSTICS_ACCESS.md` with privacy notes and QA checklist.
- Jest, TypeScript, lint, and physical-device validation remain pending until dependencies/device are available.

## Phase 30 — Playback stability and recovery
- Added explicit playback retry behavior with guarded skip cases and sanitized diagnostics.
- Serialized overlapping play/pause transport requests and invalidated pending track loads on stop.
- Added regression tests and `PHASE_30_PLAYBACK_STABILITY_RECOVERY.md` QA notes.

## Phase 31 — Audio Focus & Interruption Recovery

- Added lifecycle-managed subscriptions for native Android audio-focus and playback-status events.
- Native foreground-service status is reflected into the store only when that playback engine is active; headphones-disconnected and focus-loss reasons are handled as paused states.
- Audio focus diagnostics exclude track metadata and media paths.
- Native focus/resume remains owned by the Android module to avoid duplicate transport commands from JavaScript.
- See `PHASE_31_AUDIO_FOCUS_INTERRUPTION_RECOVERY.md` for device QA and known limitations.

## Phase 32 — Playback engine synchronization

- Guarded foreground-service status subscriptions with a generation token to reject late events after engine switches.
- Ignored native status snapshots whose URI does not match the selected track, with privacy-safe diagnostics.
- Preserved audio-focus/native-status lifecycle subscriptions across device orientation changes.
- See `PHASE_32_PLAYBACK_ENGINE_UNIFICATION_STATE_SYNC.md` for QA steps and known limitations.

## Phase 33 — Playback Position Persistence & Resume
- Added versioned persisted playback session snapshots and safe cold-start restoration.
- Restored sessions remain paused until the user explicitly resumes; the saved position is sought after the selected track reloads.
- Root layout debounces persistence writes and flushes on app background/unmount.
- See `PHASE_33_PLAYBACK_POSITION_PERSISTENCE_RESUME.md` for manual QA.

## Phase 34 — Smart Queue Persistence & Recovery
- Hardened queue start-index validation and queue-removal bounds checks.
- Current-track selection is resolved by stable media ID after queue reordering/removal.
- Added regression cases for invalid indexes and preserving the selected track after removing an earlier row.
- See `PHASE_34_SMART_QUEUE_PERSISTENCE_RECOVERY.md` for QA steps and validation limits.

## Phase 35 — Queue UX & Playback History
- Added a confirmation-protected clear-history action in Library → Recent.
- Clearing history resets `lastPlayed` only; it does not delete media or reset play counts.
- See `PHASE_35_QUEUE_UX_PLAYBACK_HISTORY.md` for manual QA.

## Phase 36 — Queue Management & Advanced Playback Controls
- Added a Play Next queue action and store operation that preserves current-track identity during queue mutation.
- Added manual QA steps for queue ordering and engine synchronization.

## Phase 37 — Playback UX polish and queue automation

- Added an actionable Up Next preview card to the main player screen.
- Added a queue shortcut and artwork fallback for tracks without thumbnails.
- Preview behavior respects the current queue order, repeat-one, and repeat-all modes.
- Added accessibility labels to new interactions.
- Validation note: automated tests and physical-device playback QA were not run in this environment.

## Phase 38 — Smart Auto-Advance & End-of-Track Handling
- Added a per-track completion guard in `useAudioPlayback` to ignore duplicate `trackEnd` callbacks until playback begins again.
- Queue-end now records a diagnostic event and leaves the player in a clean stopped state with progress reset and no stale playback error.
- Manual device checks and automated suites remain outstanding; see `PHASE_38_SMART_AUTO_ADVANCE_END_OF_TRACK.md`.

## Phase 39 — Playback reliability regression protection
- Extracted duplicate track-end suppression into `TrackCompletionGuard`, used by the audio playback hook.
- Added focused unit tests for duplicate completion events, track changes, reset behavior for repeat-one, and missing track IDs.
- Existing player-store tests cover Repeat One/All and end-of-queue behavior; full test execution remains pending where dependencies/runtime are unavailable.

## Phase 40 — Playback integration test suite
- Added store-level integration tests for normal queue advancement, Repeat One, Repeat All wraparound, queue-end stopped state, stale-error cleanup, diagnostics, and empty-queue handling.
- Tests mock the audio service and foreground adapter to isolate state/command contracts.
- Runtime test execution remains pending because dependencies are not installed in the packaging environment.

## Phase 41 — Playback CI automation
- Added a GitHub Actions workflow with separate lint/typecheck and playback regression jobs.
- Added the `test:playback` npm script for queue completion, playback-engine integration, and completion-guard tests.
- CI uploads an LCOV coverage artifact when available; configure repository branch protection to require the jobs.
- Runtime validation remains pending until the workflow runs against a pushed branch.

## Phase 42 — Playback Release Readiness & Final QA
- Added a dependency-free static release-readiness script and `npm run check:release`.
- Added a manual device QA checklist covering queue completion, repeat modes, background playback, interruptions, permissions, offline playback, RTL, and accessibility.
- Static checks are not substitutes for CI, EAS build validation, or physical-device testing.

## Phase 43 — Release candidate preflight
- Added `npm run check:rc` to statically validate version alignment, EAS profiles, playback config, required test/docs, CI presence, and secret-file ignore rules.
- Added `.gitignore` rules for environment files, signing material, generated output, and local dependencies.
- Static checks do not establish successful runtime playback or native build correctness. Follow the Phase 43 release checklist and Phase 42 device QA checklist before release.
