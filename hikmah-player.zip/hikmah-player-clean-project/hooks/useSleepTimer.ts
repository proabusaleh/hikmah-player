import { useCallback, useEffect, useRef } from 'react';
import { AppState, AppStateStatus } from 'react-native';

import { usePlayerStore } from '@/store/usePlayerStore';

export const useSleepTimer = () => {
  const {
    sleepTimerEnd,
    sleepTimerRemaining,
    setSleepTimer,
    clearSleepTimer,
    tickSleepTimer,
  } = usePlayerStore();

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const appStateRef = useRef<AppStateStatus>(AppState.currentState);

  useEffect(() => {
    if (!sleepTimerEnd) return;

    // Recalculate from the absolute end timestamp instead of decrementing a
    // counter, so background timer throttling does not extend the sleep timer.
    tickSleepTimer();
    intervalRef.current = setInterval(tickSleepTimer, 1000);

    const subscription = AppState.addEventListener('change', (nextState) => {
      const wasBackgrounded = appStateRef.current.match(/inactive|background/);
      appStateRef.current = nextState;
      if (wasBackgrounded && nextState === 'active') tickSleepTimer();
    });

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      subscription.remove();
    };
  }, [sleepTimerEnd, tickSleepTimer]);

  const startTimer = useCallback(
    (minutes: number) => {
      setSleepTimer(minutes);
    },
    [setSleepTimer]
  );

  const cancelTimer = useCallback(() => {
    clearSleepTimer();
  }, [clearSleepTimer]);

  const isActive = sleepTimerEnd !== null;
  const formattedRemaining = isActive
    ? `${String(Math.floor(sleepTimerRemaining / 60)).padStart(2, '0')}:${String(
        sleepTimerRemaining % 60
      ).padStart(2, '0')}`
    : null;

  return {
    isActive,
    remainingSeconds: sleepTimerRemaining,
    formattedRemaining,
    startTimer,
    cancelTimer,
  };
};
