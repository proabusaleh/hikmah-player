# Phase 44 — Android Release Candidate Build & Device Validation

## Goal
Make Android release-candidate validation repeatable and evidence-based. This phase adds a report validator and a fill-in report template. It does **not** build an APK, run an emulator, or certify device playback.

## 1. Install and static preflight
Run from the project root in a Node/npm environment:

```bash
npm ci
npm run check:release
npm run check:rc
npm run test:playback
npm run lint
npx tsc --noEmit
npx expo-doctor
```

Review every failure and warning. Keep the CI run tied to the exact commit being tested.

## 2. Build an installable Android candidate

```bash
npx eas-cli@latest build --platform android --profile preview
```

The `preview` profile is configured to produce an APK for internal installation. Record the EAS build ID, URL, git commit SHA, app version, and artifact checksum if available. Do not treat a queued or failed build as a successful build. For Play Store submission, use the production app-bundle profile only after the release gates are complete.

## 3. Physical-device test
1. Install the exact preview APK on a clean supported Android device.
2. Record model, Android version, date/time with timezone, and tester.
3. Test clean launch, local/network media playback, background playback, screen lock, notification/lock-screen controls, queue completion, repeat modes, interruptions, headphone disconnect, permission denied/granted flows, and crash/log behavior.
4. Repeat critical playback checks after force-stop/relaunch and after device reboot where practical.
5. Capture logs and screenshots/video for failures. Remove tokens, personal media paths, and other private data before sharing evidence.
6. Fill `docs/PHASE_44_DEVICE_QA_REPORT_TEMPLATE.json` and save a copy, e.g. `device-qa-report.json` outside version control if it contains device/user details.

## 4. Validate the report

```bash
node scripts/device-qa-report.js --report=./device-qa-report.json
```

The validator checks required metadata and check statuses. `FAIL`, `BLOCKED`, and `NOT_RUN` fail the release gate. A fully passing report is only a structured record; a reviewer must still inspect evidence and approve the release. The validator cannot independently verify that a person actually ran a test.

## Release gates
- [ ] Static preflight and required automated tests pass on the release commit.
- [ ] CI is green; lint/typecheck/Expo Doctor results are reviewed.
- [ ] EAS preview APK build completes successfully.
- [ ] Physical-device report is complete, with all checks PASS and evidence referenced.
- [ ] Known issues and privacy/store disclosures reviewed.
- [ ] Human release owner signs off before production submission.

## Honest status for this source package
This phase supplies scripts and a workflow. It does not claim that npm dependencies were installed, Jest/lint/typecheck/Expo Doctor ran, EAS generated an APK, or physical-device QA occurred in the authoring environment.
