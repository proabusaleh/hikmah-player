# Phase 47 — Clean Project Package

## What changed
- Flattened the ZIP layout so project files sit at the archive root rather than inside a nested `phase46work/` folder.
- Removed unused Expo starter/tutorial images (`react-logo*.png`, `tutorial-web.png`) after checking repository references.
- Removed the Expo icon editor working directory (`assets/expo.icon/`); generated runtime app icons remain in `assets/icons/` and `assets/images/`.
- Moved historical phase notes into `docs/phase-history/` to reduce root-folder clutter.
- Kept source code, tests, scripts, configuration, lockfile (if present), release checklists, current asset docs, and assets referenced by code/config.

## Verification limits
This cleanup is file-organization and asset-reference cleanup. It does not claim a native Android build or device test. Run `npm ci`, then `npm run check:release`, `npm run check:rc`, `npm run check:device-qa`, and the test/lint/type checks in a configured development environment.
