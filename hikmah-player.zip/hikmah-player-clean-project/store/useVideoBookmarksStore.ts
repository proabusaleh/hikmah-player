import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';

const STORAGE_KEY = '@hikmah-player/video-bookmarks/v1';

export interface VideoBookmark {
  id: string;
  mediaId: string;
  title: string;
  position: number;
  createdAt: number;
}

interface VideoBookmarksState {
  bookmarks: VideoBookmark[];
  loaded: boolean;
  load: () => Promise<void>;
  add: (input: Omit<VideoBookmark, 'id' | 'createdAt'>) => Promise<boolean>;
  remove: (id: string) => Promise<void>;
  forMedia: (mediaId: string) => VideoBookmark[];
}

const persist = async (bookmarks: VideoBookmark[]) => {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(bookmarks));
};

export const useVideoBookmarksStore = create<VideoBookmarksState>((set, get) => ({
  bookmarks: [],
  loaded: false,
  load: async () => {
    if (get().loaded) return;
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      const parsed: unknown = raw ? JSON.parse(raw) : [];
      const bookmarks = Array.isArray(parsed)
        ? parsed.filter((item): item is VideoBookmark =>
            !!item && typeof item.id === 'string' && typeof item.mediaId === 'string' &&
            typeof item.title === 'string' && Number.isFinite(item.position) &&
            Number.isFinite(item.createdAt))
        : [];
      set({ bookmarks, loaded: true });
    } catch {
      set({ bookmarks: [], loaded: true });
    }
  },
  add: async (input) => {
    const position = Number(input.position);
    if (!input.mediaId.trim() || !Number.isFinite(position) || position < 0) return false;
    const roundedPosition = Math.floor(position);
    const existing = get().bookmarks.find((item) => item.mediaId === input.mediaId && Math.abs(item.position - roundedPosition) < 3);
    if (existing) return false;
    const bookmark: VideoBookmark = {
      ...input,
      position: roundedPosition,
      id: `${input.mediaId}:${roundedPosition}:${Date.now()}`,
      createdAt: Date.now(),
    };
    const bookmarks = [bookmark, ...get().bookmarks].slice(0, 500);
    set({ bookmarks });
    try { await persist(bookmarks); } catch { set({ bookmarks: get().bookmarks.filter((item) => item.id !== bookmark.id) }); throw new Error('Could not save bookmark. Check device storage and try again.'); }
    return true;
  },
  remove: async (id) => {
    const previous = get().bookmarks;
    const bookmarks = previous.filter((item) => item.id !== id);
    set({ bookmarks });
    try { await persist(bookmarks); } catch { set({ bookmarks: previous }); throw new Error('Could not remove bookmark. Please try again.'); }
  },
  forMedia: (mediaId) => get().bookmarks.filter((item) => item.mediaId === mediaId).sort((a, b) => a.position - b.position),
}));
