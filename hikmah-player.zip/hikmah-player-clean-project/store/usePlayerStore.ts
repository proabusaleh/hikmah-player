import { create } from 'zustand';

import { audioService } from '@/services/audio/audioService';
import { foregroundPlaybackAdapter } from '@/services/audio/foregroundPlaybackAdapter';
import { playbackDiagnostics } from '@/services/playback/playbackDiagnostics';
import { PlaybackSessionStorage } from '@/services/storage/playbackSessionStorage';
import { MediaItem, PlaybackStatus } from '@/types/media';

export type ExtendedRepeatMode = 'off' | 'all' | 'one';

interface PlayerState {
  playbackEngine: 'expo-audio' | 'foreground-service';
  currentTrack: MediaItem | null;
  status: PlaybackStatus;
  /** Human-readable recoverable playback error for the player UI. */
  playbackError: string | null;
  position: number;
  duration: number;
  playbackSpeed: number;
  volume: number;
  isMuted: boolean;

  queue: MediaItem[];
  originalQueue: MediaItem[];
  currentIndex: number;
  isShuffled: boolean;
  repeatMode: ExtendedRepeatMode;

  sleepTimerEnd: number | null;
  sleepTimerRemaining: number;

  loadAndPlay: (item: MediaItem) => Promise<void>;
  togglePlayPause: () => Promise<void>;
  /** Retry the currently selected track after a recoverable playback error. */
  retryPlayback: () => Promise<void>;
  pause: () => Promise<void>;
  resume: () => Promise<void>;
  stop: () => Promise<void>;
  seekTo: (positionMs: number) => Promise<void>;
  seekRelative: (deltaSeconds: number) => Promise<void>;

  setQueue: (tracks: MediaItem[], startIndex?: number) => void;
  addToQueue: (track: MediaItem) => void;
  playNextInQueue: (index: number) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;
  moveInQueue: (fromIndex: number, toIndex: number) => void;

  nextTrack: () => Promise<void>;
  previousTrack: () => Promise<void>;
  playTrackAtIndex: (index: number) => Promise<void>;

  toggleShuffle: () => void;
  cycleRepeatMode: () => void;
  setPlaybackSpeed: (speed: number) => Promise<void>;
  setVolume: (volume: number) => Promise<void>;
  toggleMute: () => Promise<void>;

  setSleepTimer: (minutes: number) => void;
  clearSleepTimer: () => void;
  tickSleepTimer: () => void;

  updateProgress: (position: number, duration: number) => void;
  updateStatus: (status: PlaybackStatus) => void;
  resetPlayer: () => void;
  setPlaybackEngine: (engine: 'expo-audio' | 'foreground-service') => Promise<void>;
  persistPlaybackSession: () => Promise<void>;
  restorePlaybackSession: () => Promise<boolean>;
}

const shuffleArray = <T,>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

export const usePlayerStore = create<PlayerState>((set, get) => {
  // Ignore late native load results when the user quickly switches tracks.
  let loadRequestId = 0;
  // Prevent rapid taps/remote events from issuing overlapping transport commands.
  let transportCommandInFlight = false;
  let unsubscribeForegroundStatus: (() => void) | null = null;
  // Monotonic subscription generation prevents queued callbacks from a prior engine session
  // from mutating the store after an engine switch (including a quick switch back).
  let foregroundStatusGeneration = 0;
  // Cold-start restoration is metadata-only; seek to the saved position on explicit resume.
  let restoredPositionPending = false;
  const syncForegroundQueue = () => {
    const { queue, currentIndex, playbackEngine } = get();
    if (playbackEngine !== 'foreground-service') return;
    foregroundPlaybackAdapter.setQueue(queue, currentIndex < 0 ? 0 : currentIndex);
  };
  const mapForegroundStatus = (state: string): PlaybackStatus => {
    if (state === 'playing') return 'playing';
    if (state === 'paused') return 'paused';
    if (state === 'buffering') return 'buffering';
    if (state === 'error') return 'error';
    if (state === 'stopped' || state === 'ended') return 'stopped';
    return 'idle';
  };
  const readablePlaybackError = (error: unknown): string => {
    const message = error instanceof Error ? error.message : String(error ?? '');
    if (/network|fetch|internet|timeout/i.test(message)) return 'Could not reach this media. Check your connection and try again.';
    if (/permission|denied|not authorized/i.test(message)) return 'Hikmah Player cannot access this file. Check media permissions.';
    if (/MEDIA_FILE_MISSING|no such file|not found|does not exist|404/i.test(message)) return 'This media file is no longer available. Remove it from your library or choose another file.';
    return 'This media could not be played. Try again or choose another file.';
  };
  return ({
  playbackEngine: 'expo-audio',
  currentTrack: null,
  status: 'idle',
  playbackError: null,
  position: 0,
  duration: 0,
  playbackSpeed: 1.0,
  volume: 1.0,
  isMuted: false,

  queue: [],
  originalQueue: [],
  currentIndex: -1,
  isShuffled: false,
  repeatMode: 'off',

  sleepTimerEnd: null,
  sleepTimerRemaining: 0,

  loadAndPlay: async (item) => {
    const requestId = ++loadRequestId;
    playbackDiagnostics.record('track.load.start', { engine: get().playbackEngine, details: { mediaType: item.type } });
    set({ currentTrack: item, status: 'buffering', position: 0, duration: 0, playbackError: null });
    try {
      if (get().playbackEngine === 'foreground-service') {
        if (item.type !== 'audio') throw new Error('Android foreground service playback supports audio items only.');
        let queue = get().queue;
        let index = queue.findIndex((track) => track.id === item.id);
        if (queue.some((track) => track.type !== 'audio')) throw new Error('Remove video items before using foreground-service playback.');
        if (index < 0) {
          queue = [...queue, item];
          index = queue.length - 1;
          set({ queue, originalQueue: [...queue], currentIndex: index });
        } else {
          set({ currentIndex: index });
        }
        foregroundPlaybackAdapter.setQueue(queue, index);
        await foregroundPlaybackAdapter.playTrackAt(index);
        if (requestId !== loadRequestId) return;
        set({ currentTrack: item, status: 'playing', playbackError: null });
        playbackDiagnostics.record('track.load.success', { engine: get().playbackEngine });
        return;
      }
      const { duration } = await audioService.loadTrack(item, true);
      if (requestId !== loadRequestId) return;
      set({ status: 'playing', duration, playbackError: null });
      playbackDiagnostics.record('track.load.success', { engine: get().playbackEngine });
    } catch (error) {
      if (requestId !== loadRequestId) return;
      set({ status: 'error', playbackError: readablePlaybackError(error) });
      playbackDiagnostics.record('track.load.failure', { level: 'error', engine: get().playbackEngine, details: { mediaType: item.type } });
    }
  },

  togglePlayPause: async () => {
    if (transportCommandInFlight) {
      playbackDiagnostics.record('playback.command.ignored', { level: 'warning', engine: get().playbackEngine, details: { reason: 'command_in_flight' } });
      return;
    }
    const { status } = get();
    transportCommandInFlight = true;
    try {
      if (get().playbackEngine === 'foreground-service') {
        if (status === 'playing') await foregroundPlaybackAdapter.pause();
        else if (status === 'paused' || status === 'stopped') await foregroundPlaybackAdapter.play();
        set({ status: status === 'playing' ? 'paused' : 'playing', playbackError: null });
        playbackDiagnostics.record(status === 'playing' ? 'playback.pause' : 'playback.play', { engine: get().playbackEngine });
        return;
      }
      if (status === 'playing') {
        await audioService.pause();
        set({ status: 'paused', playbackError: null });
        playbackDiagnostics.record('playback.pause', { engine: get().playbackEngine });
      } else if (status === 'paused' || status === 'stopped') {
        await audioService.play();
        set({ status: 'playing', playbackError: null });
        playbackDiagnostics.record('playback.play', { engine: get().playbackEngine });
      } else if (status === 'error' && get().currentTrack) {
        await get().loadAndPlay(get().currentTrack!);
      }
    } catch (error) {
      set({ status: 'error', playbackError: readablePlaybackError(error) });
      playbackDiagnostics.record('playback.command.failure', { level: 'error', engine: get().playbackEngine, details: { command: 'toggle' } });
    } finally {
      transportCommandInFlight = false;
    }
  },

  retryPlayback: async () => {
    const { currentTrack, status } = get();
    if (!currentTrack) {
      set({ playbackError: 'Choose a track before retrying playback.' });
      playbackDiagnostics.record('playback.retry.skipped', { level: 'warning', engine: get().playbackEngine, details: { reason: 'no_track' } });
      return;
    }
    if (status === 'buffering') {
      playbackDiagnostics.record('playback.retry.skipped', { level: 'warning', engine: get().playbackEngine, details: { reason: 'already_buffering' } });
      return;
    }
    playbackDiagnostics.record('playback.retry.start', { engine: get().playbackEngine, details: { mediaType: currentTrack.type } });
    await get().loadAndPlay(currentTrack);
    if (get().status === 'playing') {
      set({ playbackError: null });
      playbackDiagnostics.record('playback.retry.success', { engine: get().playbackEngine });
    } else {
      playbackDiagnostics.record('playback.retry.failure', { level: 'error', engine: get().playbackEngine });
    }
  },

  pause: async () => {
    try {
      if (get().playbackEngine === 'foreground-service') await foregroundPlaybackAdapter.pause();
      else await audioService.pause();
      set({ status: 'paused' });
    }
    catch (error) { set({ status: 'error', playbackError: readablePlaybackError(error) }); }
  },

  resume: async () => {
    try {
      if (restoredPositionPending && get().currentTrack) {
        const track = get().currentTrack!;
        const targetPosition = get().position;
        await get().loadAndPlay(track);
        if (get().status !== 'playing') return;
        if (targetPosition > 0) await get().seekTo(targetPosition);
        restoredPositionPending = false;
      } else if (get().playbackEngine === 'foreground-service') {
        await foregroundPlaybackAdapter.play();
      } else {
        await audioService.play();
      }
      set({ status: 'playing', playbackError: null });
    } catch (error) {
      set({ status: 'error', playbackError: readablePlaybackError(error) });
      playbackDiagnostics.record('session.resume.failure', { level: 'warning', engine: get().playbackEngine });
    }
  },

  stop: async () => {
    // Invalidate pending loads so a late resolve cannot flip stopped back to playing.
    loadRequestId += 1;
    try {
      if (get().playbackEngine === 'foreground-service') foregroundPlaybackAdapter.stop();
      else await audioService.stop();
      set({ status: 'stopped', position: 0, playbackError: null });
      playbackDiagnostics.record('playback.stop', { engine: get().playbackEngine });
    } catch (error) {
      set({ status: 'error', playbackError: readablePlaybackError(error) });
      playbackDiagnostics.record('playback.stop.failure', { level: 'error', engine: get().playbackEngine });
    }
  },

  seekTo: async (positionMs) => {
    if (get().playbackEngine === 'foreground-service') await foregroundPlaybackAdapter.seekTo(positionMs);
    else await audioService.seek(positionMs);
    set({ position: positionMs });
    playbackDiagnostics.record('playback.seek', { engine: get().playbackEngine, details: { positionMs: Number.isFinite(positionMs) ? Math.max(0, positionMs) : 0 } });
  },

  seekRelative: async (deltaSeconds) => {
    if (get().playbackEngine === 'foreground-service') {
      const status = foregroundPlaybackAdapter.getStatus();
      await foregroundPlaybackAdapter.seekTo(Math.max(0, status.positionMs + deltaSeconds * 1000));
    } else await audioService.seekRelative(deltaSeconds * 1000);
  },

  setQueue: (tracks, startIndex = 0) => {
    const safeTracks = Array.isArray(tracks) ? tracks.filter((track) => track && typeof track.id === 'string' && typeof track.url === 'string') : [];
    const safeIndex = safeTracks.length ? Math.min(Math.max(0, Number.isFinite(startIndex) ? Math.trunc(startIndex) : 0), safeTracks.length - 1) : -1;
    if (get().playbackEngine === 'foreground-service' && safeTracks.some((track) => track.type !== 'audio')) {
      set({ playbackError: 'Foreground-service mode supports audio-only queues. Switch to expo-audio to use video items.' });
      return;
    }
    set({
      queue: safeTracks,
      originalQueue: [...safeTracks],
      currentIndex: safeIndex,
      currentTrack: safeTracks[safeIndex] || null,
      isShuffled: false,
    });
    syncForegroundQueue();
  },

  addToQueue: (track) => {
    if (get().playbackEngine === 'foreground-service' && track.type !== 'audio') {
      set({ playbackError: 'Foreground-service mode supports audio items only.' });
      return;
    }
    set((state) => ({
      queue: [...state.queue, track],
      originalQueue: [...state.originalQueue, track],
    }));
    syncForegroundQueue();
  },

  playNextInQueue: (index) => {
    const { queue, currentIndex } = get();
    if (!Number.isInteger(index) || index < 0 || index >= queue.length || index === currentIndex) return;
    const currentTrackId = queue[currentIndex]?.id ?? null;
    const selected = queue[index];
    if (!selected) return;
    const withoutSelected = queue.filter((_, itemIndex) => itemIndex !== index);
    const currentIndexAfterRemoval = currentTrackId
      ? withoutSelected.findIndex((track) => track.id === currentTrackId)
      : -1;
    const insertionIndex = currentIndexAfterRemoval >= 0 ? currentIndexAfterRemoval + 1 : 0;
    withoutSelected.splice(insertionIndex, 0, selected);
    const nextIndex = currentTrackId
      ? withoutSelected.findIndex((track) => track.id === currentTrackId)
      : -1;
    set({
      queue: withoutSelected,
      originalQueue: [...withoutSelected],
      currentIndex: nextIndex,
      currentTrack: withoutSelected[nextIndex] || null,
    });
    syncForegroundQueue();
  },

  removeFromQueue: (index) => {
    const { queue, originalQueue, currentIndex } = get();
    if (!Number.isInteger(index) || index < 0 || index >= queue.length) return;
    const removedTrack = queue[index];
    const currentTrackBefore = queue[currentIndex] ?? null;
    const newQueue = queue.filter((_, i) => i !== index);
    // Filter by identity, not the same numeric index: shuffled queue order may differ.
    const newOriginal = [...originalQueue];
    const originalIndex = newOriginal.findIndex((track) => track.id === removedTrack?.id);
    if (originalIndex >= 0) newOriginal.splice(originalIndex, 1);
    const preservedIndex = currentTrackBefore ? newQueue.findIndex((track) => track.id === currentTrackBefore.id) : -1;
    let newIndex = preservedIndex;
    if (index === currentIndex && newQueue.length > 0) newIndex = Math.min(index, newQueue.length - 1);
    if (newQueue.length === 0) newIndex = -1;

    set({
      queue: newQueue,
      originalQueue: newOriginal,
      currentIndex: newIndex,
      currentTrack: newQueue[newIndex] || null,
    });
    syncForegroundQueue();
  },

  clearQueue: () => {
    // Clear upcoming items without abruptly unloading the track that is playing.
    const { currentTrack, status } = get();
    const retainedQueue = currentTrack ? [currentTrack] : [];
    set({
      queue: retainedQueue,
      originalQueue: [...retainedQueue],
      currentIndex: currentTrack ? 0 : -1,
      currentTrack,
      status: currentTrack ? status : 'idle',
    });
    syncForegroundQueue();
  },

  moveInQueue: (fromIndex, toIndex) => {
    const { queue, currentIndex } = get();
    if (
      fromIndex < 0 || toIndex < 0 ||
      fromIndex >= queue.length || toIndex >= queue.length ||
      fromIndex === toIndex
    ) return;

    const currentTrackId = queue[currentIndex]?.id ?? null;
    const newQueue = [...queue];
    const [moved] = newQueue.splice(fromIndex, 1);
    if (!moved) return;
    newQueue.splice(toIndex, 0, moved);

    // Keep the currently playing item selected when rows are reordered.
    const nextIndex = currentTrackId ? newQueue.findIndex((track) => track.id === currentTrackId) : -1;

    set({
      queue: newQueue,
      originalQueue: [...newQueue],
      currentIndex: nextIndex,
      currentTrack: newQueue[nextIndex] || null,
    });
    syncForegroundQueue();
  },

  nextTrack: async () => {
    const { queue, currentIndex, repeatMode } = get();
    if (queue.length === 0) return;

    if (get().playbackEngine === 'foreground-service') {
      if (repeatMode === 'one') { await foregroundPlaybackAdapter.seekTo(0); await foregroundPlaybackAdapter.play(); set({ position: 0, status: 'playing' }); return; }
      if (currentIndex + 1 < queue.length) await get().playTrackAtIndex(currentIndex + 1);
      else if (repeatMode === 'all') await get().playTrackAtIndex(0);
      else { foregroundPlaybackAdapter.stop(); set({ status: 'stopped', position: 0 }); }
      return;
    }

    if (repeatMode === 'one') {
      await audioService.seek(0);
      await audioService.play();
      set({ position: 0, status: 'playing' });
      return;
    }

    const nextIndex = currentIndex + 1;
    if (nextIndex < queue.length) {
      set({ currentIndex: nextIndex });
      await get().loadAndPlay(queue[nextIndex]);
    } else if (repeatMode === 'all') {
      set({ currentIndex: 0 });
      await get().loadAndPlay(queue[0]);
    } else {
      // Queue completion is a normal terminal state, not a playback error.
      // Reset progress and keep the final track selected for replay.
      set({ status: 'stopped', position: 0, playbackError: null });
      playbackDiagnostics.record('queue.end', { engine: get().playbackEngine, details: { repeatMode } });
    }
  },

  previousTrack: async () => {
    const { queue, currentIndex, position } = get();
    if (queue.length === 0) return;

    if (get().playbackEngine === 'foreground-service') {
      if (position > 3000) { await foregroundPlaybackAdapter.seekTo(0); set({ position: 0 }); return; }
      if (currentIndex > 0) await get().playTrackAtIndex(currentIndex - 1);
      else if (get().repeatMode === 'all') await get().playTrackAtIndex(queue.length - 1);
      return;
    }

    if (position > 3000) {
      await audioService.seek(0);
      set({ position: 0 });
      return;
    }

    const prevIndex = currentIndex - 1;
    if (prevIndex >= 0) {
      set({ currentIndex: prevIndex });
      await get().loadAndPlay(queue[prevIndex]);
    } else if (get().repeatMode === 'all') {
      const lastIndex = queue.length - 1;
      set({ currentIndex: lastIndex });
      await get().loadAndPlay(queue[lastIndex]);
    }
  },

  playTrackAtIndex: async (index) => {
    const { queue } = get();
    if (index >= 0 && index < queue.length) {
      set({ currentIndex: index });
      if (get().playbackEngine === 'foreground-service') foregroundPlaybackAdapter.setQueue(queue, index);
      await get().loadAndPlay(queue[index]);
    }
  },

  toggleShuffle: () => {
    const { isShuffled, queue, originalQueue, currentIndex, currentTrack } = get();

    if (isShuffled) {
      const originalIndex = originalQueue.findIndex((track) => track.id === currentTrack?.id);
      set({
        queue: [...originalQueue],
        currentIndex: originalIndex >= 0 ? originalIndex : 0,
        currentTrack: originalQueue[originalIndex >= 0 ? originalIndex : 0] || null,
        isShuffled: false,
      });
      syncForegroundQueue();
    } else {
      const remaining = queue.filter((_, index) => index !== currentIndex);
      const shuffled = shuffleArray(remaining);
      if (currentTrack) shuffled.unshift(currentTrack);
      set({
        queue: shuffled,
        currentIndex: 0,
        currentTrack: shuffled[0] || null,
        isShuffled: true,
      });
      syncForegroundQueue();
    }
  },

  cycleRepeatMode: () => {
    const { repeatMode } = get();
    const modes: ExtendedRepeatMode[] = ['off', 'all', 'one'];
    const nextIndex = (modes.indexOf(repeatMode) + 1) % modes.length;
    set({ repeatMode: modes[nextIndex] });
  },

  setPlaybackSpeed: async (speed) => {
    if (!Number.isFinite(speed)) return;
    const clamped = Math.max(0.5, Math.min(2, speed));
    try {
      if (get().playbackEngine === 'foreground-service') {
        set({ playbackError: 'Playback speed control is not yet supported by the foreground-service engine.' });
        return;
      }
      await audioService.setRate(clamped);
      set({ playbackSpeed: clamped, playbackError: null });
    } catch (error) {
      set({ playbackError: readablePlaybackError(error) });
    }
  },

  setVolume: async (volume) => {
    const clamped = Math.max(0, Math.min(1, volume));
    if (get().playbackEngine === 'foreground-service') {
      set({ playbackError: 'Volume control is managed by Android while foreground-service playback is active.' });
      return;
    }
    await audioService.setVolume(clamped);
    set({ volume: clamped, isMuted: clamped === 0 });
  },

  toggleMute: async () => {
    if (get().playbackEngine === 'foreground-service') {
      set({ playbackError: 'Mute control is not yet supported by the foreground-service engine.' });
      return;
    }
    const { isMuted, volume } = get();
    const nextMuted = !isMuted;
    await audioService.setMuted(nextMuted);
    set({ isMuted: nextMuted, volume: nextMuted ? 0 : volume || 1 });
  },

  setSleepTimer: (minutes) => {
    if (!Number.isFinite(minutes) || minutes <= 0) return;
    const safeMinutes = Math.min(24 * 60, Math.floor(minutes));
    if (safeMinutes <= 0) return;
    const endTime = Date.now() + safeMinutes * 60 * 1000;
    set({
      sleepTimerEnd: endTime,
      sleepTimerRemaining: safeMinutes * 60,
    });
  },

  clearSleepTimer: () => {
    set({ sleepTimerEnd: null, sleepTimerRemaining: 0 });
  },

  tickSleepTimer: () => {
    const { sleepTimerEnd } = get();
    if (!sleepTimerEnd) return;

    const remaining = Math.max(0, Math.floor((sleepTimerEnd - Date.now()) / 1000));
    if (remaining <= 0) {
      get().pause();
      get().clearSleepTimer();
    } else {
      set({ sleepTimerRemaining: remaining });
    }
  },

  updateProgress: (position, duration) => {
    // Reject NaN/Infinity and normalize the UI's millisecond-based timeline.
    if (!Number.isFinite(position) || !Number.isFinite(duration)) return;
    const safeDuration = Math.max(0, duration);
    const safePosition = Math.max(0, safeDuration > 0 ? Math.min(position, safeDuration) : position);
    const { position: prevPosition, duration: prevDuration } = get();
    if (prevPosition === safePosition && prevDuration === safeDuration) return;
    set({ position: safePosition, duration: safeDuration });
  },

  updateStatus: (status) => {
    const previous = get().status;
    set({ status });
    if (previous !== status) playbackDiagnostics.record('playback.status', { level: status === 'error' ? 'error' : 'info', engine: get().playbackEngine, details: { previousStatus: previous, status } });
  },

  resetPlayer: () => {
    loadRequestId += 1;
    transportCommandInFlight = false;
    if (get().playbackEngine === 'foreground-service') foregroundPlaybackAdapter.stop();
    else void audioService.unload();
    set({
      currentTrack: null,
      status: 'idle',
      playbackError: null,
      position: 0,
      duration: 0,
      queue: [],
      originalQueue: [],
      currentIndex: -1,
      isShuffled: false,
      repeatMode: 'off',
      sleepTimerEnd: null,
      sleepTimerRemaining: 0,
    });
  },

  persistPlaybackSession: async () => {
    const state = get();
    try {
      await PlaybackSessionStorage.save({
        queue: state.queue,
        currentIndex: state.currentIndex,
        position: state.position,
        duration: state.duration,
        playbackSpeed: state.playbackSpeed,
        volume: state.volume,
        isMuted: state.isMuted,
        isShuffled: state.isShuffled,
        repeatMode: state.repeatMode,
      });
    } catch (error) {
      playbackDiagnostics.record('session.persist.failure', {
        level: 'warning',
        engine: state.playbackEngine,
        details: { reason: error instanceof Error ? error.name : 'storage_error' },
      });
    }
  },

  restorePlaybackSession: async () => {
    try {
      const saved = await PlaybackSessionStorage.load();
      if (!saved || saved.queue.length === 0 || saved.currentIndex < 0) return false;
      const currentTrack = saved.queue[saved.currentIndex] ?? null;
      if (!currentTrack) return false;
      // Restore metadata and position only. Never auto-start audio on cold launch.
      restoredPositionPending = saved.position > 0;
      set({
        queue: saved.queue,
        originalQueue: [...saved.queue],
        currentIndex: saved.currentIndex,
        currentTrack,
        position: saved.duration > 0 ? Math.min(saved.position, saved.duration) : saved.position,
        duration: saved.duration,
        playbackSpeed: saved.playbackSpeed,
        volume: saved.volume,
        isMuted: saved.isMuted,
        isShuffled: saved.isShuffled,
        repeatMode: saved.repeatMode,
        status: 'paused',
        playbackError: null,
      });
      playbackDiagnostics.record('session.restore.success', {
        engine: get().playbackEngine,
        details: { queueLength: saved.queue.length },
      });
      return true;
    } catch (error) {
      playbackDiagnostics.record('session.restore.failure', {
        level: 'warning',
        engine: get().playbackEngine,
        details: { reason: error instanceof Error ? error.name : 'storage_error' },
      });
      return false;
    }
  },

  setPlaybackEngine: async (engine) => {
    if (engine === get().playbackEngine) return;
    if (engine === 'foreground-service' && get().queue.some((track) => track.type !== 'audio')) {
      const message = 'Foreground-service mode requires an audio-only queue.';
      set({ playbackError: message });
      playbackDiagnostics.record('engine.switch.rejected', { level: 'warning', engine, details: { reason: 'video_in_queue' } });
      throw new Error(message);
    }
    loadRequestId += 1;
    try {
      if (get().playbackEngine === 'foreground-service') {
        foregroundStatusGeneration += 1;
        unsubscribeForegroundStatus?.();
        unsubscribeForegroundStatus = null;
        foregroundPlaybackAdapter.stop();
      } else {
        await audioService.stop();
        await audioService.unload();
      }
      if (engine === 'foreground-service') {
        set({ playbackEngine: engine, position: 0, duration: 0, status: 'idle', playbackError: null });
        playbackDiagnostics.record('engine.switch.success', { engine });
        syncForegroundQueue();
        const statusGeneration = ++foregroundStatusGeneration;
        unsubscribeForegroundStatus = foregroundPlaybackAdapter.subscribeStatus((nativeStatus) => {
          // Reject callbacks queued by a previous engine session, even if the user has switched
          // away and back to foreground-service before that callback is delivered.
          if (statusGeneration !== foregroundStatusGeneration || get().playbackEngine !== 'foreground-service') return;
          const selectedTrack = get().currentTrack;
          if (nativeStatus.uri && selectedTrack && nativeStatus.uri !== selectedTrack.url) {
            playbackDiagnostics.record('foreground.status.ignored', { level: 'warning', engine: 'foreground-service', details: { reason: 'track_uri_mismatch' } });
            return;
          }
          const nativeState = mapForegroundStatus(nativeStatus.state);
          const previousState = get().status;
          if (previousState !== nativeState) playbackDiagnostics.record('foreground.status', { level: nativeState === 'error' ? 'error' : 'info', engine: 'foreground-service', details: { previousStatus: previousState, status: nativeState } });
          const finiteNonNegative = (value: number | undefined) =>
            typeof value === 'number' && Number.isFinite(value) ? Math.max(0, value) : 0;
          const matchedIndex = nativeStatus.uri ? get().queue.findIndex((track) => track.url === nativeStatus.uri) : -1;
          set((state) => ({
            status: nativeState,
            position: finiteNonNegative(nativeStatus.positionMs),
            duration: finiteNonNegative(nativeStatus.durationMs),
            ...(matchedIndex >= 0 ? { currentIndex: matchedIndex, currentTrack: state.queue[matchedIndex] } : {}),
            ...(nativeStatus.active === false || nativeState === 'stopped' || nativeState === 'ended'
              ? { currentTrack: null, position: 0, duration: 0, currentIndex: -1 }
              : {}),
            ...(nativeState === 'error' ? { playbackError: 'Native foreground playback reported an error.' } : {}),
          }));
        });
      } else {
        foregroundStatusGeneration += 1;
        unsubscribeForegroundStatus?.();
        unsubscribeForegroundStatus = null;
        set({ playbackEngine: engine, position: 0, duration: 0, status: 'idle', playbackError: null });
        playbackDiagnostics.record('engine.switch.success', { engine });
      }
    } catch (error) {
      set({ playbackError: error instanceof Error ? error.message : String(error) });
      playbackDiagnostics.record('engine.switch.failure', { level: 'error', engine });
      throw error;
    }
  },
  });
});
