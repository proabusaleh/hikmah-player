# Hikmah Player Privacy Policy — Draft

**Last updated:** [INSERT DATE]

> Before publishing: replace the contact placeholder, confirm every statement against the shipped app and its dependencies, and host this document at a public HTTPS URL. Do not submit this draft as a final policy until reviewed.

## Overview

Hikmah Player is designed to play media that a user selects or makes available from their device. The app does not require an account to use its local media-player features.

## Media and device access

When you grant permission or choose files through the system picker, the app accesses the media and files needed for playback and library features. Media may be indexed or cached locally so that the app can display a library, remember playback progress, and support offline playback. The app should not access media outside the permissions or files you grant.

## Local app data

Settings, playlists, favorites, playback history, and related app state may be stored on your device. Uninstalling the app may remove app-local data and downloaded files, depending on the operating system and storage location.

## Network access and updates

The app may use network access for app updates and other features described in the current release. This draft does not claim that the app has no network traffic. Review the shipped dependencies and update configuration before publishing this policy.

## Sharing and advertising

This draft does not document any third-party analytics, advertising, or crash-reporting service as active. Verify the current build and dependencies before making a final statement about third-party data sharing.

## Children's privacy

Hikmah Player is not intended to knowingly collect personal information from children. The final policy should be updated to reflect the app's actual audience and applicable laws.

## Security and retention

Local data remains on the device unless a feature or platform service sends data elsewhere. Users can remove local app data by clearing storage or uninstalling the app, subject to operating-system behavior.

## Changes to this policy

This policy may be updated when app functionality or legal requirements change. The publication date should be updated whenever the policy changes.

## Contact

Privacy questions: **[ADD A REAL SUPPORT EMAIL OR WEBSITE BEFORE PUBLISHING]**
