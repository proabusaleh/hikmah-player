package expo.modules.hikmahaudioeffects

import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Build
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

/** Android audio effects attached to a specific player audio session.
 * The app must pass the real session ID from its playback engine. Never use a
 * guessed ID: effects can otherwise attach to the wrong output or fail silently.
 */
class HikmahAudioEffectsModule : Module() {
  private var equalizer: Equalizer? = null
  private var bassBoost: BassBoost? = null
  private var activeSessionId: Int? = null

  override fun definition() = ModuleDefinition {
    Name("HikmahAudioEffects")

    Function("getCapabilities") {
      mapOf(
        "platform" to "android",
        "supported" to (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT),
        "equalizer" to (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT),
        "bassBoost" to (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT),
        "requiresAudioSessionId" to true
      )
    }

    AsyncFunction("applyEffects") { sessionId: Int, presetLevels: List<Double>, bassEnabled: Boolean, bassLevel: Int ->
      if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
        throw IllegalStateException("Audio effects are not supported on this Android version.")
      }
      if (sessionId <= 0) {
        throw IllegalArgumentException("A valid playback audio session ID is required.")
      }
      if (bassLevel !in 0..100) {
        throw IllegalArgumentException("Bass boost level must be between 0 and 100.")
      }

      synchronized(this) {
        if (activeSessionId != sessionId) releaseEffects()
        if (equalizer == null) equalizer = Equalizer(0, sessionId)
        if (bassBoost == null) bassBoost = BassBoost(0, sessionId)
        val eq = equalizer ?: throw IllegalStateException("Equalizer could not be initialized.")
        val bass = bassBoost ?: throw IllegalStateException("Bass boost could not be initialized.")
        val range = eq.bandLevelRange
        val bandCount = eq.numberOfBands.toInt()
        for (band in 0 until minOf(bandCount, presetLevels.size)) {
          val normalized = presetLevels[band].coerceIn(-1.0, 1.0)
          val level = (range[0] + ((normalized + 1.0) / 2.0) * (range[1] - range[0])).toInt()
          eq.setBandLevel(band.toShort(), level.toShort())
        }
        eq.enabled = presetLevels.isNotEmpty()
        bass.setStrength((bassLevel.coerceIn(0, 100) * 10).toShort())
        bass.enabled = bassEnabled && bassLevel > 0
        activeSessionId = sessionId
        mapOf(
          "applied" to true,
          "sessionId" to sessionId,
          "equalizerEnabled" to eq.enabled,
          "bassBoostEnabled" to bass.enabled,
          "bandsApplied" to minOf(bandCount, presetLevels.size)
        )
      }
    }

    Function("release") {
      synchronized(this) { releaseEffects() }
      true
    }

    OnDestroy {
      synchronized(this) { releaseEffects() }
    }
  }

  private fun releaseEffects() {
    try { equalizer?.release() } catch (_: Exception) { }
    try { bassBoost?.release() } catch (_: Exception) { }
    equalizer = null
    bassBoost = null
    activeSessionId = null
  }
}
