package expo.modules.hikmahnativeplayer

import android.media.AudioAttributes
import android.media.AudioManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.net.Uri
import android.os.Build
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.IOException

/** Phase 12 native-player proof of concept. This owns its MediaPlayer and exposes its real audio session ID. */
class HikmahNativePlayerModule : Module() {
  private var player: MediaPlayer? = null
  private var loadedUri: String? = null
  private var audioManager: AudioManager? = null
  private var hasAudioFocus = false
  private var resumeAfterTransientLoss = false
  private var receiverContext: Context? = null
  private var noisyReceiverRegistered = false
  private var actionReceiverRegistered = false
  private var mediaSession: MediaSession? = null
  private var notificationManager: NotificationManager? = null
  private val notificationId = 7318
  private val notificationChannelId = "hikmah_player_playback"
  private var trackTitle = "Hikmah Player"
  private var trackArtist = "Now playing"
  private var trackAlbum = ""

  private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
    val active = player
    when (change) {
      AudioManager.AUDIOFOCUS_GAIN -> {
        try { active?.setVolume(1f, 1f) } catch (_: Exception) { }
        if (resumeAfterTransientLoss && active != null) {
          try { active.start(); sendEvent("playbackStatus", mapOf("state" to "playing", "reason" to "audio_focus_gained")) } catch (_: Exception) { }
        }
        resumeAfterTransientLoss = false
        sendEvent("audioFocus", mapOf("state" to "gained"))
      }
      AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
        resumeAfterTransientLoss = active?.isPlaying == true
        try { if (active?.isPlaying == true) active.pause() } catch (_: Exception) { }
        sendEvent("playbackStatus", mapOf("state" to "paused", "reason" to "audio_focus_transient_loss"))
        sendEvent("audioFocus", mapOf("state" to "transient_loss"))
      }
      AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
        try { active?.setVolume(0.2f, 0.2f) } catch (_: Exception) { }
        sendEvent("audioFocus", mapOf("state" to "ducked"))
      }
      AudioManager.AUDIOFOCUS_LOSS -> {
        resumeAfterTransientLoss = false
        try { if (active?.isPlaying == true) active.pause() } catch (_: Exception) { }
        hasAudioFocus = false
        sendEvent("playbackStatus", mapOf("state" to "paused", "reason" to "audio_focus_loss"))
        sendEvent("audioFocus", mapOf("state" to "lost"))
      }
    }
  }

  private val mediaActionReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      val action = intent?.getStringExtra("action") ?: return
      val payload = mutableMapOf<String, Any>("action" to action)
      intent.getStringExtra("source")?.let { payload["source"] = it }
      if (intent.hasExtra("positionMs")) payload["positionMs"] = intent.getLongExtra("positionMs", 0L)
      sendEvent("mediaSessionAction", payload)
    }
  }

  private val noisyReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
        try { if (player?.isPlaying == true) player?.pause() } catch (_: Exception) { }
        resumeAfterTransientLoss = false
        sendEvent("playbackStatus", mapOf("state" to "paused", "reason" to "headphones_disconnected"))
      }
    }
  }

  override fun definition() = ModuleDefinition {
    Name("HikmahNativePlayer")

    Events("playbackStatus", "audioFocus", "mediaSessionAction")

    OnCreate {
      val context = appContext.reactContext
      audioManager = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
      notificationManager = context?.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      ensureNotificationChannel(context)
      ensureMediaSession(context)
      if (context != null && !noisyReceiverRegistered) {
        try {
          val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
          if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(noisyReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
          else context.registerReceiver(noisyReceiver, filter)
          receiverContext = context
          noisyReceiverRegistered = true
          val actionFilter = IntentFilter("${context.packageName}.HIKMAH_MEDIA_ACTION")
          if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(mediaActionReceiver, actionFilter, Context.RECEIVER_NOT_EXPORTED)
          else context.registerReceiver(mediaActionReceiver, actionFilter)
          actionReceiverRegistered = true
        } catch (_: Exception) { }
      }
    }

    AsyncFunction("load") { uri: String ->
      require(uri.isNotBlank()) { "A non-empty media URI is required." }
      val context = appContext.reactContext ?: throw IllegalStateException("React context is unavailable.")
      releasePlayer()
      val next = MediaPlayer()
      try {
        next.setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        )
        next.setDataSource(context, Uri.parse(uri))
        next.prepare()
        next.setOnCompletionListener { sendEvent("playbackStatus", mapOf("state" to "ended")) }
        next.setOnErrorListener { _, what, extra ->
          sendEvent("playbackStatus", mapOf("state" to "error", "what" to what, "extra" to extra))
          true
        }
        player = next
        loadedUri = uri
        mapOf(
          "loaded" to true,
          "durationMs" to next.duration,
          "audioSessionId" to next.audioSessionId,
          "uri" to uri
        )
      } catch (error: Exception) {
        try { next.release() } catch (_: Exception) { }
        throw IOException("Unable to load media URI: ${error.message}", error)
      }
    }

    Function("play") {
      val active = requirePlayer()
      val manager = audioManager
      if (manager != null) {
        @Suppress("DEPRECATION")
        val focusResult = manager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        if (focusResult != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
          sendEvent("audioFocus", mapOf("state" to "request_denied"))
          throw IllegalStateException("Audio focus request was not granted.")
        }
        hasAudioFocus = true
      }
      if (!active.isPlaying) active.start()
      sendEvent("playbackStatus", mapOf("state" to "playing", "audioSessionId" to active.audioSessionId))
      updateMediaSessionState(PlaybackState.STATE_PLAYING)
      updatePlaybackNotification()
      true
    }

    Function("pause") {
      val active = requirePlayer()
      if (active.isPlaying) active.pause()
      sendEvent("playbackStatus", mapOf("state" to "paused", "audioSessionId" to active.audioSessionId))
      updateMediaSessionState(PlaybackState.STATE_PAUSED)
      updatePlaybackNotification()
      true
    }

    Function("stop") {
      val active = requirePlayer()
      if (active.isPlaying) active.pause()
      active.seekTo(0)
      sendEvent("playbackStatus", mapOf("state" to "stopped", "audioSessionId" to active.audioSessionId))
      updateMediaSessionState(PlaybackState.STATE_STOPPED)
      updatePlaybackNotification()
      true
    }

    Function("seekTo") { positionMs: Int ->
      val active = requirePlayer()
      active.seekTo(positionMs.coerceAtLeast(0))
      mapOf("positionMs" to active.currentPosition, "durationMs" to active.duration)
    }

    AsyncFunction("setMediaMetadata") { title: String, artist: String, album: String ->
      trackTitle = title.take(200).ifBlank { "Hikmah Player" }
      trackArtist = artist.take(200).ifBlank { "Unknown artist" }
      trackAlbum = album.take(200)
      updateMediaMetadata()
      updatePlaybackNotification()
      true
    }

    Function("setMediaSessionActive") { active: Boolean ->
      mediaSession?.isActive = active
      if (active) updatePlaybackNotification() else notificationManager?.cancel(notificationId)
      active
    }

    Function("updateMediaSessionState") { state: String ->
      val playbackState = when (state.lowercase()) {
        "playing" -> PlaybackState.STATE_PLAYING
        "paused" -> PlaybackState.STATE_PAUSED
        "buffering" -> PlaybackState.STATE_BUFFERING
        "stopped" -> PlaybackState.STATE_STOPPED
        "ended" -> PlaybackState.STATE_STOPPED
        else -> PlaybackState.STATE_NONE
      }
      updateMediaSessionState(playbackState)
      updatePlaybackNotification()
      true
    }

    Function("startForegroundPlayback") { uri: String, title: String, artist: String ->
      require(uri.isNotBlank()) { "A non-empty media URI is required." }
      val context = appContext.reactContext ?: throw IllegalStateException("React context is unavailable.")
      val intent = Intent(context, HikmahPlaybackService::class.java)
        .setAction(HikmahPlaybackService.ACTION_START)
        .putExtra(HikmahPlaybackService.EXTRA_URI, uri)
        .putExtra(HikmahPlaybackService.EXTRA_TITLE, title)
        .putExtra(HikmahPlaybackService.EXTRA_ARTIST, artist)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
      true
    }

    Function("getForegroundPlaybackStatus") {
      HikmahPlaybackService.getStatusSnapshot()
    }

    Function("sendForegroundPlaybackCommand") { action: String, positionMs: Double ->
      val context = appContext.reactContext ?: throw IllegalStateException("React context is unavailable.")
      val serviceAction = when (action.lowercase()) {
        "play" -> HikmahPlaybackService.ACTION_PLAY
        "pause" -> HikmahPlaybackService.ACTION_PAUSE
        "seek" -> HikmahPlaybackService.ACTION_SEEK
        "stop" -> HikmahPlaybackService.ACTION_STOP
        "next" -> HikmahPlaybackService.ACTION_NEXT
        "previous" -> HikmahPlaybackService.ACTION_PREVIOUS
        else -> throw IllegalArgumentException("Unsupported foreground playback command: $action")
      }
      val intent = Intent(context, HikmahPlaybackService::class.java).setAction(serviceAction)
        .putExtra(HikmahPlaybackService.EXTRA_POSITION, positionMs.toLong().coerceAtLeast(0L))
      // Commands target an already-running service. Use startService here so a stale STOP command
      // cannot trigger Android's foreground-service start timeout when no service is active.
      context.startService(intent)
      true
    }

    Function("getStatus") {
      val active = player ?: return@Function mapOf("loaded" to false)
      mapOf(
        "loaded" to true,
        "playing" to active.isPlaying,
        "positionMs" to active.currentPosition,
        "durationMs" to active.duration,
        "audioSessionId" to active.audioSessionId,
        "uri" to loadedUri
      )
    }

    Function("getAudioSessionId") {
      val active = player ?: return@Function 0
      active.audioSessionId
    }

    Function("release") {
      releasePlayer()
      true
    }

    Function("abandonAudioFocus") { abandonFocus(); true }
    OnDestroy { releasePlayer(); unregisterNoisyReceiver(); releaseMediaSession() }
  }

  private fun ensureNotificationChannel(context: Context?) {
    if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
    val channel = NotificationChannel(notificationChannelId, "Media playback", NotificationManager.IMPORTANCE_LOW).apply {
      description = "Playback controls for Hikmah Player"
      setShowBadge(false)
    }
    manager.createNotificationChannel(channel)
  }

  private fun ensureMediaSession(context: Context?) {
    if (context == null || mediaSession != null) return
    mediaSession = MediaSession(context, "HikmahPlayerMediaSession").apply {
      setCallback(object : MediaSession.Callback() {
        override fun onPlay() { sendEvent("mediaSessionAction", mapOf("action" to "play")) }
        override fun onPause() { sendEvent("mediaSessionAction", mapOf("action" to "pause")) }
        override fun onStop() { sendEvent("mediaSessionAction", mapOf("action" to "stop")) }
        override fun onSkipToNext() { sendEvent("mediaSessionAction", mapOf("action" to "next")) }
        override fun onSkipToPrevious() { sendEvent("mediaSessionAction", mapOf("action" to "previous")) }
        override fun onSeekTo(pos: Long) { sendEvent("mediaSessionAction", mapOf("action" to "seek", "positionMs" to pos)) }
      })
      isActive = true
    }
    updateMediaMetadata()
    updateMediaSessionState(if (player?.isPlaying == true) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED)
  }

  private fun updateMediaMetadata() {
    mediaSession?.setMetadata(MediaMetadata.Builder()
      .putString(MediaMetadata.METADATA_KEY_TITLE, trackTitle)
      .putString(MediaMetadata.METADATA_KEY_ARTIST, trackArtist)
      .putString(MediaMetadata.METADATA_KEY_ALBUM, trackAlbum)
      .build())
  }

  private fun updateMediaSessionState(state: Int) {
    val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
      PlaybackState.ACTION_STOP or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO
    val position = try { player?.currentPosition?.toLong() ?: 0L } catch (_: Exception) { 0L }
    mediaSession?.setPlaybackState(PlaybackState.Builder().setActions(actions).setState(state, position, if (state == PlaybackState.STATE_PLAYING) 1f else 0f).build())
  }

  private fun updatePlaybackNotification() {
    val context = appContext.reactContext ?: return
    val session = mediaSession ?: return
    val manager = notificationManager ?: return
    val playing = try { player?.isPlaying == true } catch (_: Exception) { false }
    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
    val contentIntent = launchIntent?.let { PendingIntent.getActivity(context, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0) }
    val playPauseAction = if (playing) Notification.Action.Builder(android.R.drawable.ic_media_pause, "Pause", actionPendingIntent(context, "pause", 2)).build()
      else Notification.Action.Builder(android.R.drawable.ic_media_play, "Play", actionPendingIntent(context, "play", 1)).build()
    val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      Notification.Builder(context, notificationChannelId)
    } else {
      @Suppress("DEPRECATION")
      Notification.Builder(context)
    }.setSmallIcon(android.R.drawable.ic_media_play)
      .setContentTitle(trackTitle)
      .setContentText(trackArtist)
      .setContentIntent(contentIntent)
      .setOngoing(playing)
      .setVisibility(Notification.VISIBILITY_PUBLIC)
      .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", actionPendingIntent(context, "previous", 3)).build())
      .addAction(playPauseAction)
      .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", actionPendingIntent(context, "next", 4)).build())
      .setStyle(Notification.MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2))
      .build()
    try { manager.notify(notificationId, notification) } catch (_: Exception) { }
  }

  private fun actionPendingIntent(context: Context, action: String, requestCode: Int): PendingIntent {
    val intent = Intent("${context.packageName}.HIKMAH_MEDIA_ACTION").setPackage(context.packageName).putExtra("action", action)
    return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
  }

  private fun releaseMediaSession() {
    try { mediaSession?.isActive = false; mediaSession?.release() } catch (_: Exception) { }
    mediaSession = null
    try { notificationManager?.cancel(notificationId) } catch (_: Exception) { }
  }

  private fun requirePlayer(): MediaPlayer = player ?: throw IllegalStateException("No media is loaded. Call load(uri) first.")

  private fun releasePlayer() {
    try { player?.stop() } catch (_: Exception) { }
    try { player?.release() } catch (_: Exception) { }
    player = null
    loadedUri = null
    abandonFocus()
  }

  @Suppress("DEPRECATION")
  private fun abandonFocus() {
    try { if (hasAudioFocus) audioManager?.abandonAudioFocus(focusListener) } catch (_: Exception) { }
    hasAudioFocus = false
    resumeAfterTransientLoss = false
  }

  private fun unregisterNoisyReceiver() {
    val context = receiverContext
    if (context != null && noisyReceiverRegistered) {
      try { context.unregisterReceiver(noisyReceiver) } catch (_: Exception) { }
    }
    receiverContext = null
    noisyReceiverRegistered = false
    if (context != null && actionReceiverRegistered) {
      try { context.unregisterReceiver(mediaActionReceiver) } catch (_: Exception) { }
    }
    actionReceiverRegistered = false
  }
}
