package expo.modules.hikmahnativeplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.IBinder

/** Opt-in foreground playback owner. It intentionally has its own player instance. */
class HikmahPlaybackService : Service() {
  private var player: MediaPlayer? = null
  private var session: MediaSession? = null
  private var title = "Hikmah Player"
  private var artist = "Now playing"
  private var sourceUri: String? = null
  private var playbackStateName: String = "idle"
  private val channelId = "hikmah_foreground_playback"
  private val notificationId = 7319

  override fun onCreate() {
    super.onCreate()
    instance = this
    createChannel()
    session = MediaSession(this, "HikmahForegroundSession").apply {
      setCallback(object : MediaSession.Callback() {
        override fun onPlay() { play() }
        override fun onPause() { pause() }
        override fun onStop() { stopPlayback(); emitMediaAction("stop") }
        override fun onSkipToNext() { emitMediaAction("next") }
        override fun onSkipToPrevious() { emitMediaAction("previous") }
        override fun onSeekTo(pos: Long) { seek(pos); emitMediaAction("seek", pos) }
      })
      isActive = true
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action ?: ACTION_START) {
      ACTION_START -> {
        title = intent?.getStringExtra(EXTRA_TITLE)?.take(200)?.ifBlank { "Hikmah Player" } ?: "Hikmah Player"
        artist = intent?.getStringExtra(EXTRA_ARTIST)?.take(200)?.ifBlank { "Unknown artist" } ?: "Unknown artist"
        val uri = intent?.getStringExtra(EXTRA_URI)
        if (uri.isNullOrBlank()) { stopSelf(); return START_NOT_STICKY }
        startForeground(notificationId, buildNotification(false))
        if (uri != sourceUri) prepare(uri) else play()
      }
      ACTION_PLAY -> play()
      ACTION_PAUSE -> pause()
      ACTION_SEEK -> seek(intent?.getLongExtra(EXTRA_POSITION, 0L) ?: 0L)
      ACTION_STOP -> { stopPlayback(); emitMediaAction("stop") }
      ACTION_NEXT -> emitMediaAction("next")
      ACTION_PREVIOUS -> emitMediaAction("previous")
    }
    return START_NOT_STICKY
  }

  private fun prepare(uri: String) {
    releasePlayer()
    sourceUri = uri
    val next = MediaPlayer()
    player = next
    try {
      next.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
      next.setDataSource(this, Uri.parse(uri))
      next.setOnPreparedListener { mp -> mp.start(); playbackStateName = "playing"; updateSession(PlaybackState.STATE_PLAYING); updateNotification(true) }
      next.setOnCompletionListener { playbackStateName = "ended"; updateSession(PlaybackState.STATE_STOPPED); updateNotification(false) }
      next.setOnErrorListener { _, _, _ -> playbackStateName = "error"; stopPlayback(); true }
      next.prepareAsync()
      session?.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title).putString(MediaMetadata.METADATA_KEY_ARTIST, artist).build())
      playbackStateName = "buffering"
      updateSession(PlaybackState.STATE_BUFFERING)
    } catch (_: Exception) { stopPlayback() }
  }

  private fun play() { try { val p = player; if (p != null && !p.isPlaying) { p.start(); playbackStateName = "playing"; updateSession(PlaybackState.STATE_PLAYING); updateNotification(true) } } catch (_: Exception) {} }
  private fun pause() { try { val p = player; if (p?.isPlaying == true) p.pause(); playbackStateName = "paused"; updateSession(PlaybackState.STATE_PAUSED); updateNotification(false) } catch (_: Exception) {} }
  private fun seek(positionMs: Long) { try { val p = player; if (p != null) p.seekTo(positionMs.coerceAtLeast(0).coerceAtMost((p.duration.takeIf { it > 0 } ?: Int.MAX_VALUE).toLong()).toInt()) } catch (_: Exception) {} }
  private fun stopPlayback() { releasePlayer(); sourceUri = null; playbackStateName = "stopped"; updateSession(PlaybackState.STATE_STOPPED); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }

  private fun statusSnapshot(): Map<String, Any?> {
    val p = player
    val position = try { p?.currentPosition?.toLong() ?: 0L } catch (_: Exception) { 0L }
    val duration = try { p?.duration?.toLong() ?: 0L } catch (_: Exception) { 0L }
    val prepared = p != null && (playbackStateName == "playing" || playbackStateName == "paused" || playbackStateName == "ended")
    return mapOf("active" to (sourceUri != null), "loaded" to prepared, "playing" to (playbackStateName == "playing"), "state" to playbackStateName, "positionMs" to position, "durationMs" to duration, "uri" to sourceUri, "title" to title, "artist" to artist)
  }
  private fun releasePlayer() { try { player?.setOnPreparedListener(null); player?.stop() } catch (_: Exception) {}; try { player?.release() } catch (_: Exception) {}; player = null }

  private fun updateSession(state: Int) {
    val actions = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS
    val position = try { player?.currentPosition?.toLong() ?: 0L } catch (_: Exception) { 0L }
    session?.setPlaybackState(PlaybackState.Builder().setActions(actions).setState(state, position, if (state == PlaybackState.STATE_PLAYING) 1f else 0f).build())
  }

  private fun buildNotification(playing: Boolean): Notification {
    val launch = packageManager.getLaunchIntentForPackage(packageName)
    val content = launch?.let { PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE) }
    val toggleAction = if (playing) ACTION_PAUSE else ACTION_PLAY
    val toggleIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
    val toggleLabel = if (playing) "Pause" else "Play"
    val toggle = Notification.Action.Builder(toggleIcon, toggleLabel, commandIntent(toggleAction, 2)).build()
    val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else @Suppress("DEPRECATION") Notification.Builder(this)
    return builder.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(title).setContentText(artist).setContentIntent(content).setOngoing(playing).setVisibility(Notification.VISIBILITY_PUBLIC)
      .addAction(Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", commandIntent(ACTION_PREVIOUS, 4)).build())
      .addAction(toggle)
      .addAction(Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", commandIntent(ACTION_NEXT, 5)).build())
      .setStyle(Notification.MediaStyle().apply { session?.sessionToken?.let { setMediaSession(it) } })
      .build()
  }
  private fun updateNotification(playing: Boolean) { try { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(notificationId, buildNotification(playing)) } catch (_: Exception) {} }
  private fun emitMediaAction(action: String, positionMs: Long? = null) {
    try {
      val event = Intent("${packageName}.HIKMAH_MEDIA_ACTION").setPackage(packageName).putExtra("action", action).putExtra("source", "foreground_service")
      if (positionMs != null) event.putExtra("positionMs", positionMs)
      sendBroadcast(event)
    } catch (_: Exception) { }
  }
  private fun commandIntent(action: String, code: Int) = PendingIntent.getService(this, code, Intent(this, HikmahPlaybackService::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  private fun createChannel() { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(channelId, "Hikmah playback service", NotificationManager.IMPORTANCE_LOW).apply { description = "Foreground media playback controls"; setShowBadge(false) }) }
  override fun onDestroy() { releasePlayer(); playbackStateName = "idle"; if (instance === this) instance = null; try { session?.isActive = false; session?.release() } catch (_: Exception) {}; session = null; super.onDestroy() }
  override fun onBind(intent: Intent?): IBinder? = null

  companion object {
    @Volatile private var instance: HikmahPlaybackService? = null
    fun getStatusSnapshot(): Map<String, Any?> = instance?.statusSnapshot() ?: mapOf("active" to false, "loaded" to false, "playing" to false, "state" to "idle", "positionMs" to 0L, "durationMs" to 0L, "uri" to null, "title" to "Hikmah Player", "artist" to "Unknown artist")
    const val ACTION_START = "expo.modules.hikmahnativeplayer.START"
    const val ACTION_PLAY = "expo.modules.hikmahnativeplayer.PLAY"
    const val ACTION_PAUSE = "expo.modules.hikmahnativeplayer.PAUSE"
    const val ACTION_SEEK = "expo.modules.hikmahnativeplayer.SEEK"
    const val ACTION_STOP = "expo.modules.hikmahnativeplayer.STOP"
    const val ACTION_NEXT = "expo.modules.hikmahnativeplayer.NEXT"
    const val ACTION_PREVIOUS = "expo.modules.hikmahnativeplayer.PREVIOUS"
    const val EXTRA_URI = "uri"; const val EXTRA_TITLE = "title"; const val EXTRA_ARTIST = "artist"; const val EXTRA_POSITION = "positionMs"
  }
}
