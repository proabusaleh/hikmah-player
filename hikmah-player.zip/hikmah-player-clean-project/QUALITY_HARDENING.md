# Hikmah Player reliability hardening

This pass adds targeted safeguards in the current architecture. It is not a substitute for device-level validation.

## Implemented in this pass

- **Playback:** the player store now exposes `playbackError`, maps common playback failures to actionable copy, retries a failed track when the user presses play, and ignores stale load completions after a newer track request. The audio service checks app-owned `file://` sources before handing them to the decoder. `content://` sources are left to Android's media provider.
- **Storage and library identity:** scanner IDs are now stable for the same path, preventing repeated scans from creating new entries. `LibraryDatabase` supports id/path-aware upserts and batched writes while preserving user-owned fields (favorites, playlists, progress and play count).
- **Downloads:** queue initialization skips malformed persisted entries; enqueue validates source URL schemes; pause/cancel races are guarded so a completed native promise cannot resurrect a cancelled task; cancellation removes completed/partial task files when their location is known; final failures include guidance for common storage and network errors.
- **State:** transient player errors remain in the player store, while user preferences continue to be persisted separately in the settings store. Do not persist playback status or native player objects.
- **Recovery:** missing app-owned local files produce a specific recoverable player message rather than a generic decoder failure.

## Still requires implementation or platform verification

- Expo/native audio interruption events (phone calls, Bluetooth route changes, headphone unplug) need device-level testing and may require a dedicated interruption adapter depending on the installed Expo SDK's event support.
- Free-space checks are not treated as authoritative: available disk-space APIs differ by platform and can race with other apps. Test low-storage behaviour on physical devices and keep errors recoverable.
- Android scoped-storage and iOS limited-library permission behaviour must be tested on physical devices. Reconcile deleted assets during refresh, not by deleting user metadata based only on one permission-limited scan.
- Large-library performance needs profiling with realistic libraries (1k, 5k, 10k+ entries). AsyncStorage remains a JSON store and may need SQLite for larger datasets.
- Download resume across process death is not guaranteed by the current queue: queue state is persisted, but the native resumable download's resumable data is not. Interrupted downloads are safely re-queued rather than guaranteed to resume byte-for-byte.
- The app UI should render `usePlayerStore(s => s.playbackError)` with a Retry action and a Remove-from-library action for missing local files.

## Manual QA matrix

1. Start audio, background/foreground the app, lock/unlock, and verify playback state matches actual audio.
2. Play a video, background the app, return, and verify it does not show a false playing state.
3. Switch tracks rapidly; ensure the previous track's late load result never overwrites the latest selection.
4. Deny media permission, allow limited access, revoke access in system settings, and retry import.
5. Delete a file that is already in the library, then play it; verify the actionable missing-file message and recovery path.
6. Import the same media repeatedly and scan the same folder repeatedly; the library count should not grow with duplicates.
7. Import a large library and monitor UI responsiveness, memory use, and storage latency.
8. Queue several downloads; pause, resume, cancel during transfer, disable network, re-enable network, and force-close/reopen the app.
9. Simulate low storage on a test device and confirm failed downloads do not appear completed or playable.
10. Run `npm ci`, `npx expo install --check`, `npx tsc --noEmit`, `npm run lint`, and `npm test` in an environment with network access and Node 22.13+.
