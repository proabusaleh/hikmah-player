# Hikmah Player — Phase 3: Smart Playlists

## Included
- Recently Played: latest playback activity first, capped at 50 items.
- Most Played: highest play count first, with recent playback as a tie-breaker; items never played are excluded.
- Recently Added: newest library items first, excluding future timestamps; capped at 50 items.
- Favorites: media explicitly marked as a favorite.
- Smart lists are derived from existing library metadata at runtime. They are not copied into a second database and use no additional media storage.
- Library screen has a shortcut to the Smart Playlists screen.
- Selecting a smart playlist queues its audio items and starts playback. Video items remain in the library and are included in the playlist count, but are not placed in the audio queue.
- Unit tests cover sorting, filtering and future timestamps.

## Verification still required
Run `npm ci`, `npx tsc --noEmit`, `npm run lint`, and `npm test`. Then test on a physical device with an empty library, many media items, removed files, and a mix of audio and video. The archive has not been built or run on a device in this environment.
