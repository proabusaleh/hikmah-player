# Phase 46 — Separate Branded Assets & Integration

## What changed

This phase replaces the Expo/React demo artwork with Hikmah Player branded artwork and keeps each asset as an independent file rather than using a single collage.

### Individual files

- `assets/icons/icon.png` — 1024×1024 main app icon.
- `assets/images/android-icon-foreground.png` — transparent Android adaptive foreground.
- `assets/images/android-icon-background.png` — dedicated adaptive icon background.
- `assets/images/android-icon-monochrome.png` — monochrome Android icon.
- `assets/images/notification-icon.png` — dedicated transparent notification glyph.
- `assets/images/favicon.png` — standalone favicon.
- `assets/images/hikmah-mark.png` — transparent logo mark for app UI/animation.
- `assets/images/hikmah-splash-screen.png` — vertical splash artwork (1080×2400).
- `assets/images/hikmah-splash-banner.png` — horizontal brand artwork (1920×1080).
- `assets/images/onboarding-listen.png` — onboarding illustration 1.
- `assets/images/onboarding-library.png` — onboarding illustration 2.
- `assets/images/onboarding-offline.png` — onboarding illustration 3.
- `assets/images/tabIcons/home*.png` and `explore*.png` — separate tab icons at 1x/2x/3x.

Legacy `expo-logo.png`, `expo-badge*.png`, and `react-logo*.png` filenames are retained as compatibility assets for existing component imports, but their contents are Hikmah Player artwork, not Expo/React logos. The animated icon components now reference `hikmah-mark.png` directly.

## Integration notes

- `app.json` now points Android adaptive foreground to the dedicated transparent foreground asset.
- Native splash uses the dedicated transparent Hikmah mark rather than the full app icon tile.
- The app's splash route remains a code-rendered animated screen and continues to use the app icon. The large splash artwork files are separate assets available for onboarding/marketing and are not a screenshot of an app screen.
- Home, player, queue, and settings are functional React Native screens, not static images. They should not be replaced with a single generated collage.

## Validation

Run `npm run check:release`, `npm run check:rc`, and `npm run lint` after installing dependencies. Then build an Android preview APK and visually verify app icon, adaptive icon, notification icon, and splash on a physical device. Dependency install and native build were not performed as part of this asset-only phase.
