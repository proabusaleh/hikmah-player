import { usePlayerStore } from '@/store/usePlayerStore';
import type { MediaItem } from '@/types/media';
import { audioService } from '@/services/audio/audioService';
import { foregroundPlaybackAdapter } from '@/services/audio/foregroundPlaybackAdapter';

jest.mock('@/services/audio/audioService', () => ({
  audioService: {
    loadTrack: jest.fn().mockResolvedValue({ duration: 180 }),
    play: jest.fn().mockResolvedValue(undefined),
    pause: jest.fn().mockResolvedValue(undefined),
    stop: jest.fn().mockResolvedValue(undefined),
    unload: jest.fn().mockResolvedValue(undefined),
    seek: jest.fn().mockResolvedValue(undefined),
    setPlaybackSpeed: jest.fn().mockResolvedValue(undefined),
    setVolume: jest.fn().mockResolvedValue(undefined),
  },
}));

jest.mock('@/services/audio/foregroundPlaybackAdapter', () => ({
  foregroundPlaybackAdapter: {
    setQueue: jest.fn(),
    playTrackAt: jest.fn().mockResolvedValue(undefined),
    next: jest.fn().mockResolvedValue(undefined),
    previous: jest.fn().mockResolvedValue(undefined),
    play: jest.fn().mockResolvedValue(true),
    pause: jest.fn().mockResolvedValue(true),
    seekTo: jest.fn().mockResolvedValue(true),
    stop: jest.fn().mockReturnValue(true),
    subscribeStatus: jest.fn(() => jest.fn()),
  },
}));

const tracks: MediaItem[] = [
  { id: 'a', title: 'Audio A', url: 'https://example.test/a.mp3', duration: 180, type: 'audio', addedAt: 1 },
  { id: 'b', title: 'Audio B', url: 'https://example.test/b.mp3', duration: 200, type: 'audio', addedAt: 2 },
];

describe('playback engine integration contract', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    usePlayerStore.getState().resetPlayer();
  });

  it('routes track loading through the selected foreground adapter', async () => {
    usePlayerStore.getState().setQueue(tracks, 0);
    await usePlayerStore.getState().setPlaybackEngine('foreground-service');
    await usePlayerStore.getState().playTrackAtIndex(0);

    expect(foregroundPlaybackAdapter.setQueue).toHaveBeenCalledWith(tracks, 0);
    expect(foregroundPlaybackAdapter.playTrackAt).toHaveBeenCalledWith(0);
    expect(audioService.loadTrack).not.toHaveBeenCalled();
    expect(usePlayerStore.getState().currentTrack?.id).toBe('a');
  });

  it('rejects switching to foreground service when queue contains video', async () => {
    const mixedQueue = [tracks[0], { ...tracks[1], type: 'video' as const }];
    usePlayerStore.getState().setQueue(mixedQueue, 0);

    await expect(usePlayerStore.getState().setPlaybackEngine('foreground-service')).rejects.toThrow('audio-only queue');
    expect(usePlayerStore.getState().playbackEngine).toBe('expo-audio');
  });

  it('routes play/pause commands to only the selected engine', async () => {
    usePlayerStore.getState().setQueue(tracks, 0);
    await usePlayerStore.getState().setPlaybackEngine('foreground-service');
    await usePlayerStore.getState().playTrackAtIndex(0);
    await usePlayerStore.getState().pause();

    expect(foregroundPlaybackAdapter.pause).toHaveBeenCalledTimes(1);
    expect(audioService.pause).not.toHaveBeenCalled();
  });

  it('unsubscribes native status and stops native playback when switching back', async () => {
    usePlayerStore.getState().setQueue(tracks, 0);
    await usePlayerStore.getState().setPlaybackEngine('foreground-service');
    await usePlayerStore.getState().setPlaybackEngine('expo-audio');

    expect(foregroundPlaybackAdapter.stop).toHaveBeenCalledTimes(1);
    expect(usePlayerStore.getState().playbackEngine).toBe('expo-audio');
  });
});
