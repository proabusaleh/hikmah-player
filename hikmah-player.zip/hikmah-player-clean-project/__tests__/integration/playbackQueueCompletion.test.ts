import { usePlayerStore } from '@/store/usePlayerStore';
import type { MediaItem } from '@/types/media';
import { audioService } from '@/services/audio/audioService';
import { foregroundPlaybackAdapter } from '@/services/audio/foregroundPlaybackAdapter';
import { playbackDiagnostics } from '@/services/playback/playbackDiagnostics';

jest.mock('@/services/audio/audioService', () => ({
  audioService: {
    initialize: jest.fn().mockResolvedValue(undefined),
    loadTrack: jest.fn().mockResolvedValue({ duration: 180 }),
    play: jest.fn().mockResolvedValue(undefined),
    pause: jest.fn().mockResolvedValue(undefined),
    stop: jest.fn().mockResolvedValue(undefined),
    unload: jest.fn().mockResolvedValue(undefined),
    seek: jest.fn().mockResolvedValue(undefined),
    seekRelative: jest.fn().mockResolvedValue(undefined),
    setPlaybackSpeed: jest.fn().mockResolvedValue(undefined),
    setVolume: jest.fn().mockResolvedValue(undefined),
    addListener: jest.fn(() => jest.fn()),
    getStatus: jest.fn().mockResolvedValue({ position: 0, duration: 180 }),
  },
}));

jest.mock('@/services/audio/foregroundPlaybackAdapter', () => ({
  foregroundPlaybackAdapter: {
    setQueue: jest.fn(),
    playTrackAt: jest.fn().mockResolvedValue(undefined),
    next: jest.fn().mockResolvedValue(undefined),
    previous: jest.fn().mockResolvedValue(undefined),
    play: jest.fn().mockResolvedValue(true),
    pause: jest.fn().mockResolvedValue(true),
    seekTo: jest.fn().mockResolvedValue(true),
    stop: jest.fn().mockReturnValue(true),
    subscribeStatus: jest.fn(() => jest.fn()),
  },
}));

const queue: MediaItem[] = [
  { id: 'track-a', title: 'Track A', url: 'https://example.test/a.mp3', duration: 180, type: 'audio', addedAt: 1 },
  { id: 'track-b', title: 'Track B', url: 'https://example.test/b.mp3', duration: 200, type: 'audio', addedAt: 2 },
];

describe('playback queue completion integration', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    playbackDiagnostics.clear();
    usePlayerStore.getState().resetPlayer();
    usePlayerStore.setState({ playbackEngine: 'expo-audio', repeatMode: 'off' });
    jest.clearAllMocks();
  });

  it('advances to the next item and loads it when repeat is off', async () => {
    usePlayerStore.getState().setQueue(queue, 0);

    await usePlayerStore.getState().nextTrack();

    expect(usePlayerStore.getState().currentTrack?.id).toBe('track-b');
    expect(audioService.loadTrack).toHaveBeenCalledWith(queue[1], true);
  });

  it('restarts the current item for Repeat One', async () => {
    usePlayerStore.getState().setQueue(queue, 0);
    usePlayerStore.setState({ repeatMode: 'one' });

    await usePlayerStore.getState().nextTrack();

    expect(audioService.seek).toHaveBeenCalledWith(0);
    expect(audioService.play).toHaveBeenCalledTimes(1);
    expect(usePlayerStore.getState().currentIndex).toBe(0);
  });

  it('wraps from the last item to the first for Repeat All', async () => {
    usePlayerStore.getState().setQueue(queue, 1);
    usePlayerStore.setState({ repeatMode: 'all' });

    await usePlayerStore.getState().nextTrack();

    expect(usePlayerStore.getState().currentIndex).toBe(0);
    expect(usePlayerStore.getState().currentTrack?.id).toBe('track-a');
    expect(audioService.loadTrack).toHaveBeenCalledWith(queue[0], true);
  });

  it('ends normally after the last item when repeat is off', async () => {
    usePlayerStore.getState().setQueue(queue, 1);
    usePlayerStore.setState({ status: 'playing', position: 199000, playbackError: 'stale error' });

    await usePlayerStore.getState().nextTrack();

    expect(usePlayerStore.getState().status).toBe('stopped');
    expect(usePlayerStore.getState().position).toBe(0);
    expect(usePlayerStore.getState().playbackError).toBeNull();
    expect(playbackDiagnostics.snapshot().some((event) => event.event === 'queue.end')).toBe(true);
  });

  it('does nothing for an empty queue', async () => {
    await usePlayerStore.getState().nextTrack();

    expect(usePlayerStore.getState().currentTrack).toBeNull();
    expect(audioService.loadTrack).not.toHaveBeenCalled();
    expect(foregroundPlaybackAdapter.playTrackAt).not.toHaveBeenCalled();
  });
});
