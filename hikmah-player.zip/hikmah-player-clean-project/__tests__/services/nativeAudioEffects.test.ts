import { normalizeBassBoostLevel, isEqualizerPreset } from '../../services/audio/equalizerSettings';
import { getEqualizerPresetLevels } from '../../services/audio/nativeAudioEffects';

describe('native audio effects input validation', () => {
  it('clamps bass boost to the supported range', () => {
    expect(normalizeBassBoostLevel(-1)).toBe(0);
    expect(normalizeBassBoostLevel(101)).toBe(100);
    expect(normalizeBassBoostLevel(55.7)).toBe(56);
  });

  it('accepts known presets only', () => {
    expect(isEqualizerPreset('flat')).toBe(true);
    expect(isEqualizerPreset('rock')).toBe(true);
    expect(isEqualizerPreset('cinema')).toBe(false);
    expect(isEqualizerPreset(null)).toBe(false);
  });
});


describe('equalizer preset mapping', () => {
  it('returns five normalized bands for every supported preset', () => {
    for (const preset of ['flat', 'bass', 'vocal', 'treble', 'classical', 'rock']) {
      const levels = getEqualizerPresetLevels(preset);
      expect(levels).toHaveLength(5);
      expect(levels.every((level) => level >= -1 && level <= 1)).toBe(true);
    }
  });

  it('falls back to flat for an unknown preset and returns a copy', () => {
    const levels = getEqualizerPresetLevels('unknown');
    expect(levels).toEqual([0, 0, 0, 0, 0]);
    levels[0] = 1;
    expect(getEqualizerPresetLevels('flat')).toEqual([0, 0, 0, 0, 0]);
  });
});

import { getAudioEffectsDiagnostics } from '../../services/audio/audioEffectsDiagnostics';

describe('audio effects integration diagnostics', () => {
  const androidCapabilities = { platform: 'android', supported: true, equalizer: true, bassBoost: true, requiresAudioSessionId: true };

  it('reports Android-only support on other platforms', () => {
    expect(getAudioEffectsDiagnostics(androidCapabilities, 12, 'ios').state).toBe('unsupported-platform');
  });

  it('does not mistake module availability for active playback integration', () => {
    const result = getAudioEffectsDiagnostics(androidCapabilities, null, 'android');
    expect(result.state).toBe('session-id-required');
    expect(result.canApplyEffects).toBe(false);
  });

  it('allows application only when a valid session ID is supplied', () => {
    expect(getAudioEffectsDiagnostics(androidCapabilities, 23, 'android').canApplyEffects).toBe(true);
    expect(getAudioEffectsDiagnostics(androidCapabilities, 0, 'android').canApplyEffects).toBe(false);
  });

  it('reports missing native module', () => {
    expect(getAudioEffectsDiagnostics(null, null, 'android').state).toBe('native-module-missing');
  });
});
