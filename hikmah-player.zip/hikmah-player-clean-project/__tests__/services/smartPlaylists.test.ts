import { getSmartPlaylistItems } from '@/services/library/smartPlaylists';
import type { LocalMediaItem } from '@/types/library';

const media = (overrides: Partial<LocalMediaItem> & Pick<LocalMediaItem, 'id'>): LocalMediaItem => ({
  id: overrides.id,
  title: overrides.title ?? overrides.id,
  duration: overrides.duration ?? 60,
  filePath: overrides.filePath ?? `/music/${overrides.id}.mp3`,
  mediaType: overrides.mediaType ?? 'audio',
  fileSize: overrides.fileSize ?? 100,
  mimeType: overrides.mimeType ?? 'audio/mpeg',
  progress: overrides.progress ?? 0,
  lastPlayed: overrides.lastPlayed ?? null,
  playCount: overrides.playCount ?? 0,
  favorite: overrides.favorite ?? false,
  playlists: overrides.playlists ?? [],
  addedAt: overrides.addedAt ?? 1,
  modifiedAt: overrides.modifiedAt ?? 1,
  thumbnail: overrides.thumbnail,
});

describe('getSmartPlaylistItems', () => {
  const items = [
    media({ id: 'old', addedAt: 10, lastPlayed: 100, playCount: 2 }),
    media({ id: 'new', addedAt: 30, lastPlayed: 300, playCount: 8, favorite: true }),
    media({ id: 'never-played', addedAt: 20, playCount: 0, favorite: true }),
    media({ id: 'future', addedAt: 9999 }),
  ];

  it('orders recently played by most recent playback and excludes never-played items', () => {
    expect(getSmartPlaylistItems(items, 'recently-played').map((item) => item.id)).toEqual(['new', 'old']);
  });

  it('orders most played by play count and excludes zero-play items', () => {
    expect(getSmartPlaylistItems(items, 'most-played').map((item) => item.id)).toEqual(['new', 'old']);
  });

  it('shows newest added first and excludes future timestamps', () => {
    expect(getSmartPlaylistItems(items, 'recently-added', 100).map((item) => item.id)).toEqual(['new', 'never-played', 'old']);
  });

  it('returns favorites only', () => {
    expect(getSmartPlaylistItems(items, 'favorites').map((item) => item.id)).toEqual(['new', 'never-played']);
  });
});
