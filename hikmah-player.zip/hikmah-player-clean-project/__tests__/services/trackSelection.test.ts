import { formatTrackLabel, makeTrackOptions } from '@/services/video/trackSelection';

describe('track selection helpers', () => {
  it('adds a default/off option before supplied tracks', () => {
    const options = makeTrackOptions([{ id: 'en', language: 'English' }], 'subtitle');
    expect(options).toHaveLength(2);
    expect(options[0].key).toBe('off');
    expect(options[0].label).toBe('Off');
    expect(options[1].label).toContain('English');
  });

  it('handles missing track metadata safely', () => {
    expect(formatTrackLabel({}, 1, 'audio')).toBe('Audio 2');
    expect(makeTrackOptions(undefined, 'audio')).toHaveLength(1);
    expect(makeTrackOptions(null, 'subtitle')).toHaveLength(1);
  });

  it('deduplicates repeated label metadata', () => {
    expect(formatTrackLabel({ label: 'English', language: 'English' }, 0, 'audio')).toBe('English');
  });
});
