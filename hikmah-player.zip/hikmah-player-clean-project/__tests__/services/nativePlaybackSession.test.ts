import { NativePlaybackSession } from '../../services/audio/nativePlaybackSession';
import * as bridge from '../../services/audio/nativePlayerBridge';
import * as effects from '../../services/audio/nativeAudioEffects';

jest.mock('../../services/audio/nativePlayerBridge', () => ({
  loadNativePlayer: jest.fn(async (uri: string) => ({ loaded: true, uri, durationMs: 90000, audioSessionId: 42 })),
  playNativePlayer: jest.fn(() => true), pauseNativePlayer: jest.fn(() => true), stopNativePlayer: jest.fn(() => true),
  seekNativePlayer: jest.fn((positionMs: number) => ({ positionMs, durationMs: 90000 })),
  getNativePlayerStatus: jest.fn(() => ({ loaded: true, playing: false, positionMs: 1200, durationMs: 90000, audioSessionId: 42 })),
  releaseNativePlayer: jest.fn(() => true),
}));
jest.mock('../../services/audio/nativeAudioEffects', () => ({ releaseNativeAudioEffects: jest.fn(() => true) }));

describe('NativePlaybackSession', () => {
  beforeEach(() => jest.clearAllMocks());
  it('loads and retains a valid native audio session', async () => {
    const session = new NativePlaybackSession();
    const snapshot = await session.load('file:///song.mp3');
    expect(snapshot.state).toBe('ready');
    expect(snapshot.audioSessionId).toBe(42);
    expect(snapshot.durationMs).toBe(90000);
  });
  it('rejects blank URIs before touching native playback', async () => {
    const session = new NativePlaybackSession();
    await expect(session.load('   ')).rejects.toThrow('URI');
    expect(bridge.loadNativePlayer).not.toHaveBeenCalled();
  });
  it('requires media before play and rejects use after disposal', async () => {
    const session = new NativePlaybackSession();
    await expect(session.play()).rejects.toThrow('No media is loaded');
    await session.dispose();
    await expect(session.load('file:///song.mp3')).rejects.toThrow('disposed');
  });
  it('releases effects before the player on dispose', async () => {
    const session = new NativePlaybackSession();
    await session.load('file:///song.mp3');
    await session.dispose();
    expect(effects.releaseNativeAudioEffects).toHaveBeenCalled();
    expect(bridge.releaseNativePlayer).toHaveBeenCalled();
    expect(session.getSnapshot().state).toBe('idle');
  });
  it('validates seek position', async () => {
    const session = new NativePlaybackSession();
    await session.load('file:///song.mp3');
    await expect(session.seek(-1)).rejects.toThrow('non-negative');
  });
});
