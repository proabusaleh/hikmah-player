import { TrackCompletionGuard } from '@/services/playback/trackCompletionGuard';

describe('TrackCompletionGuard', () => {
  it('handles a track completion once even when native end events are duplicated', () => {
    const guard = new TrackCompletionGuard();
    expect(guard.shouldHandle('track-a')).toBe(true);
    expect(guard.shouldHandle('track-a')).toBe(false);
    expect(guard.shouldHandle('track-a')).toBe(false);
  });

  it('allows a different track to complete without requiring an intermediate reset', () => {
    const guard = new TrackCompletionGuard();
    expect(guard.shouldHandle('track-a')).toBe(true);
    expect(guard.shouldHandle('track-b')).toBe(true);
    expect(guard.shouldHandle('track-b')).toBe(false);
  });

  it('resets after a new play event so repeat-one can complete again', () => {
    const guard = new TrackCompletionGuard();
    expect(guard.shouldHandle('track-a')).toBe(true);
    guard.reset();
    expect(guard.shouldHandle('track-a')).toBe(true);
  });

  it('ignores missing track ids safely', () => {
    const guard = new TrackCompletionGuard();
    expect(guard.shouldHandle(null)).toBe(false);
    expect(guard.shouldHandle(undefined)).toBe(false);
    expect(guard.shouldHandle('track-a')).toBe(true);
  });
});
