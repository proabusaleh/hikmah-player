import { getActiveSubtitle, parseExternalSubtitles } from '@/services/video/externalSubtitles';

describe('external subtitles', () => {
  it('parses SRT timestamps, HTML tags and multiple cues', () => {
    const cues = parseExternalSubtitles('1\n00:00:01,000 --> 00:00:02,500\n<i>Hello</i> world\n\n2\n00:00:03,000 --> 00:00:04,000\nNext');
    expect(cues).toHaveLength(2);
    expect(cues[0]).toMatchObject({ start: 1, end: 2.5, text: 'Hello world' });
  });
  it('parses WebVTT and ignores malformed cues', () => {
    const cues = parseExternalSubtitles('WEBVTT\n\n00:01.000 --> 00:02.000\nA cue\n\n00:bad --> nope\ninvalid');
    expect(cues).toHaveLength(1);
    expect(cues[0].start).toBe(1);
  });
  it('returns the active cue and applies subtitle delay', () => {
    const cues = parseExternalSubtitles('00:01.000 --> 00:03.000\nHello');
    expect(getActiveSubtitle(cues, 2)?.text).toBe('Hello');
    expect(getActiveSubtitle(cues, 2, 1500)).toBeNull();
  });
  it('rejects empty and oversized input', () => {
    expect(parseExternalSubtitles('')).toEqual([]);
    expect(parseExternalSubtitles('x'.repeat(5_000_001))).toEqual([]);
  });
});
