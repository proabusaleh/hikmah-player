import { PlaybackDiagnostics } from '@/services/playback/playbackDiagnostics';

describe('PlaybackDiagnostics', () => {
  it('keeps a bounded rolling event buffer and monotonically increasing IDs', () => {
    let now = 100;
    const diagnostics = new PlaybackDiagnostics(2, () => now++);
    diagnostics.record('playback.started');
    diagnostics.record('playback.paused', { level: 'warning' });
    diagnostics.record('playback.failed', { level: 'error' });
    const entries = diagnostics.snapshot();
    expect(entries).toHaveLength(2);
    expect(entries.map((entry) => entry.id)).toEqual([2, 3]);
    expect(entries[1].at).toBe(102);
    expect(diagnostics.summary()).toEqual({ total: 2, errors: 1, warnings: 1, latestEvent: 'playback.failed' });
  });

  it('filters sensitive fields and unsupported values from diagnostic details', () => {
    const diagnostics = new PlaybackDiagnostics(10, () => Number.NaN);
    const event = diagnostics.record('native.error / unexpected', {
      level: 'error', engine: 'native/service',
      details: {
        retryCount: 2, playing: false, url: 'https://private.example/secret.mp3',
        title: 'Private title', stack: 'secret stack', arbitrary: { hidden: true },
        positionMs: Number.POSITIVE_INFINITY, note: 'x'.repeat(100),
      },
    });
    expect(event.event).toBe('native.errorunexpected');
    expect(event.engine).toBe('native/service');
    expect(event.at).toBe(0);
    expect(event.details).toEqual({ retryCount: 2, playing: false, note: 'x'.repeat(80) });
    expect(JSON.stringify(event)).not.toContain('private.example');
    expect(JSON.stringify(event)).not.toContain('Private title');
  });

  it('clamps capacity, returns defensive snapshots, and supports clear', () => {
    const diagnostics = new PlaybackDiagnostics(0, () => 5);
    diagnostics.record('one');
    const copy = diagnostics.snapshot();
    copy[0].event = 'tampered';
    expect(diagnostics.snapshot()[0].event).toBe('one');
    diagnostics.clear();
    expect(diagnostics.summary()).toEqual({ total: 0, errors: 0, warnings: 0, latestEvent: null });
  });
});
