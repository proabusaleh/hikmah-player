import { Platform } from 'react-native';
import type { MediaItem } from '@/types/media';
import {
  ForegroundPlaybackAdapter,
} from '@/services/audio/foregroundPlaybackAdapter';
import {
  startNativeForegroundPlayback,
  sendNativeForegroundPlaybackCommand,
  getNativeForegroundPlaybackStatus,
  subscribeNativeMediaSessionActions,
} from '@/services/audio/nativePlayerBridge';

jest.mock('@/services/audio/nativePlayerBridge', () => ({
  startNativeForegroundPlayback: jest.fn(() => true),
  sendNativeForegroundPlaybackCommand: jest.fn(() => true),
  getNativeForegroundPlaybackStatus: jest.fn(() => ({
    active: true, loaded: true, playing: false, state: 'paused',
    positionMs: 0, durationMs: 1000, uri: 'https://example.test/a.mp3',
  })),
  subscribeNativeMediaSessionActions: jest.fn(() => ({ remove: jest.fn() })),
}));

const audio: MediaItem = {
  id: 'audio-a', title: 'Audio A', url: 'https://example.test/a.mp3',
  duration: 10, type: 'audio', addedAt: 1,
};

const video: MediaItem = {
  id: 'video-a', title: 'Video A', url: 'https://example.test/a.mp4',
  duration: 10, type: 'video', addedAt: 2,
};

describe('ForegroundPlaybackAdapter hardening', () => {
  const originalOS = Platform.OS;
  let adapter: ForegroundPlaybackAdapter;

  beforeEach(() => {
    Object.defineProperty(Platform, 'OS', { configurable: true, value: 'android' });
    jest.clearAllMocks();
    adapter = new ForegroundPlaybackAdapter();
  });

  afterEach(() => {
    adapter.dispose();
    Object.defineProperty(Platform, 'OS', { configurable: true, value: originalOS });
  });

  it('rejects non-finite queue start indexes instead of silently choosing an item', () => {
    expect(() => adapter.setQueue([audio], Number.NaN)).toThrow('finite number');
    expect(() => adapter.setQueue([audio], Number.POSITIVE_INFINITY)).toThrow('finite number');
  });

  it('clamps finite queue start indexes into the valid range', () => {
    adapter.setQueue([audio], 999);
    expect(adapter.currentQueueIndex).toBe(0);
    adapter.setQueue([], 0);
    expect(adapter.currentQueueIndex).toBe(-1);
  });

  it('rejects video items before starting the native service', async () => {
    await expect(adapter.start(video)).rejects.toThrow('audio items only');
    expect(startNativeForegroundPlayback).not.toHaveBeenCalled();
  });

  it('does not issue playback commands before a track is active', () => {
    expect(() => adapter.play()).toThrow('has not been started');
    expect(sendNativeForegroundPlaybackCommand).not.toHaveBeenCalled();
  });

  it('starts a valid audio item and routes pause to the foreground service', async () => {
    await adapter.start(audio);
    expect(adapter.isActive).toBe(true);
    expect(adapter.currentTrack?.id).toBe('audio-a');
    expect(sendNativeForegroundPlaybackCommand).not.toHaveBeenCalled();
    adapter.pause();
    expect(sendNativeForegroundPlaybackCommand).toHaveBeenCalledWith('pause');
  });

  it('can read native status and safely dispose subscriptions', () => {
    expect(adapter.getStatus().state).toBe('paused');
    expect(getNativeForegroundPlaybackStatus).toHaveBeenCalledTimes(1);
    expect(subscribeNativeMediaSessionActions).not.toHaveBeenCalled();
    adapter.dispose();
  });
});
