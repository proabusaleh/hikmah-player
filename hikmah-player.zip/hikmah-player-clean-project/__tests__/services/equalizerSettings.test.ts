import {
  isEqualizerPreset,
  normalizeBassBoostLevel,
  normalizeEqualizerPreferences,
} from '@/services/audio/equalizerSettings';

describe('equalizer preference validation', () => {
  it('accepts known presets and rejects unknown values', () => {
    expect(isEqualizerPreset('rock')).toBe(true);
    expect(isEqualizerPreset('cinema')).toBe(false);
    expect(isEqualizerPreset(null)).toBe(false);
  });

  it('clamps bass boost level to 0–100', () => {
    expect(normalizeBassBoostLevel(-20)).toBe(0);
    expect(normalizeBassBoostLevel(45.7)).toBe(46);
    expect(normalizeBassBoostLevel(120)).toBe(100);
    expect(normalizeBassBoostLevel(Number.NaN)).toBe(0);
  });

  it('returns safe defaults for invalid persisted preferences', () => {
    expect(normalizeEqualizerPreferences({ preset: 'unknown' as never, bassBoostEnabled: 1 as never, bassBoostLevel: 500 })).toEqual({
      preset: 'flat',
      bassBoostEnabled: false,
      bassBoostLevel: 100,
    });
  });
});
