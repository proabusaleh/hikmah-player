import { clampSeekPosition, createMediaSessionSnapshot } from '@/services/playback/mediaSessionContract';

describe('media session contract', () => {
  it('sanitizes invalid playback positions and speed', () => {
    expect(createMediaSessionSnapshot({ positionMs: -8, speed: 8 }).positionMs).toBe(0);
    expect(createMediaSessionSnapshot({ positionMs: 20.9, speed: 8 }).positionMs).toBe(20);
    expect(createMediaSessionSnapshot({ speed: 8 }).speed).toBe(4);
  });

  it('requires useful metadata and filters unsupported actions', () => {
    expect(createMediaSessionSnapshot({ metadata: { mediaId: '', title: '' } }).metadata).toBeNull();
    expect(createMediaSessionSnapshot({ availableActions: ['play', 'play', 'bogus' as never] }).availableActions).toEqual(['play']);
  });

  it('clamps seeks to zero and optional duration', () => {
    expect(clampSeekPosition(-100, 1000)).toBe(0);
    expect(clampSeekPosition(1200, 1000)).toBe(1000);
    expect(clampSeekPosition(400)).toBe(400);
  });
});
