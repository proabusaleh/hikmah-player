import { loadNativePlaybackWithEffects, releaseNativePlaybackWithEffects } from '../../services/audio/nativePlaybackEffectsCoordinator';
import { loadNativePlayer, releaseNativePlayer } from '../../services/audio/nativePlayerBridge';
import { applyNativeAudioEffects, releaseNativeAudioEffects } from '../../services/audio/nativeAudioEffects';

jest.mock('../../services/audio/nativePlayerBridge', () => ({
  loadNativePlayer: jest.fn(),
  releaseNativePlayer: jest.fn(() => true),
}));
jest.mock('../../services/audio/nativeAudioEffects', () => ({
  applyNativeAudioEffects: jest.fn(),
  getEqualizerPresetLevels: jest.fn(() => [0, 0.2, 0, -0.2, 0]),
  releaseNativeAudioEffects: jest.fn(() => true),
}));

describe('native playback effects coordinator', () => {
  beforeEach(() => jest.clearAllMocks());

  it('uses the actual session ID and returns the effects result', async () => {
    (loadNativePlayer as jest.Mock).mockResolvedValue({ loaded: true, durationMs: 1200, audioSessionId: 42 });
    (applyNativeAudioEffects as jest.Mock).mockResolvedValue({ applied: true, sessionId: 42, equalizerEnabled: true, bassBoostEnabled: false, bandsApplied: 5 });
    const result = await loadNativePlaybackWithEffects('file:///song.mp3', { equalizerPreset: 'rock', equalizerEnabled: true, bassBoostEnabled: false, bassBoostLevel: 0 });
    expect(applyNativeAudioEffects).toHaveBeenCalledWith(expect.objectContaining({ audioSessionId: 42 }));
    expect(result.effects?.applied).toBe(true);
    expect(result.effectsError).toBeNull();
  });

  it('does not hide effects failure after media loaded', async () => {
    (loadNativePlayer as jest.Mock).mockResolvedValue({ loaded: true, durationMs: 1200, audioSessionId: 42 });
    (applyNativeAudioEffects as jest.Mock).mockRejectedValue(new Error('OEM effect unavailable'));
    const result = await loadNativePlaybackWithEffects('file:///song.mp3', { equalizerPreset: 'flat', equalizerEnabled: true, bassBoostEnabled: false, bassBoostLevel: 0 });
    expect(result.loaded).toBe(true);
    expect(result.effects).toBeNull();
    expect(result.effectsError).toBe('OEM effect unavailable');
  });

  it('releases effects before the native player', () => {
    const result = releaseNativePlaybackWithEffects();
    expect(releaseNativeAudioEffects).toHaveBeenCalledTimes(1);
    expect(releaseNativePlayer).toHaveBeenCalledTimes(1);
    expect(result).toEqual({ effectsReleased: true, playerReleased: true });
  });
});
