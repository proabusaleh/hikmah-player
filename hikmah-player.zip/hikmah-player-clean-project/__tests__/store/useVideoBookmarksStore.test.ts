import AsyncStorage from '@react-native-async-storage/async-storage';
import { useVideoBookmarksStore } from '@/store/useVideoBookmarksStore';

jest.mock('@react-native-async-storage/async-storage', () => require('@react-native-async-storage/async-storage/jest/async-storage-mock'));

describe('useVideoBookmarksStore', () => {
  beforeEach(async () => {
    await AsyncStorage.clear();
    useVideoBookmarksStore.setState({ bookmarks: [], loaded: false });
  });

  it('adds a bookmark and returns bookmarks in playback order', async () => {
    const store = useVideoBookmarksStore.getState();
    expect(await store.add({ mediaId: 'video-1', title: 'Demo', position: 42.8 })).toBe(true);
    expect(await useVideoBookmarksStore.getState().add({ mediaId: 'video-1', title: 'Demo', position: 12 })).toBe(true);
    expect(useVideoBookmarksStore.getState().forMedia('video-1').map((item) => item.position)).toEqual([12, 42]);
  });

  it('rejects near-duplicate and invalid bookmarks', async () => {
    const store = useVideoBookmarksStore.getState();
    expect(await store.add({ mediaId: 'video-1', title: 'Demo', position: 42 })).toBe(true);
    expect(await useVideoBookmarksStore.getState().add({ mediaId: 'video-1', title: 'Demo', position: 44 })).toBe(false);
    expect(await useVideoBookmarksStore.getState().add({ mediaId: '', title: 'Demo', position: 10 })).toBe(false);
    expect(await useVideoBookmarksStore.getState().add({ mediaId: 'video-1', title: 'Demo', position: Number.NaN })).toBe(false);
  });

  it('persists and removes bookmarks', async () => {
    await useVideoBookmarksStore.getState().add({ mediaId: 'video-1', title: 'Demo', position: 80 });
    const saved = useVideoBookmarksStore.getState().bookmarks[0];
    await useVideoBookmarksStore.getState().remove(saved.id);
    expect(useVideoBookmarksStore.getState().bookmarks).toHaveLength(0);
    expect(await AsyncStorage.getItem('@hikmah-player/video-bookmarks/v1')).toContain('[]');
  });
});
