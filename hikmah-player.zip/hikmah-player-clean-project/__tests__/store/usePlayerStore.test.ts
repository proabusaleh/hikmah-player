import { usePlayerStore } from '@/store/usePlayerStore';
import { MediaItem } from '@/types/media';
import { playbackDiagnostics } from '@/services/playback/playbackDiagnostics';

const createMockTrack = (id: string, title: string): MediaItem => ({
  id,
  title,
  url: `https://example.com/${id}.mp3`,
  duration: 120,
  type: 'audio',
  addedAt: Date.now(),
});

const mockQueue: MediaItem[] = [
  createMockTrack('1', 'Track One'),
  createMockTrack('2', 'Track Two'),
  createMockTrack('3', 'Track Three'),
];

describe('usePlayerStore', () => {
  beforeEach(() => {
    playbackDiagnostics.clear();
    usePlayerStore.getState().resetPlayer();
    jest.clearAllMocks();
  });


  describe('Playback diagnostics integration', () => {
    it('records status transitions without storing media metadata', () => {
      usePlayerStore.getState().setQueue([createMockTrack('private-id', 'Private Track')], 0);
      usePlayerStore.getState().updateStatus('playing');
      const serialized = JSON.stringify(playbackDiagnostics.snapshot());
      expect(serialized).toContain('playback.status');
      expect(serialized).toContain('playing');
      expect(serialized).not.toContain('Private Track');
      expect(serialized).not.toContain('example.com');
    });
  });

  describe('Queue Management', () => {
    it('should set queue and current track', () => {
      usePlayerStore.getState().setQueue(mockQueue, 0);

      const state = usePlayerStore.getState();
      expect(state.queue).toHaveLength(3);
      expect(state.currentIndex).toBe(0);
      expect(state.currentTrack?.id).toBe('1');
    });

    it('clamps an invalid start index to a valid queue item', () => {
      usePlayerStore.getState().setQueue(mockQueue, 99);
      const state = usePlayerStore.getState();
      expect(state.currentIndex).toBe(2);
      expect(state.currentTrack?.id).toBe('3');
    });

    it('keeps the selected track stable when an earlier queue item is removed', () => {
      usePlayerStore.getState().setQueue(mockQueue, 2);
      usePlayerStore.getState().removeFromQueue(0);
      const state = usePlayerStore.getState();
      expect(state.queue.map((track) => track.id)).toEqual(['2', '3']);
      expect(state.currentIndex).toBe(1);
      expect(state.currentTrack?.id).toBe('3');
    });

    it('ignores invalid queue removal indexes', () => {
      usePlayerStore.getState().setQueue(mockQueue, 0);
      usePlayerStore.getState().removeFromQueue(-1);
      usePlayerStore.getState().removeFromQueue(99);
      expect(usePlayerStore.getState().queue.map((track) => track.id)).toEqual(['1', '2', '3']);
    });

    it('should add item to queue', () => {
      usePlayerStore.getState().setQueue(mockQueue, 0);
      const newTrack = createMockTrack('4', 'Track Four');
      usePlayerStore.getState().addToQueue(newTrack);

      expect(usePlayerStore.getState().queue).toHaveLength(4);
    });

    it('should remove item from queue', () => {
      usePlayerStore.getState().setQueue(mockQueue, 0);
      usePlayerStore.getState().removeFromQueue(1);

      const state = usePlayerStore.getState();
      expect(state.queue).toHaveLength(2);
      expect(state.queue.find((t) => t.id === '2')).toBeUndefined();
    });

    it('should clear upcoming items but retain the current track', () => {
      usePlayerStore.getState().setQueue(mockQueue, 1);
      usePlayerStore.getState().clearQueue();

      const state = usePlayerStore.getState();
      expect(state.queue).toHaveLength(1);
      expect(state.queue[0].id).toBe('2');
      expect(state.currentIndex).toBe(0);
      expect(state.currentTrack?.id).toBe('2');
    });

    it('should reorder queue while preserving the current track selection', () => {
      usePlayerStore.getState().setQueue(mockQueue, 1);
      usePlayerStore.getState().moveInQueue(0, 2);

      const state = usePlayerStore.getState();
      expect(state.queue.map((track) => track.id)).toEqual(['2', '3', '1']);
      expect(state.currentIndex).toBe(0);
      expect(state.currentTrack?.id).toBe('2');
      expect(state.originalQueue.map((track) => track.id)).toEqual(['2', '3', '1']);
    });

    it('should ignore invalid queue reorder indexes', () => {
      usePlayerStore.getState().setQueue(mockQueue, 0);
      usePlayerStore.getState().moveInQueue(-1, 2);
      usePlayerStore.getState().moveInQueue(0, 10);

      expect(usePlayerStore.getState().queue.map((track) => track.id)).toEqual(['1', '2', '3']);
    });
  });

  describe('Navigation', () => {
    beforeEach(() => {
      usePlayerStore.getState().setQueue(mockQueue, 0);
    });

    it('should go to next track', async () => {
      await usePlayerStore.getState().nextTrack();
      expect(usePlayerStore.getState().currentIndex).toBe(1);
    });

    it('should go to previous track', async () => {
      usePlayerStore.getState().setQueue(mockQueue, 1);
      await usePlayerStore.getState().previousTrack();
      expect(usePlayerStore.getState().currentIndex).toBe(0);
    });

    it('should restart track if position > 3s on previous', async () => {
      usePlayerStore.getState().setQueue(mockQueue, 1);
      usePlayerStore.setState({ position: 5000 });

      await usePlayerStore.getState().previousTrack();
      // Should stay on same track but reset position
      expect(usePlayerStore.getState().currentIndex).toBe(1);
      expect(usePlayerStore.getState().position).toBe(0);
    });

    it('should loop to first track with repeat all', async () => {
      usePlayerStore.getState().setQueue(mockQueue, 2);
      usePlayerStore.setState({ repeatMode: 'all' });

      await usePlayerStore.getState().nextTrack();
      expect(usePlayerStore.getState().currentIndex).toBe(0);
    });

    it('should stop at last track with repeat off', async () => {
      usePlayerStore.getState().setQueue(mockQueue, 2);
      usePlayerStore.setState({ repeatMode: 'off' });

      await usePlayerStore.getState().nextTrack();
      expect(usePlayerStore.getState().status).toBe('stopped');
    });
  });

  describe('Shuffle', () => {
    it('should shuffle queue keeping current track first', () => {
      usePlayerStore.getState().setQueue(mockQueue, 0);
      usePlayerStore.getState().toggleShuffle();

      const state = usePlayerStore.getState();
      expect(state.isShuffled).toBe(true);
      expect(state.currentTrack?.id).toBe('1');
    });

    it('should restore original order on second toggle', () => {
      usePlayerStore.getState().setQueue(mockQueue, 0);
      usePlayerStore.getState().toggleShuffle();
      usePlayerStore.getState().toggleShuffle();

      const state = usePlayerStore.getState();
      expect(state.isShuffled).toBe(false);
      expect(state.queue[0].id).toBe('1');
      expect(state.queue[1].id).toBe('2');
    });
  });

  describe('Repeat Mode', () => {
    it('should cycle through off → all → one → off', () => {
      const store = usePlayerStore.getState();

      expect(store.repeatMode).toBe('off');
      store.cycleRepeatMode();
      expect(usePlayerStore.getState().repeatMode).toBe('all');
      store.cycleRepeatMode();
      expect(usePlayerStore.getState().repeatMode).toBe('one');
      store.cycleRepeatMode();
      expect(usePlayerStore.getState().repeatMode).toBe('off');
    });
  });

  describe('Playback stability and recovery', () => {
    it('does not attempt recovery when no track is selected', async () => {
      await usePlayerStore.getState().retryPlayback();
      expect(usePlayerStore.getState().playbackError).toBe('Choose a track before retrying playback.');
      expect(playbackDiagnostics.snapshot().some((event) => event.event === 'playback.retry.skipped')).toBe(true);
    });

    it('does not start a second recovery while the player is already buffering', async () => {
      usePlayerStore.setState({ currentTrack: createMockTrack('retry', 'Retry Track'), status: 'buffering' });
      await usePlayerStore.getState().retryPlayback();
      expect(usePlayerStore.getState().status).toBe('buffering');
      expect(playbackDiagnostics.snapshot().some((event) => event.event === 'playback.retry.skipped')).toBe(true);
    });

    it('invalidates a pending load when stop is requested', async () => {
      usePlayerStore.setState({ currentTrack: createMockTrack('stop', 'Stop Track'), status: 'playing' });
      await usePlayerStore.getState().stop();
      expect(usePlayerStore.getState().status).toBe('stopped');
      expect(usePlayerStore.getState().position).toBe(0);
    });
  });

  describe('Playback reliability', () => {
    it('ignores non-finite progress values', () => {
      usePlayerStore.setState({ position: 1000, duration: 5000 });
      usePlayerStore.getState().updateProgress(Number.NaN, 9000);
      usePlayerStore.getState().updateProgress(2000, Number.POSITIVE_INFINITY);
      expect(usePlayerStore.getState().position).toBe(1000);
      expect(usePlayerStore.getState().duration).toBe(5000);
    });

    it('clamps progress to a known duration and prevents negative positions', () => {
      usePlayerStore.getState().updateProgress(9000, 5000);
      expect(usePlayerStore.getState().position).toBe(5000);
      expect(usePlayerStore.getState().duration).toBe(5000);
      usePlayerStore.getState().updateProgress(-200, 5000);
      expect(usePlayerStore.getState().position).toBe(0);
    });

    it('keeps an empty duration at zero without inventing a duration bound', () => {
      usePlayerStore.getState().updateProgress(1200, 0);
      expect(usePlayerStore.getState().position).toBe(1200);
      expect(usePlayerStore.getState().duration).toBe(0);
    });
  });

  describe('Sleep Timer', () => {
    it('should set sleep timer', () => {
      usePlayerStore.getState().setSleepTimer(30);

      const state = usePlayerStore.getState();
      expect(state.sleepTimerEnd).not.toBeNull();
      expect(state.sleepTimerRemaining).toBe(1800);
    });

    it('should clear sleep timer', () => {
      usePlayerStore.getState().setSleepTimer(30);
      usePlayerStore.getState().clearSleepTimer();

      const state = usePlayerStore.getState();
      expect(state.sleepTimerEnd).toBeNull();
      expect(state.sleepTimerRemaining).toBe(0);
    });

    it('should ignore invalid timer durations', () => {
      usePlayerStore.getState().setSleepTimer(Number.NaN);
      expect(usePlayerStore.getState().sleepTimerEnd).toBeNull();
      usePlayerStore.getState().setSleepTimer(-5);
      expect(usePlayerStore.getState().sleepTimerEnd).toBeNull();
    });
  });
});
