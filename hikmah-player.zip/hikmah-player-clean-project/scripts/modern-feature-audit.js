#!/usr/bin/env node
/** Static source-presence audit only; it does not validate runtime/device behavior. */
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const checks = [
  ['Root layout conditionally mounts the mini-player', 'src/app/_layout.tsx', /showMiniPlayer\s*&&\s*<MiniPlayer\s*\/>/],
  ['Mini-player exposes play/pause controls', 'src/components/player/MiniPlayer.tsx', /onTogglePlayPause=\{togglePlayPause\}/],
  ['Mini-player exposes next-track control', 'src/components/player/MiniPlayer.tsx', /onSkipNext=\{skipNext\}/],
  ['Mini-player opens full player', 'src/components/player/MiniPlayer.tsx', /router\.navigate\('\/player'\)/],
  ['Player defines speed presets', 'src/app/player/index.tsx', /SPEED_OPTIONS\s*=\s*\[0\.5,\s*0\.75[\s\S]*?2\.0\]/],
  ['Player store implements speed changes', 'store/usePlayerStore.ts', /setPlaybackSpeed:\s*async\s*\(speed\)/],
  ['Player session persists playback speed', 'store/usePlayerStore.ts', /playbackSpeed:\s*state\.playbackSpeed/],
  ['Phase 49 acceptance checklist exists', 'PHASE_49_MODERN_FEATURE_AUDIT.md', /Device acceptance checklist/],
];
let failed = 0;
for (const [name, file, pattern] of checks) {
  const full = path.join(root, file);
  const ok = fs.existsSync(full) && pattern.test(fs.readFileSync(full, 'utf8'));
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
  if (!ok) failed++;
}
console.log(`\nStatic audit: ${checks.length - failed}/${checks.length} passed; ${failed} failed.`);
console.log('Static source checks only; physical-device behavior is not tested.');
if (failed) process.exitCode = 1;
