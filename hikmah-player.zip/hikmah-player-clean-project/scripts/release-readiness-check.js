#!/usr/bin/env node
/** Static release-readiness checks for Hikmah Player. Does not replace native-device QA. */
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const checks = [];
const add = (name, ok, detail) => checks.push({ name, ok: Boolean(ok), detail });
const exists = (relative) => fs.existsSync(path.join(root, relative));
const readJson = (relative) => JSON.parse(fs.readFileSync(path.join(root, relative), 'utf8'));

let pkg;
let app;
try { pkg = readJson('package.json'); add('package.json parses', true, 'Valid JSON'); }
catch (error) { add('package.json parses', false, error.message); }
try { app = readJson('app.json').expo; add('app.json parses', Boolean(app), 'Expo config found'); }
catch (error) { add('app.json parses', false, error.message); }

if (pkg) {
  for (const script of ['lint', 'test', 'test:playback']) add(`npm script: ${script}`, Boolean(pkg.scripts?.[script]), pkg.scripts?.[script] || 'Missing script');
  add('lockfile present', exists('package-lock.json'), 'npm ci requires package-lock.json');
}
if (app) {
  add('Android package configured', typeof app.android?.package === 'string' && app.android.package.includes('.'), app.android?.package || 'Missing android.package');
  add('iOS bundle identifier configured', typeof app.ios?.bundleIdentifier === 'string' && app.ios.bundleIdentifier.includes('.'), app.ios?.bundleIdentifier || 'Missing ios.bundleIdentifier');
  add('Android playback foreground service permission', (app.android?.permissions || []).includes('android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK'), 'Required for configured background playback');
  const audioPlugin = (app.plugins || []).find((plugin) => Array.isArray(plugin) && plugin[0] === 'expo-audio');
  add('Background audio plugin enabled', Boolean(audioPlugin?.[1]?.enableBackgroundPlayback), 'expo-audio enableBackgroundPlayback must be true');
  const iconPaths = [app.icon, app.android?.adaptiveIcon?.foregroundImage, app.android?.adaptiveIcon?.monochromeImage];
  iconPaths.forEach((asset) => add(`Asset exists: ${asset || '(unset)'}`, Boolean(asset && exists(asset.replace(/^\.\//, ''))), asset || 'Asset path is not configured'));
}
for (const file of [
  '.github/workflows/ci.yml',
  '__tests__/integration/playbackQueueCompletion.test.ts',
  '__tests__/integration/playbackEngineIntegration.test.ts',
  '__tests__/services/trackCompletionGuard.test.ts',
  'PRIVACY_POLICY.md',
  'DEPLOYMENT_CHECKLIST.md',
]) add(`Release file: ${file}`, exists(file), exists(file) ? 'Present' : 'Missing');

const failed = checks.filter((check) => !check.ok);
console.log('\nHikmah Player — Static Release Readiness Check\n');
for (const check of checks) console.log(`${check.ok ? 'PASS' : 'FAIL'}  ${check.name} — ${check.detail}`);
console.log(`\nResult: ${checks.length - failed.length}/${checks.length} checks passed; ${failed.length} failed.`);
console.log('Note: static checks do not verify builds, app-store policy compliance, runtime playback, or physical-device behavior.');
if (failed.length) process.exitCode = 1;
