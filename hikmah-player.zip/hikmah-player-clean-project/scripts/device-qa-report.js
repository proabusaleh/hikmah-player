#!/usr/bin/env node
/** Validate a human-completed device QA report; never treats NOT_RUN as a pass. */
const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
const reportArg = args.find((arg) => arg.startsWith('--report='));
if (args.includes('--help') || !reportArg) {
  console.log('Usage: node scripts/device-qa-report.js --report=PATH_TO_REPORT.json');
  console.log('Use docs/PHASE_44_DEVICE_QA_REPORT_TEMPLATE.json as a starting point.');
  console.log('Allowed statuses: PASS, FAIL, BLOCKED, NOT_RUN. Only PASS counts as passed.');
  process.exit(args.includes('--help') ? 0 : 2);
}
const reportPath = path.resolve(process.cwd(), reportArg.slice('--report='.length));
let report;
try { report = JSON.parse(fs.readFileSync(reportPath, 'utf8')); }
catch (error) { console.error(`Cannot read valid JSON report: ${error.message}`); process.exit(2); }
const failures = [];
const required = [
  ['appVersion', report.appVersion], ['commitSha', report.commitSha], ['buildId', report.buildId],
  ['buildArtifact', report.buildArtifact], ['device.model', report.device?.model],
  ['device.osVersion', report.device?.osVersion], ['tester', report.tester], ['testedAt', report.testedAt],
];
for (const [field, value] of required) if (typeof value !== 'string' || !value.trim() || /^(TODO|TBD|UNKNOWN)$/i.test(value.trim())) failures.push(`Missing or placeholder metadata: ${field}`);
if (!Array.isArray(report.checks) || report.checks.length === 0) failures.push('checks must be a non-empty array');
const allowed = new Set(['PASS', 'FAIL', 'BLOCKED', 'NOT_RUN']);
const ids = new Set();
for (const [i, item] of (Array.isArray(report.checks) ? report.checks : []).entries()) {
  const prefix = `checks[${i}]`;
  if (!item || typeof item.id !== 'string' || !item.id.trim()) failures.push(`${prefix}.id is required`);
  else if (ids.has(item.id)) failures.push(`Duplicate check id: ${item.id}`); else ids.add(item.id);
  if (!allowed.has(item.status)) failures.push(`${prefix}.status must be PASS, FAIL, BLOCKED, or NOT_RUN`);
  if (typeof item.name !== 'string' || !item.name.trim()) failures.push(`${prefix}.name is required`);
  if (item.status !== 'PASS' && (!item.notes || !String(item.notes).trim())) failures.push(`${prefix}.notes required unless status is PASS`);
}
const counts = Object.fromEntries([...allowed].map((status) => [status, (report.checks || []).filter((c) => c.status === status).length]));
console.log('\nHikmah Player — Device QA Report Validation\n');
console.log(`Report: ${reportPath}`);
console.log(`App version: ${report.appVersion || 'missing'} | Build: ${report.buildId || 'missing'} | Device: ${report.device?.model || 'missing'}`);
console.log(`Checks: ${report.checks?.length || 0} | PASS ${counts.PASS} | FAIL ${counts.FAIL} | BLOCKED ${counts.BLOCKED} | NOT_RUN ${counts.NOT_RUN}`);
if (failures.length) {
  console.log('\nReport validation: FAIL');
  for (const failure of failures) console.log(`- ${failure}`);
  process.exitCode = 1;
} else if (counts.FAIL || counts.BLOCKED || counts.NOT_RUN) {
  console.log('\nRelease gate: NOT READY — outstanding checks remain.');
  process.exitCode = 1;
} else {
  console.log('\nRelease gate: all listed device checks are PASS. Review evidence and approvals manually before release.');
}
