#!/usr/bin/env node
/** Static release-candidate preflight. Does not build or certify native playback. */
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const results = [];
const check = (name, ok, detail) => results.push({ name, ok: Boolean(ok), detail });
const exists = (file) => fs.existsSync(path.join(root, file));
const readJson = (file) => JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
let pkg; let app; let eas;
for (const [file, assign] of [['package.json', (v) => { pkg = v; }], ['app.json', (v) => { app = v.expo; }], ['eas.json', (v) => { eas = v; }]]) {
  try { assign(readJson(file)); check(`${file} parses`, true, 'Valid JSON'); }
  catch (error) { check(`${file} parses`, false, error.message); }
}
if (pkg) {
  check('App version is release-like', /^\d+\.\d+\.\d+([+-][0-9A-Za-z.-]+)?$/.test(pkg.version || ''), pkg.version || 'Missing package version');
  check('npm lockfile present', exists('package-lock.json'), 'Required for reproducible npm ci installs');
  for (const script of ['lint', 'test:playback', 'check:release', 'check:device-qa']) check(`script exists: ${script}`, Boolean(pkg.scripts?.[script]), pkg.scripts?.[script] || 'Missing');
}
if (app) {
  check('Expo app version matches package version', app.version === pkg?.version, `app.json=${app.version}; package.json=${pkg?.version}`);
  check('Android package configured', /^[A-Za-z][\w]*(\.[A-Za-z][\w]*)+$/.test(app.android?.package || ''), app.android?.package || 'Missing');
  check('iOS bundle identifier configured', /^[A-Za-z][\w]*(\.[A-Za-z][\w]*)+$/.test(app.ios?.bundleIdentifier || ''), app.ios?.bundleIdentifier || 'Missing');
  check('Background audio enabled', (app.plugins || []).some((p) => Array.isArray(p) && p[0] === 'expo-audio' && p[1]?.enableBackgroundPlayback === true), 'expo-audio plugin configuration');
  check('Android media playback foreground permission', (app.android?.permissions || []).includes('android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK'), 'Manifest permission configured');
}
if (eas) {
  for (const profile of ['preview', 'production']) check(`EAS profile exists: ${profile}`, Boolean(eas.build?.[profile]), 'Build profile');
  check('Preview profile creates installable Android APK', eas.build?.preview?.android?.buildType === 'apk', eas.build?.preview?.android?.buildType || 'Expected apk');
}
for (const file of [
  '.gitignore', 'scripts/release-readiness-check.js', 'scripts/release-candidate-preflight.js', 'scripts/device-qa-report.js', 'scripts/modern-feature-audit.js', 'PHASE_49_MODERN_FEATURE_AUDIT.md',
  'docs/PHASE_44_DEVICE_QA_REPORT_TEMPLATE.json', 'PHASE_44_ANDROID_RELEASE_CANDIDATE_DEVICE_VALIDATION.md',
  'PHASE_42_DEVICE_QA_CHECKLIST.md', 'PRIVACY_POLICY.md', 'DEPLOYMENT_CHECKLIST.md',
  '__tests__/integration/playbackQueueCompletion.test.ts',
  '__tests__/integration/playbackEngineIntegration.test.ts',
  '__tests__/services/trackCompletionGuard.test.ts', '.github/workflows/ci.yml',
]) check(`required file: ${file}`, exists(file), exists(file) ? 'Present' : 'Missing');
const ignoreText = exists('.gitignore') ? fs.readFileSync(path.join(root, '.gitignore'), 'utf8') : '';
check('Secret file patterns ignored', ['.env', '*.keystore', '*.jks', 'google-play-service-account.json'].every((s) => ignoreText.includes(s)), 'Environment files and signing credentials');
const failed = results.filter((r) => !r.ok);
console.log('\nHikmah Player — Release Candidate Preflight\n');
for (const r of results) console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name} — ${r.detail}`);
console.log(`\nResult: ${results.length - failed.length}/${results.length} passed; ${failed.length} failed.`);
console.log('This is a static preflight only. It does not run Jest, lint, TypeScript, EAS builds, or device QA.');
if (failed.length) process.exitCode = 1;
