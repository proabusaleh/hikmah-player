import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { playbackDiagnostics, type PlaybackDiagnosticEvent } from '@/services/playback/playbackDiagnostics';

/** Optional developer/QA panel. It displays only the sanitized in-memory event stream. */
export function PlaybackDiagnosticsPanel() {
  const [events, setEvents] = useState<PlaybackDiagnosticEvent[]>([]);
  const [summary, setSummary] = useState(playbackDiagnostics.summary());

  const refresh = useCallback(() => {
    setEvents(playbackDiagnostics.snapshot().reverse());
    setSummary(playbackDiagnostics.summary());
  }, []);

  useEffect(() => {
    refresh();
    const timer = setInterval(refresh, 1500);
    return () => clearInterval(timer);
  }, [refresh]);

  const clear = () => {
    playbackDiagnostics.clear();
    refresh();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Playback diagnostics</Text>
      <Text style={styles.subtitle}>In-memory QA events only. Media names and URLs are excluded.</Text>
      <View style={styles.summary}>
        <Metric label="Events" value={summary.total} />
        <Metric label="Warnings" value={summary.warnings} />
        <Metric label="Errors" value={summary.errors} />
      </View>
      <View style={styles.actions}>
        <Pressable accessibilityRole="button" onPress={refresh} style={styles.button}><Text style={styles.buttonText}>Refresh</Text></Pressable>
        <Pressable accessibilityRole="button" onPress={clear} style={[styles.button, styles.clearButton]}><Text style={styles.buttonText}>Clear events</Text></Pressable>
      </View>
      <ScrollView style={styles.list} contentContainerStyle={styles.listContent}>
        {events.length === 0 ? <Text style={styles.empty}>No playback events recorded yet.</Text> : events.map((event) => (
          <View key={event.id} style={styles.event}>
            <View style={styles.eventHeading}>
              <Text style={styles.eventName}>{event.event}</Text>
              <Text style={[styles.level, event.level === 'error' ? styles.error : event.level === 'warning' ? styles.warning : styles.info]}>{event.level.toUpperCase()}</Text>
            </View>
            <Text style={styles.meta}>#{event.id} · {new Date(event.at).toLocaleTimeString()} · {event.engine || 'app'}</Text>
            {event.details ? <Text style={styles.details}>{Object.entries(event.details).map(([key, value]) => `${key}: ${String(value)}`).join(' · ')}</Text> : null}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return <View style={styles.metric}><Text style={styles.metricValue}>{value}</Text><Text style={styles.metricLabel}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  container: { backgroundColor: '#0B1720', borderRadius: 16, padding: 16, gap: 12 },
  title: { color: '#FFFFFF', fontSize: 18, fontWeight: '700' },
  subtitle: { color: '#A9B7C2', fontSize: 12, lineHeight: 18 },
  summary: { flexDirection: 'row', gap: 10 },
  metric: { flex: 1, backgroundColor: '#142833', padding: 12, borderRadius: 10 },
  metricValue: { color: '#34D399', fontSize: 22, fontWeight: '700' },
  metricLabel: { color: '#B7C6D0', fontSize: 11, marginTop: 3 },
  actions: { flexDirection: 'row', gap: 8 },
  button: { backgroundColor: '#0F766E', paddingVertical: 10, paddingHorizontal: 14, borderRadius: 8 },
  clearButton: { backgroundColor: '#334155' },
  buttonText: { color: '#FFFFFF', fontSize: 12, fontWeight: '600' },
  list: { maxHeight: 280 },
  listContent: { gap: 8 },
  empty: { color: '#A9B7C2', paddingVertical: 18, textAlign: 'center' },
  event: { backgroundColor: '#142833', borderRadius: 8, padding: 10, gap: 5 },
  eventHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  eventName: { color: '#FFFFFF', fontSize: 12, fontWeight: '600', flex: 1 },
  level: { fontSize: 9, fontWeight: '800' },
  error: { color: '#F87171' },
  warning: { color: '#FBBF24' },
  info: { color: '#60A5FA' },
  meta: { color: '#91A4B2', fontSize: 10 },
  details: { color: '#D4DEE5', fontSize: 11, lineHeight: 16 },
});
