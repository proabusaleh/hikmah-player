import { Bookmark, Play, Plus, Trash2 } from 'lucide-react-native';
import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { BottomSheet } from '@/components/common/BottomSheet';
import { BorderRadius, Colors, Spacing } from '@/constants/theme';
import { useVideoBookmarksStore } from '@/store/useVideoBookmarksStore';
import { formatTime } from '@/utils/formatters';

interface Props {
  visible: boolean;
  onClose: () => void;
  mediaId: string;
  title: string;
  currentPosition: number;
  onSeek: (position: number) => void;
}

export const VideoBookmarksSheet: React.FC<Props> = ({ visible, onClose, mediaId, title, currentPosition, onSeek }) => {
  const [error, setError] = useState<string | null>(null);
  const load = useVideoBookmarksStore((state) => state.load);
  const add = useVideoBookmarksStore((state) => state.add);
  const remove = useVideoBookmarksStore((state) => state.remove);
  const bookmarks = useVideoBookmarksStore((state) => state.forMedia(mediaId));

  useEffect(() => { if (visible) void load(); }, [visible, load]);

  const addCurrent = async () => {
    setError(null);
    try {
      const added = await add({ mediaId, title, position: currentPosition });
      if (!added) setError('A bookmark already exists near this position.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save bookmark.');
    }
  };

  const removeBookmark = async (id: string) => {
    setError(null);
    try { await remove(id); } catch (e) { setError(e instanceof Error ? e.message : 'Could not remove bookmark.'); }
  };

  return (
    <BottomSheet visible={visible} onClose={onClose} height={560} title="Video Bookmarks">
      <TouchableOpacity style={styles.addButton} onPress={() => void addCurrent()} activeOpacity={0.8}>
        <Plus size={18} color={Colors.white} />
        <Text style={styles.addButtonText}>Bookmark current position · {formatTime(currentPosition)}</Text>
      </TouchableOpacity>
      {error ? <Text accessibilityRole="alert" style={styles.error}>{error}</Text> : null}
      <ScrollView style={styles.list} contentContainerStyle={styles.listContent}>
        {bookmarks.length === 0 ? (
          <View style={styles.empty}>
            <Bookmark size={28} color={Colors.muted} />
            <Text style={styles.emptyTitle}>No bookmarks yet</Text>
            <Text style={styles.emptyText}>Save a moment in this video to return to it later.</Text>
          </View>
        ) : bookmarks.map((bookmark) => (
          <View key={bookmark.id} style={styles.item}>
            <TouchableOpacity style={styles.playButton} onPress={() => { onSeek(bookmark.position); onClose(); }} accessibilityLabel={`Jump to ${formatTime(bookmark.position)}`}>
              <Play size={17} color={Colors.secondary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.itemText} onPress={() => { onSeek(bookmark.position); onClose(); }}>
              <Text style={styles.time}>{formatTime(bookmark.position)}</Text>
              <Text style={styles.caption}>Saved {new Date(bookmark.createdAt).toLocaleDateString()}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.deleteButton} onPress={() => void removeBookmark(bookmark.id)} accessibilityLabel="Delete bookmark">
              <Trash2 size={17} color={Colors.muted} />
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </BottomSheet>
  );
};

const styles = StyleSheet.create({
  addButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: Spacing.sm, backgroundColor: Colors.secondary, borderRadius: BorderRadius.md, padding: Spacing.md, marginBottom: Spacing.md },
  addButtonText: { color: Colors.white, fontSize: 14, fontWeight: '700' },
  error: { color: Colors.danger, fontSize: 12, marginBottom: Spacing.sm },
  list: { flex: 1 },
  listContent: { paddingBottom: Spacing.xl },
  empty: { alignItems: 'center', justifyContent: 'center', paddingVertical: Spacing.xxl, gap: Spacing.sm },
  emptyTitle: { color: Colors.text, fontSize: 16, fontWeight: '700' },
  emptyText: { color: Colors.muted, fontSize: 13, textAlign: 'center', maxWidth: 260 },
  item: { flexDirection: 'row', alignItems: 'center', paddingVertical: Spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: Colors.border, gap: Spacing.sm },
  playButton: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.card },
  itemText: { flex: 1, paddingVertical: Spacing.xs },
  time: { color: Colors.text, fontSize: 15, fontWeight: '700' },
  caption: { color: Colors.muted, fontSize: 11, marginTop: 2 },
  deleteButton: { padding: Spacing.md },
});
