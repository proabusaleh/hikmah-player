import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Captions, Check, Trash2 } from 'lucide-react-native';
import { BorderRadius, Colors, Spacing } from '@/constants/theme';
import { parseExternalSubtitles, type SubtitleCue } from '@/services/video/externalSubtitles';

interface Props {
  mediaId?: string;
  cues: SubtitleCue[];
  onCuesChange: (cues: SubtitleCue[]) => void;
  delayMs: number;
  onDelayChange: (delayMs: number) => void;
  fontSize: number;
  onFontSizeChange: (fontSize: number) => void;
}

const keyFor = (mediaId?: string) => `hikmah.external-subtitles.v1.${mediaId || 'current'}`;

export const ExternalSubtitleSettings: React.FC<Props> = ({ mediaId, cues, onCuesChange, delayMs, onDelayChange, fontSize, onFontSizeChange }) => {
  const [sourceText, setSourceText] = useState('');
  const [message, setMessage] = useState('Paste SRT or WebVTT subtitle text below.');

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(keyFor(mediaId)).then((raw) => {
      if (!active || !raw) return;
      try {
        const saved = JSON.parse(raw) as { sourceText?: string; delayMs?: number; fontSize?: number };
        if (saved.sourceText) {
          setSourceText(saved.sourceText);
          onCuesChange(parseExternalSubtitles(saved.sourceText));
        }
        if (Number.isFinite(saved.delayMs)) onDelayChange(Math.max(-10000, Math.min(10000, saved.delayMs ?? 0)));
        if (Number.isFinite(saved.fontSize)) onFontSizeChange(Math.max(14, Math.min(32, saved.fontSize ?? 20)));
      } catch { setMessage('Saved subtitle settings could not be read. You can paste the subtitle again.'); }
    }).catch(() => setMessage('Subtitle settings could not be loaded.'));
    return () => { active = false; };
  // mediaId intentionally scopes persisted subtitle text to the selected video.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mediaId]);

  const persist = async (nextText: string, nextDelay = delayMs, nextFontSize = fontSize) => {
    try { await AsyncStorage.setItem(keyFor(mediaId), JSON.stringify({ sourceText: nextText, delayMs: nextDelay, fontSize: nextFontSize })); }
    catch { setMessage('Could not save subtitle settings. Check available storage.'); }
  };

  const apply = () => {
    const parsed = parseExternalSubtitles(sourceText);
    if (!parsed.length) { setMessage('No valid SRT/WebVTT cues found. Check the timestamps and format.'); return; }
    onCuesChange(parsed);
    void persist(sourceText);
    setMessage(`Loaded ${parsed.length.toLocaleString()} subtitle cues.`);
  };

  const clear = () => {
    setSourceText(''); onCuesChange([]); setMessage('External subtitles cleared.');
    void AsyncStorage.removeItem(keyFor(mediaId)).catch(() => setMessage('Could not remove saved subtitles.'));
  };

  const adjustDelay = (delta: number) => {
    const next = Math.max(-10000, Math.min(10000, delayMs + delta));
    onDelayChange(next); void persist(sourceText, next);
  };
  const adjustFont = (delta: number) => {
    const next = Math.max(14, Math.min(32, fontSize + delta));
    onFontSizeChange(next); void persist(sourceText, delayMs, next);
  };

  return <View style={styles.container}>
    <View style={styles.heading}><Captions size={18} color={Colors.secondary} /><Text style={styles.title}>External subtitles</Text></View>
    <Text style={styles.help}>Paste subtitle text from a local .srt or .vtt file. File-picker import is not enabled in this build.</Text>
    <TextInput value={sourceText} onChangeText={setSourceText} multiline textAlignVertical="top" autoCapitalize="none" autoCorrect={false} placeholder={'WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nSubtitle text'} placeholderTextColor={Colors.muted} style={styles.input} accessibilityLabel="Subtitle file contents" />
    <View style={styles.actions}>
      <TouchableOpacity accessibilityRole="button" style={styles.primaryButton} onPress={apply}><Check size={16} color="#052E25" /><Text style={styles.primaryText}>Load subtitles</Text></TouchableOpacity>
      <TouchableOpacity accessibilityRole="button" style={styles.secondaryButton} onPress={clear}><Trash2 size={15} color={Colors.text} /><Text style={styles.secondaryText}>Clear</Text></TouchableOpacity>
    </View>
    <Text accessibilityLiveRegion="polite" style={styles.message}>{message}</Text>
    <View style={styles.controlRow}><Text style={styles.controlLabel}>Timing offset</Text><View style={styles.stepper}><TouchableOpacity onPress={() => adjustDelay(-250)} style={styles.step}><Text style={styles.stepText}>−250</Text></TouchableOpacity><Text style={styles.value}>{delayMs} ms</Text><TouchableOpacity onPress={() => adjustDelay(250)} style={styles.step}><Text style={styles.stepText}>+250</Text></TouchableOpacity></View></View>
    <View style={styles.controlRow}><Text style={styles.controlLabel}>Text size</Text><View style={styles.stepper}><TouchableOpacity onPress={() => adjustFont(-2)} style={styles.step}><Text style={styles.stepText}>A−</Text></TouchableOpacity><Text style={styles.value}>{fontSize}</Text><TouchableOpacity onPress={() => adjustFont(2)} style={styles.step}><Text style={styles.stepText}>A+</Text></TouchableOpacity></View></View>
    <Text style={styles.footer}>{cues.length ? `${cues.length.toLocaleString()} cues ready · settings saved for this video` : 'Supported formats: SRT and WebVTT. Subtitle text is stored locally on this device.'}</Text>
  </View>;
};

export const externalSubtitleFontSize = (fontSize: number) => Math.max(14, Math.min(32, fontSize));

const styles = StyleSheet.create({
  container: { gap: Spacing.md, paddingBottom: Spacing.xl },
  heading: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  title: { color: Colors.text, fontSize: 14, fontWeight: '700' },
  help: { color: Colors.muted, fontSize: 12, lineHeight: 18 },
  input: { minHeight: 150, maxHeight: 240, borderRadius: BorderRadius.md, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.card, color: Colors.text, padding: Spacing.md, fontSize: 12, lineHeight: 18 },
  actions: { flexDirection: 'row', gap: Spacing.sm },
  primaryButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: Colors.secondary, borderRadius: BorderRadius.md, paddingHorizontal: Spacing.md, paddingVertical: Spacing.md, flex: 1 },
  primaryText: { color: '#052E25', fontWeight: '800', fontSize: 12 },
  secondaryButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: Colors.card, borderRadius: BorderRadius.md, paddingHorizontal: Spacing.md, borderWidth: 1, borderColor: Colors.border },
  secondaryText: { color: Colors.text, fontSize: 12, fontWeight: '600' },
  message: { color: Colors.secondary, fontSize: 12, lineHeight: 17 },
  controlRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: Spacing.sm },
  controlLabel: { color: Colors.text, fontSize: 12, fontWeight: '600' },
  stepper: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  step: { minWidth: 44, minHeight: 34, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.card, borderRadius: BorderRadius.sm, borderWidth: 1, borderColor: Colors.border },
  stepText: { color: Colors.text, fontSize: 11, fontWeight: '700' },
  value: { minWidth: 48, textAlign: 'center', color: Colors.secondary, fontSize: 12, fontWeight: '700' },
  footer: { color: Colors.muted, fontSize: 11, lineHeight: 16 },
});
