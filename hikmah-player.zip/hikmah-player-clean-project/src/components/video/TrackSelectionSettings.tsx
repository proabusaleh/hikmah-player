import React, { useMemo, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { AudioLines, Captions, CircleOff } from 'lucide-react-native';
import { Colors, Spacing, BorderRadius } from '@/constants/theme';
import { makeTrackOptions, type SelectableTrack } from '@/services/video/trackSelection';

type TrackPlayer = {
  availableAudioTracks?: SelectableTrack[];
  availableSubtitleTracks?: SelectableTrack[];
  audioTrack?: SelectableTrack | null;
  subtitleTrack?: SelectableTrack | null;
  selectAudioTrack?: (track: SelectableTrack | null) => void;
  selectSubtitleTrack?: (track: SelectableTrack | null) => void;
};

interface Props { player: TrackPlayer | null; isWeb: boolean; }

export const TrackSelectionSettings: React.FC<Props> = ({ player, isWeb }) => {
  const [refresh, setRefresh] = useState(0);
  const audioOptions = useMemo(() => makeTrackOptions(player?.availableAudioTracks, 'audio'), [player, refresh]);
  const subtitleOptions = useMemo(() => makeTrackOptions(player?.availableSubtitleTracks, 'subtitle'), [player, refresh]);
  const currentAudio = player?.audioTrack;
  const currentSubtitle = player?.subtitleTrack;

  const selectAudio = (track: SelectableTrack | null) => {
    try { player?.selectAudioTrack?.(track); setRefresh((v) => v + 1); } catch { /* Native engine may reject unsupported tracks. */ }
  };
  const selectSubtitle = (track: SelectableTrack | null) => {
    try { player?.selectSubtitleTrack?.(track); setRefresh((v) => v + 1); } catch { /* Native engine may reject unsupported tracks. */ }
  };

  if (isWeb || !player) {
    return <View style={styles.notice}><Text style={styles.noticeTitle}>Track selection unavailable</Text><Text style={styles.noticeText}>Audio and subtitle selection currently requires the native video player. Web support depends on the browser and media source.</Text></View>;
  }

  return <View style={styles.container}>
    <View style={styles.sectionHeader}><AudioLines size={18} color={Colors.secondary} /><Text style={styles.sectionTitle}>Audio track</Text></View>
    {audioOptions.length === 1 ? <Text style={styles.muted}>No alternate audio tracks were reported by this video.</Text> : audioOptions.map((option) => {
      const selected = option.track ? currentAudio === option.track || (currentAudio?.id != null && currentAudio.id === option.track.id) : !currentAudio;
      return <TouchableOpacity key={option.key} accessibilityRole="button" accessibilityState={{ selected }} style={[styles.option, selected && styles.optionSelected]} onPress={() => selectAudio(option.track)}><Text style={[styles.optionText, selected && styles.optionTextSelected]}>{option.label}</Text><Text style={styles.check}>{selected ? '✓' : ''}</Text></TouchableOpacity>;
    })}
    <View style={styles.divider} />
    <View style={styles.sectionHeader}><Captions size={18} color={Colors.secondary} /><Text style={styles.sectionTitle}>Subtitles</Text></View>
    {subtitleOptions.length === 1 ? <View style={styles.notice}><CircleOff size={16} color={Colors.muted} /><Text style={styles.noticeText}>No embedded subtitle tracks were reported. External subtitle-file loading is not included in this phase.</Text></View> : subtitleOptions.map((option) => {
      const selected = option.track ? currentSubtitle === option.track || (currentSubtitle?.id != null && currentSubtitle.id === option.track.id) : !currentSubtitle;
      return <TouchableOpacity key={option.key} accessibilityRole="button" accessibilityState={{ selected }} style={[styles.option, selected && styles.optionSelected]} onPress={() => selectSubtitle(option.track)}><Text style={[styles.optionText, selected && styles.optionTextSelected]}>{option.label}</Text><Text style={styles.check}>{selected ? '✓' : ''}</Text></TouchableOpacity>;
    })}
    <Text style={styles.footer}>Available tracks are supplied by the video file and device decoder. Some formats expose no selectable tracks.</Text>
  </View>;
};

const styles = StyleSheet.create({
  container: { paddingBottom: Spacing.lg },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, marginBottom: Spacing.md },
  sectionTitle: { color: Colors.text, fontSize: 14, fontWeight: '700' },
  option: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 44, paddingHorizontal: Spacing.md, marginBottom: Spacing.xs, borderRadius: BorderRadius.md, borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.card },
  optionSelected: { borderColor: Colors.secondary, backgroundColor: 'rgba(16,185,129,0.12)' },
  optionText: { color: Colors.text, fontSize: 13, flex: 1 },
  optionTextSelected: { color: Colors.secondary, fontWeight: '700' },
  check: { color: Colors.secondary, fontWeight: '800', paddingLeft: Spacing.sm },
  muted: { color: Colors.muted, fontSize: 12, lineHeight: 18 },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: Spacing.xl },
  notice: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.sm, padding: Spacing.md, borderRadius: BorderRadius.md, backgroundColor: Colors.card },
  noticeTitle: { color: Colors.text, fontSize: 13, fontWeight: '700', marginBottom: 4 },
  noticeText: { color: Colors.muted, fontSize: 12, lineHeight: 18, flex: 1 },
  footer: { color: Colors.muted, fontSize: 11, lineHeight: 16, marginTop: Spacing.lg },
});
