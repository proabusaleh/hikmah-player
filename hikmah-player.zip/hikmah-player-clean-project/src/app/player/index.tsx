import { BlurView } from 'expo-blur';
import Slider from '@react-native-community/slider';
import { useRouter } from 'expo-router';
import {
    ChevronDown,
    Heart,
    ListMusic,
    MoreHorizontal,
    Music,
    Repeat,
    Repeat1,
    Share2,
    Shuffle,
    Sparkles,
    Timer,
    Volume2,
    VolumeX,
    ChevronUp,
    Trash2,
    ListStart,
    ArrowRight,
} from 'lucide-react-native';
import { useEffect, useMemo, useState } from 'react';
import {
    Animated,
    FlatList,
    Image,
    PanResponder,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';

import { AudioCard } from '@/components/cards/AudioCard';
import { BottomSheet } from '@/components/common/BottomSheet';
import { HikmahIconButton } from '@/components/common/HikmahIconButton';
import { PlayerControls } from '@/components/player/PlayerControls';
import { ProgressBar } from '@/components/player/ProgressBar';
import { SmartPlaybackOverlay } from '@/components/player/SmartPlaybackOverlay';
import { SmartQueueSheet } from '@/components/player/SmartQueueSheet';
import { BorderRadius, Colors, Spacing, Typography } from '@/constants/theme';
import { useAudioPlayback } from '@/hooks/useAudioPlayback';
import { useSleepTimer } from '@/hooks/useSleepTimer';
import { SmartQueueItem } from '@/types/smartPlayback';
import { usePlayerStore } from '@/store/usePlayerStore';

const SPEED_OPTIONS = [0.5, 0.75, 0.9, 1.0, 1.1, 1.25, 1.5, 1.75, 2.0];
const SLEEP_OPTIONS = [5, 10, 15, 20, 30, 45, 60, 90, 120];

export default function AudioPlayerScreen() {
  const router = useRouter();
  const {
    currentTrack,
    status,
    position,
    duration,
    playbackSpeed,
    volume,
    isMuted,
    queue,
    currentIndex,
    isShuffled,
    repeatMode,
    togglePlayPause,
    seekTo,
    seekRelative,
    skipNext,
    skipPrevious,
    toggleShuffle,
    cycleRepeatMode,
    setPlaybackSpeed,
    setVolume,
    toggleMute,
    playTrackAtIndex,
    setQueue,
    playMedia,
  } = useAudioPlayback();

  const { isActive: isSleepActive, formattedRemaining, startTimer, cancelTimer } = useSleepTimer();
  const { removeFromQueue, moveInQueue, clearQueue, playNextInQueue } = usePlayerStore();

  const [showQueue, setShowQueue] = useState(false);
  const [showSpeed, setShowSpeed] = useState(false);
  const [showSleep, setShowSleep] = useState(false);
  const [showSmartQueue, setShowSmartQueue] = useState(false);

  // Entrance animation + draggable artwork (fling sideways for prev/next).
  const [enterAnim] = useState(() => new Animated.Value(0));
  const [artX] = useState(() => new Animated.Value(0));

  useEffect(() => {
    Animated.timing(enterAnim, {
      toValue: 1,
      duration: 450,
      useNativeDriver: true,
    }).start();
  }, [enterAnim]);

  useEffect(() => {
    artX.setValue(0);
  }, [currentTrack?.id, artX]);

  const artPanResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        onMoveShouldSetPanResponder: (_, gestureState) =>
          Math.abs(gestureState.dx) > 20 && Math.abs(gestureState.dx) > Math.abs(gestureState.dy),
        onPanResponderMove: (_, gestureState) => {
          artX.setValue(gestureState.dx);
        },
        onPanResponderRelease: (_, gestureState) => {
          if (gestureState.dx < -80) {
            skipNext();
          } else if (gestureState.dx > 80) {
            skipPrevious();
          }
          Animated.spring(artX, {
            toValue: 0,
            tension: 300,
            friction: 30,
            useNativeDriver: true,
          }).start();
        },
        onPanResponderTerminate: () => {
          Animated.spring(artX, {
            toValue: 0,
            tension: 300,
            friction: 30,
            useNativeDriver: true,
          }).start();
        },
      }),
    [artX, skipNext, skipPrevious]
  );

  const handleRelativeSeek = (seconds: number) => {
    seekRelative(seconds);
  };

  const handleSmartQueuePlay = (item: SmartQueueItem) => {
    setQueue([item.media], 0);
    playMedia(item.media);
    setShowSmartQueue(false);
  };

  const RepeatIcon = repeatMode === 'one' ? Repeat1 : Repeat;
  const repeatColor = repeatMode === 'off' ? Colors.dim : Colors.secondary;

  return (
    <View style={styles.container}>
      {currentTrack?.thumbnailUrl ? (
        <Image source={{ uri: currentTrack.thumbnailUrl }} style={StyleSheet.absoluteFill} />
      ) : (
        <View style={[StyleSheet.absoluteFill, styles.bgFallback]} />
      )}
      <BlurView intensity={72} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, styles.scrim]} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.headerBtn} activeOpacity={0.8}>
          <ChevronDown size={28} color={Colors.text} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerLabel}>NOW PLAYING</Text>
          <Text numberOfLines={1} style={styles.headerSource}>
            {currentTrack?.type === 'audio' ? '🎵 Audio' : '🎬 Video'} • Queue ({queue.length})
          </Text>
        </View>
        <TouchableOpacity style={styles.headerBtn} activeOpacity={0.8}>
          <MoreHorizontal size={24} color={Colors.muted} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scrollContent}
        contentContainerStyle={styles.scrollInner}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View
          style={[
            styles.artworkSection,
            {
              opacity: enterAnim,
              transform: [
                {
                  translateY: enterAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [28, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <Animated.View style={[styles.artworkCard, { transform: [{ translateX: artX }] }]} {...artPanResponder.panHandlers}>
            {currentTrack?.thumbnailUrl ? (
              <Image source={{ uri: currentTrack.thumbnailUrl }} style={styles.artworkImage} />
            ) : (
              <View style={styles.artworkFallback}>
                <Music size={84} color={Colors.secondary} />
              </View>
            )}
          </Animated.View>
          <Text numberOfLines={1} style={styles.trackTitle}>
            {currentTrack?.title ?? 'No track'}
          </Text>
          <Text numberOfLines={1} style={styles.trackArtist}>
            {currentTrack?.artistOrSpeaker || 'Hikmah Audio'}
          </Text>
          <Text style={styles.swipeHint}>Swipe artwork to change track</Text>
        </Animated.View>

        <View style={styles.actionRow}>
          <HikmahIconButton icon={<Heart size={20} color={Colors.muted} />} onPress={() => {}} size="sm" />
          <HikmahIconButton icon={<Share2 size={20} color={Colors.muted} />} onPress={() => {}} size="sm" />
          <HikmahIconButton
            icon={
              <View style={styles.timerIconWrap}>
                <Timer size={20} color={isSleepActive ? Colors.warning : Colors.muted} />
                {isSleepActive && <Text style={styles.timerBadge}>{formattedRemaining}</Text>}
              </View>
            }
            onPress={() => setShowSleep(true)}
            size="sm"
            testID="sleep-button"
            accessibilityLabel="Sleep timer"
          />
          <HikmahIconButton
            icon={<Text style={[styles.speedIcon, playbackSpeed !== 1 && styles.speedIconActive]}>{playbackSpeed}x</Text>}
            onPress={() => setShowSpeed(true)}
            size="sm"
            testID="speed-button"
            accessibilityLabel="Playback speed"
          />
        </View>

        <BlurView intensity={36} tint="dark" style={styles.controlCard}>
          <ProgressBar position={position} duration={duration} onSeek={seekTo} />
          <PlayerControls
            status={status}
            onTogglePlayPause={togglePlayPause}
            onSkipNext={skipNext}
            onSkipPrevious={skipPrevious}
            onSeekRelative={handleRelativeSeek}
            size="large"
          />
        </BlurView>

        {(() => {
          const previewIndex = repeatMode === 'one'
            ? currentIndex
            : currentIndex >= 0 && currentIndex + 1 < queue.length
              ? currentIndex + 1
              : repeatMode === 'all' && queue.length > 0
                ? 0
                : -1;
          const previewTrack = previewIndex >= 0 ? queue[previewIndex] : null;
          if (!previewTrack) return null;
          return (
            <View style={styles.nextPreviewSection}>
              <View style={styles.nextPreviewHeading}>
                <Text style={styles.nextPreviewLabel}>UP NEXT</Text>
                <TouchableOpacity
                  accessibilityRole="button"
                  accessibilityLabel="Open playback queue"
                  onPress={() => setShowQueue(true)}
                  style={styles.viewQueueButton}
                  activeOpacity={0.8}
                >
                  <Text style={styles.viewQueueText}>Queue</Text>
                  <ArrowRight size={14} color={Colors.secondary} />
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                accessibilityRole="button"
                accessibilityLabel={`Play next: ${previewTrack.title}`}
                onPress={() => {
                  void playTrackAtIndex(previewIndex);
                }}
                activeOpacity={0.82}
                style={styles.nextPreviewCard}
              >
                {previewTrack.thumbnailUrl ? (
                  <Image source={{ uri: previewTrack.thumbnailUrl }} style={styles.nextPreviewArtwork} />
                ) : (
                  <View style={styles.nextPreviewArtworkFallback}>
                    <Music size={20} color={Colors.secondary} />
                  </View>
                )}
                <View style={styles.nextPreviewMeta}>
                  <Text numberOfLines={1} style={styles.nextPreviewTitle}>{previewTrack.title}</Text>
                  <Text numberOfLines={1} style={styles.nextPreviewArtist}>{previewTrack.artistOrSpeaker || 'Hikmah Audio'}</Text>
                  {previewIndex === currentIndex && repeatMode === 'one' && (
                    <Text style={styles.nextPreviewRepeat}>Repeat current track</Text>
                  )}
                </View>
                <ArrowRight size={18} color={Colors.secondary} />
              </TouchableOpacity>
            </View>
          );
        })()}

        <View style={styles.modeRow}>
          <TouchableOpacity onPress={toggleShuffle} style={styles.modeBtn} activeOpacity={0.8}>
            <Shuffle size={20} color={isShuffled ? Colors.secondary : Colors.dim} />
          </TouchableOpacity>

          <TouchableOpacity onPress={cycleRepeatMode} style={styles.modeBtn} activeOpacity={0.8}>
            <RepeatIcon size={20} color={repeatColor} />
            {repeatMode !== 'off' && <View style={styles.modeDot} />}
          </TouchableOpacity>

          <TouchableOpacity onPress={toggleMute} style={styles.modeBtn} activeOpacity={0.8}>
            {isMuted ? <VolumeX size={20} color={Colors.dim} /> : <Volume2 size={20} color={Colors.text} />}
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setShowQueue(true)} style={styles.modeBtn} activeOpacity={0.8}>
            <ListMusic size={20} color={Colors.text} />
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setShowSmartQueue(true)} style={styles.modeBtn} activeOpacity={0.8}>
            <Sparkles size={20} color={Colors.accent} />
          </TouchableOpacity>
        </View>

        <View style={styles.volumeSection}>
          <VolumeX size={14} color={Colors.dim} />
          <Slider
            style={styles.volumeSlider}
            minimumValue={0}
            maximumValue={1}
            step={0.05}
            value={isMuted ? 0 : volume}
            minimumTrackTintColor={Colors.secondary}
            maximumTrackTintColor={Colors.border}
            thumbTintColor={Colors.accent}
            onValueChange={setVolume}
          />
          <Volume2 size={14} color={Colors.text} />
        </View>
      </ScrollView>

      {/* ── Smart Playback: network/quality chips, skip button, resume, up-next ── */}
      <SmartPlaybackOverlay onSeek={(sec) => void seekTo(sec * 1000)} />

      <SmartQueueSheet
        visible={showSmartQueue}
        onClose={() => setShowSmartQueue(false)}
        onPlayItem={handleSmartQueuePlay}
      />

      <BottomSheet
        visible={showQueue}
        title={`Up Next (${queue.length} tracks)`}
        onClose={() => setShowQueue(false)}
        snapHeight={0.7}
      >
        {queue.length > 0 && (
          <View style={styles.queueToolbar}>
            <View style={styles.queueSummary}>
              <ListMusic size={16} color={Colors.secondary} />
              <Text style={styles.queueSummaryText}>
                {queue.length} tracks · {queue.reduce((total, track) => total + (track.duration || 0), 0) > 0
                  ? `${Math.round(queue.reduce((total, track) => total + (track.duration || 0), 0) / 60)} min total`
                  : 'duration unavailable'}
              </Text>
            </View>
            <TouchableOpacity
              accessibilityRole="button"
              accessibilityLabel="Clear playback queue"
              style={styles.clearQueueButton}
              onPress={() => clearQueue()}
              activeOpacity={0.8}
            >
              <Trash2 size={15} color={Colors.danger} />
              <Text style={styles.clearQueueText}>Clear</Text>
            </TouchableOpacity>
          </View>
        )}
        {queue.length === 0 ? (
          <View style={styles.queueEmpty}>
            <ListMusic size={34} color={Colors.dim} />
            <Text style={styles.queueEmptyTitle}>Your queue is empty</Text>
            <Text style={styles.queueEmptyText}>Add tracks from your library to build a listening queue.</Text>
          </View>
        ) : (
          <FlatList
            data={queue}
            keyExtractor={(item, index) => `${item.id}-${index}`}
            extraData={currentIndex}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => (
              <View style={styles.queueRow}>
                <View style={styles.queueTrack}>
                  <AudioCard
                    item={item}
                    index={index}
                    isPlaying={index === currentIndex && status === 'playing'}
                    onPress={() => {
                      void playTrackAtIndex(index);
                      setShowQueue(false);
                    }}
                  />
                </View>
                <View style={styles.queueActions}>
                  <TouchableOpacity
                    accessibilityRole="button"
                    accessibilityLabel={`Move ${item.title} up`}
                    disabled={index === 0}
                    onPress={() => moveInQueue(index, index - 1)}
                    style={styles.queueActionButton}
                  >
                    <ChevronUp size={18} color={index === 0 ? Colors.dim : Colors.text} />
                  </TouchableOpacity>
                  {index !== currentIndex && (
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityLabel={`Play ${item.title} next`}
                      onPress={() => playNextInQueue(index)}
                      style={styles.queueActionButton}
                    >
                      <ListStart size={17} color={Colors.secondary} />
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    accessibilityRole="button"
                    accessibilityLabel={`Move ${item.title} down`}
                    disabled={index === queue.length - 1}
                    onPress={() => moveInQueue(index, index + 1)}
                    style={styles.queueActionButton}
                  >
                    <ChevronDown size={18} color={index === queue.length - 1 ? Colors.dim : Colors.text} />
                  </TouchableOpacity>
                  {index !== currentIndex && (
                    <TouchableOpacity
                      accessibilityRole="button"
                      accessibilityLabel={`Remove ${item.title} from queue`}
                      onPress={() => removeFromQueue(index)}
                      style={styles.queueActionButton}
                    >
                      <Trash2 size={16} color={Colors.danger} />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}
          />
        )}
      </BottomSheet>

      <BottomSheet
        visible={showSpeed}
        title="Playback Speed"
        onClose={() => setShowSpeed(false)}
        snapHeight={0.35}
      >
        <View style={styles.speedGrid}>
          {SPEED_OPTIONS.map((speed) => (
            <TouchableOpacity
              key={speed}
              style={[styles.speedChip, playbackSpeed === speed && styles.speedChipActive]}
              onPress={() => {
                void setPlaybackSpeed(speed);
                setShowSpeed(false);
              }}
              activeOpacity={0.8}
            >
              <Text style={[styles.speedChipText, playbackSpeed === speed && styles.speedChipTextActive]}>
                {speed}x
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </BottomSheet>

      <BottomSheet
        visible={showSleep}
        title="Sleep Timer"
        onClose={() => setShowSleep(false)}
        snapHeight={0.4}
      >
        {isSleepActive ? (
          <View style={styles.sleepActive}>
            <Timer size={40} color={Colors.warning} />
            <Text style={styles.sleepRemaining}>{formattedRemaining}</Text>
            <Text style={styles.sleepLabel}>remaining</Text>
            <TouchableOpacity
              style={styles.cancelTimerBtn}
              onPress={() => {
                cancelTimer();
                setShowSleep(false);
              }}
              activeOpacity={0.8}
            >
              <Text style={styles.cancelTimerText}>Cancel Timer</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.sleepGrid}>
            {SLEEP_OPTIONS.map((minutes) => (
              <TouchableOpacity
                key={minutes}
                style={styles.sleepChip}
                onPress={() => {
                  startTimer(minutes);
                  setShowSleep(false);
                }}
                activeOpacity={0.8}
              >
                <Text style={styles.sleepChipText}>{minutes} min</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </BottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  bgFallback: {
    backgroundColor: '#0B1F16',
  },
  scrim: {
    backgroundColor: 'rgba(2, 6, 23, 0.55)',
  },
  artworkSection: {
    alignItems: 'center',
    marginTop: Spacing.md,
    marginBottom: Spacing.lg,
  },
  artworkCard: {
    width: 280,
    height: 280,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    backgroundColor: Colors.card,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.45,
    shadowRadius: 24,
    elevation: 12,
    marginBottom: Spacing.xl,
  },
  artworkImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  artworkFallback: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
  },
  trackTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: Colors.text,
    textAlign: 'center',
    letterSpacing: -0.3,
    paddingHorizontal: Spacing.lg,
  },
  trackArtist: {
    fontSize: 15,
    color: Colors.muted,
    textAlign: 'center',
    marginTop: 4,
  },
  swipeHint: {
    fontSize: 11,
    color: Colors.dim,
    textAlign: 'center',
    marginTop: 8,
  },
  controlCard: {
    width: '100%',
    marginTop: Spacing.md,
    marginBottom: Spacing.xl,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xxl,
    paddingBottom: Spacing.md,
  },
  headerBtn: {
    padding: Spacing.sm,
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
  },
  headerLabel: {
    ...Typography.caption,
    color: Colors.secondary,
    letterSpacing: 1.5,
  },
  headerSource: {
    ...Typography.bodySmall,
    marginTop: 2,
  },
  scrollContent: {
    flex: 1,
  },
  scrollInner: {
    paddingHorizontal: Spacing.xxl,
    paddingBottom: 40,
  },
  actionRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: Spacing.xxl,
    marginTop: Spacing.xl,
    marginBottom: Spacing.lg,
  },
  timerIconWrap: {
    alignItems: 'center',
  },
  timerBadge: {
    fontSize: 8,
    fontWeight: '800',
    color: Colors.warning,
    marginTop: -2,
  },
  speedIcon: {
    fontSize: 13,
    fontWeight: '800',
    color: Colors.muted,
  },
  speedIconActive: {
    color: Colors.secondary,
  },
  nextPreviewSection: {
    marginTop: Spacing.xs,
    marginBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  nextPreviewHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xs,
  },
  nextPreviewLabel: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.4,
    color: Colors.muted,
  },
  viewQueueButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 4,
    paddingHorizontal: 6,
  },
  viewQueueText: {
    color: Colors.secondary,
    fontSize: 12,
    fontWeight: '700',
  },
  nextPreviewCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    padding: Spacing.sm,
    borderRadius: BorderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },
  nextPreviewArtwork: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.card,
  },
  nextPreviewArtworkFallback: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(16,185,129,0.12)',
  },
  nextPreviewMeta: {
    flex: 1,
    minWidth: 0,
    gap: 3,
  },
  nextPreviewTitle: {
    color: Colors.text,
    fontSize: 13,
    fontWeight: '700',
  },
  nextPreviewArtist: {
    color: Colors.muted,
    fontSize: 11,
  },
  nextPreviewRepeat: {
    color: Colors.secondary,
    fontSize: 10,
    fontWeight: '700',
  },
  modeRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingHorizontal: Spacing.xl,
    marginBottom: Spacing.lg,
  },
  modeBtn: {
    padding: Spacing.sm,
    position: 'relative',
  },
  modeDot: {
    position: 'absolute',
    bottom: 2,
    right: 4,
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: Colors.secondary,
  },
  volumeSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },
  volumeSlider: {
    flex: 1,
    height: 30,
  },
  queueToolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
    paddingHorizontal: Spacing.xs,
  },
  queueSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    flex: 1,
  },
  queueSummaryText: {
    color: Colors.muted,
    fontSize: 12,
    fontWeight: '600',
  },
  clearQueueButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 7,
    paddingHorizontal: 10,
    borderRadius: BorderRadius.full,
    backgroundColor: 'rgba(239, 68, 68, 0.10)',
  },
  clearQueueText: {
    color: Colors.danger,
    fontSize: 12,
    fontWeight: '700',
  },
  queueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  queueTrack: {
    flex: 1,
    minWidth: 0,
  },
  queueActions: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: Spacing.sm,
  },
  queueActionButton: {
    width: 32,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  queueEmpty: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.xxl,
    gap: Spacing.sm,
  },
  queueEmptyTitle: {
    ...Typography.h3,
  },
  queueEmptyText: {
    ...Typography.bodySmall,
    color: Colors.muted,
    textAlign: 'center',
  },
  speedGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    justifyContent: 'center',
  },
  speedChip: {
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.card,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    borderColor: Colors.border,
    minWidth: 70,
    alignItems: 'center',
  },
  speedChipActive: {
    backgroundColor: Colors.secondary,
    borderColor: Colors.secondary,
  },
  speedChipText: {
    fontSize: 15,
    fontWeight: '700',
    color: Colors.text,
  },
  speedChipTextActive: {
    color: Colors.background,
  },
  sleepGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    justifyContent: 'center',
  },
  sleepChip: {
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.lg,
    backgroundColor: Colors.card,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    minWidth: 80,
    alignItems: 'center',
  },
  sleepChipText: {
    fontSize: 15,
    fontWeight: '700',
    color: Colors.text,
  },
  sleepActive: {
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: Spacing.xl,
  },
  sleepRemaining: {
    ...Typography.h1,
    color: Colors.warning,
    fontVariant: ['tabular-nums'],
  },
  sleepLabel: {
    ...Typography.body,
    color: Colors.muted,
  },
  cancelTimerBtn: {
    marginTop: Spacing.lg,
    paddingHorizontal: Spacing.xxl,
    paddingVertical: Spacing.md,
    backgroundColor: 'rgba(239, 68, 68, 0.12)',
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    borderColor: Colors.danger,
  },
  cancelTimerText: {
    fontSize: 14,
    fontWeight: '700',
    color: Colors.danger,
  },
});
