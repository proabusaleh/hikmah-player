import { useRouter } from 'expo-router';
import { ChevronRight, Clock3, Flame, Heart, Sparkles } from 'lucide-react-native';
import React, { useMemo } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { Colors, Spacing, Typography } from '@/constants/theme';
import { useAudioPlayback } from '@/hooks/useAudioPlayback';
import { useLibraryStore } from '@/store/useLibraryStore';
import { getSmartPlaylistItems, SMART_PLAYLISTS, type SmartPlaylistId } from '@/services/library/smartPlaylists';
import type { LocalMediaItem } from '@/types/library';
import type { MediaItem } from '@/types/media';

const ICONS = { 'recently-played': Clock3, 'most-played': Flame, 'recently-added': Sparkles, favorites: Heart };
const ACCENTS: Record<SmartPlaylistId, string> = {
  'recently-played': '#38BDF8',
  'most-played': '#F59E0B',
  'recently-added': '#A78BFA',
  favorites: '#10B981',
};

const toMediaItem = (item: LocalMediaItem): MediaItem => ({
  id: item.id,
  title: item.title,
  url: item.filePath,
  duration: item.duration,
  type: item.mediaType,
  addedAt: item.addedAt,
  thumbnailUrl: item.thumbnail,
});

export default function SmartPlaylistsScreen() {
  const router = useRouter();
  const allMedia = useLibraryStore((state) => state.allMedia);
  const loadLibrary = useLibraryStore((state) => state.loadLibrary);
  const { setQueue, playMedia } = useAudioPlayback();
  React.useEffect(() => { void loadLibrary(); }, [loadLibrary]);

  const smartLists = useMemo(() => SMART_PLAYLISTS.map((definition) => ({
    ...definition,
    items: getSmartPlaylistItems(allMedia, definition.id),
  })), [allMedia]);

  const playList = (id: SmartPlaylistId) => {
    const audioItems = getSmartPlaylistItems(allMedia, id).filter((item) => item.mediaType === 'audio');
    if (!audioItems.length) return;
    const tracks = audioItems.map(toMediaItem);
    setQueue(tracks, 0);
    playMedia(tracks[0]);
    router.push('/player');
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Text style={styles.eyebrow}>MADE FOR YOUR LIBRARY</Text>
      <Text style={styles.title}>Smart Playlists</Text>
      <Text style={styles.subtitle}>Automatically organized from your listening history, favorites and local media.</Text>
      {smartLists.map((list) => {
        const Icon = ICONS[list.id];
        const accent = ACCENTS[list.id];
        return (
          <TouchableOpacity key={list.id} style={styles.card} activeOpacity={0.8} onPress={() => playList(list.id)}>
            <View style={[styles.iconWrap, { backgroundColor: `${accent}20` }]}>
              <Icon size={24} color={accent} />
            </View>
            <View style={styles.cardCopy}>
              <Text style={styles.cardTitle}>{list.title}</Text>
              <Text style={styles.description}>{list.description}</Text>
              <Text style={styles.count}>{list.items.length} {list.items.length === 1 ? 'item' : 'items'}</Text>
            </View>
            <ChevronRight size={20} color={Colors.dim} />
          </TouchableOpacity>
        );
      })}
      <View style={styles.note}>
        <Text style={styles.noteTitle}>Always up to date</Text>
        <Text style={styles.noteText}>These playlists are generated from your library each time the screen opens. They do not create duplicate files or take extra storage.</Text>
      </View>
      <Text style={styles.footer}>Tap a playlist to play its audio items. Video items remain visible in the count but open from your library.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },
  content: { padding: Spacing.lg, paddingBottom: 40, gap: Spacing.md },
  eyebrow: { color: Colors.secondary, fontSize: 11, fontWeight: '800', letterSpacing: 1.5, marginTop: 8 },
  title: { ...Typography.h1, marginTop: -4 },
  subtitle: { color: Colors.muted, fontSize: 14, lineHeight: 21, marginBottom: 8 },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, borderColor: Colors.border, borderWidth: 1, borderRadius: 18, padding: 14, gap: 13 },
  iconWrap: { width: 52, height: 52, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  cardCopy: { flex: 1, gap: 3 },
  cardTitle: { color: Colors.text, fontSize: 16, fontWeight: '700' },
  description: { color: Colors.muted, fontSize: 12 },
  count: { color: Colors.secondary, fontSize: 12, fontWeight: '700', marginTop: 3 },
  note: { marginTop: 8, padding: 16, backgroundColor: Colors.backgroundElement, borderRadius: 16, borderWidth: 1, borderColor: Colors.border, gap: 5 },
  noteTitle: { color: Colors.text, fontSize: 14, fontWeight: '700' },
  noteText: { color: Colors.muted, fontSize: 12, lineHeight: 18 },
  footer: { color: Colors.dim, fontSize: 11, lineHeight: 16, textAlign: 'center', marginTop: 4 },
});
