export type SubtitleCue = { id: string; start: number; end: number; text: string };

function parseTimestamp(value: string): number | null {
  const normalized = value.trim().replace(',', '.');
  const full = normalized.match(/^(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?$/);
  const short = normalized.match(/^(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?$/);
  let hours = 0; let minutes = 0; let seconds = 0; let fractionText = '';
  if (full) {
    hours = Number(full[1]); minutes = Number(full[2]); seconds = Number(full[3]); fractionText = full[4] ?? '';
  } else if (short) {
    minutes = Number(short[1]); seconds = Number(short[2]); fractionText = short[3] ?? '';
  } else return null;
  if (minutes > 59 || seconds > 59) return null;
  const fraction = Number(fractionText.padEnd(3, '0')) / 1000;
  return hours * 3600 + minutes * 60 + seconds + fraction;
}

/** Parse common SRT and WebVTT subtitle text. HTML-like tags are stripped before display. */
export function parseExternalSubtitles(input: string): SubtitleCue[] {
  if (!input.trim() || input.length > 5_000_000) return [];
  const normalized = input.replace(/^\uFEFF/, '').replace(/\r/g, '').trim();
  const blocks = normalized.split(/\n\s*\n/);
  const cues: SubtitleCue[] = [];
  for (const block of blocks) {
    const lines = block.split('\n');
    const timeIndex = lines.findIndex((line) => line.includes('-->'));
    if (timeIndex < 0) continue;
    const [startRaw, endRaw] = lines[timeIndex].split('-->').map((part) => part.trim().split(/\s+/)[0]);
    const start = parseTimestamp(startRaw ?? '');
    const end = parseTimestamp(endRaw ?? '');
    if (start == null || end == null || end <= start) continue;
    const text = lines.slice(timeIndex + 1).join('\n')
      .replace(/<\/?(?:i|b|u|font|c|v|ruby|rt)(?:\s+[^>]*)?>/gi, '')
      .replace(/<[^>]*>/g, '')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
      .trim();
    if (!text) continue;
    cues.push({ id: `cue-${cues.length}-${start}`, start, end, text });
  }
  return cues.sort((a, b) => a.start - b.start).slice(0, 100_000);
}

export function getActiveSubtitle(cues: SubtitleCue[], positionSeconds: number, delayMs = 0): SubtitleCue | null {
  if (!Number.isFinite(positionSeconds)) return null;
  const position = positionSeconds - delayMs / 1000;
  // Binary search the last cue whose start is <= the current position.
  let low = 0; let high = cues.length - 1; let candidate = -1;
  while (low <= high) {
    const mid = (low + high) >> 1;
    if (cues[mid].start <= position) { candidate = mid; low = mid + 1; }
    else high = mid - 1;
  }
  if (candidate < 0) return null;
  const cue = cues[candidate];
  return position < cue.end ? cue : null;
}
