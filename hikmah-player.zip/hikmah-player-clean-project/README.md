# Hikmah Player

An offline-first Islamic media player for Android, iOS and web, built with Expo (SDK 57) and Expo Router.

Hikmah Player plays the audio and video **already on the user's device** — recitations, lectures, nasheeds and sermons. It imports media through the system picker (or a full library scan), keeps a searchable local library, downloads files for offline playback, and tracks progress so you can resume where you stopped. There is no account or app-operated media streaming backend. Network access may still be used for app updates and platform services; downloaded and imported media is intended for local playback.

**Current version:** `1.1.0` · **Android applicationId / iOS bundleId:** `com.hikmah.media`

## Features

- **Local library** — import via the system document/media picker or scan device folders, with favorites, playlists and continue-watching.
- **Modern audio player** — blurred artwork backdrop, glass control card, queue support, sleep timer, swipe artwork to skip tracks.
- **Modern video player** — right-half swipe for volume, left-half swipe for brightness, tap-to-seek with a seek readout, Picture-in-Picture, background playback.
- **Home with media tabs** — Audio / Video / Recent, per-tab counts, a Recent Files rail with real thumbnails, and a branded splash screen.
- **Downloads** — resumable queue with progress notifications, offline playback of downloaded items.
- **Search** — fuzzy local search over titles, reciters and tags.
- **Background playback & notifications** — lock-screen and media controls via `expo-audio` + `expo-notifications`.
- **OTA updates** — release builds silently fetch over-the-air updates, with a manual check in Settings.
- **Platform aware** — native features are guarded so the app runs on web (downloads fall back to browser save).

## Modern feature list

This list separates capabilities described in the current project from ideas for future releases. A feature should only be marked complete after it is verified in the app and on a target device.

### Current product capabilities

- **Offline-first media library** — import local audio/video, browse recent items, search titles and reciters, and organize favorites and playlists.
- **Resume playback** — continue from saved playback progress where supported by the current media workflow.
- **Modern audio controls** — seek, skip, queue, repeat/shuffle controls where available, a sleep timer, and playback-speed presets.
- **Mini-player across tabs** — current track, progress, play/pause and skip controls remain available while browsing tabs; tap the mini-player to open the full player.
- **Video gestures** — brightness/volume gestures and tap-to-seek, plus Picture-in-Picture/background behavior where supported by platform and build.
- **Downloads for offline use** — download queue and progress reporting for supported media sources.
- **Background audio** — native media session/notification controls and playback continuity, subject to device-specific validation.
- **Smart local search** — find local media by title, reciter, or tags.
- **Theming and accessibility foundations** — shared colors, reusable UI, accessibility utilities, and localization infrastructure.
- **Release support** — OTA update workflow, release preflight scripts, device QA checklists, and branded app assets.

### Phase 49 audit status

- Mini-player across tabs: present in source; real-device acceptance testing still required.
- Playback speed presets: present in source (0.5×–2.0×); real-device and queue-progression testing still required.
- Sleep timer: basic duration timer present; fade-out and end-of-track modes remain future work.
- Run `npm run check:features` for a static source-presence audit. This does not replace Jest, lint, a native build, or device QA. See `PHASE_49_MODERN_FEATURE_AUDIT.md` for the checklist.

### Modern features to consider for future releases

These are **roadmap suggestions, not claims that they are implemented**. Prioritize them after validating the existing player on real devices.

| Priority | Feature | Expected value | Suggested acceptance criteria |
|---|---|---|---|
| P1 | **Sleep timer with fade-out** | Better bedtime listening | Timer supports duration/end-of-track options; fade-out is optional and stops playback reliably. |
| P1 | **Queue editing and smart queue** | Easier listening sessions | Reorder/remove tracks, clear queue, add next, and recover queue after app restart. |
| P1 | **Listening history and resume shelf** | Return to recent content | History is searchable, progress is saved safely, and users can clear history. |
| P2 | **Advanced library filters** | Find content faster | Filter by duration, file type, folder, recently added, favorites, and reciter. |
| P2 | **Equalizer and audio presets** | Personalize sound | Show only effects supported by the active platform/device; provide safe reset and bypass controls. |
| P2 | **Lyrics / Arabic text and synchronized transcript** | Follow recitation or lectures | Optional local transcript, adjustable text size, and reliable timestamp synchronization when transcript data exists. |
| P2 | **Bookmarks and listening notes** | Save meaningful moments | Add timestamped bookmarks/notes, edit/delete them, and jump back to a bookmark. |
| P2 | **Home screen widgets and quick actions** | Faster access | Widget/shortcut actions reflect actual playback state and degrade gracefully on unsupported devices. |
| P2 | **Storage manager and cache controls** | Give users control of space | Show downloaded/cache size, remove selected downloads, and confirm destructive actions. |
| P2 | **Accessibility polish** | Make the player easier to use | Screen-reader labels, scalable text, adequate contrast, reduced-motion behavior, and large touch targets are tested. |
| P3 | **Backup / restore settings and playlists** | Preserve personal setup | Export/import a versioned local backup with validation and clear conflict handling. |
| P3 | **Optional cloud sync** | Sync across devices | Only after a privacy review; opt-in accounts, transparent data controls, and documented retention/deletion. |
| P3 | **Android Auto / casting integrations** | Use playback in more environments | Separate native feasibility review and device certification; do not promise support before implementation. |
| P3 | **Home-screen personalization** | Tailor the listening experience | Reorder/hide sections and persist the layout without affecting accessibility. |

### Suggested implementation order

1. Verify core playback, background behavior, media controls, queue recovery, and offline playback on physical Android devices.
2. Run physical-device acceptance tests for mini-player and playback speed; then improve queue editing, history, and sleep-timer behavior.
3. Improve accessibility, library filters, storage controls, and bookmarks.
4. Evaluate platform-dependent features (equalizer, widgets, Android Auto, casting) individually before committing to them.
5. Consider optional sync only after the offline-first experience and privacy model are stable.

## Tech stack

| Area | Choice |
|---|---|
| Framework | Expo SDK 57, React Native 0.86, React 19.2 |
| Routing | Expo Router (file-based, typed routes) |
| State | Zustand (player, library, downloads, settings, search, continue-watching) |
| Lists | `@shopify/flash-list` |
| Audio / Video | `expo-audio`, `expo-video` (+ `expo-video`-free web engine) |
| Storage | `expo-file-system`, `expo-media-library`, AsyncStorage |
| Styling | `StyleSheet` + `lucide-react-native` icons, `expo-blur` / `expo-glass-effect` |
| i18n | `i18next` + `react-i18next` |
| Tests | Jest (`jest-expo`), Detox E2E |

## Project structure

```
src/app/            # Routes (every file is a screen)
  (tabs)/           # Tab navigator: home, library, downloads, favorites, settings
  player/           # Audio and video player screens
  library/          # Playlist detail
  _layout.tsx       # Root stack, startup gate, deferred OTA update check
src/components/     # cards/, common/, player/, video/, search/, ui/, permissions/
src/constants/      # theme (colors, spacing, typography), storage keys
src/hooks/          # theme and platform hooks
src/types/          # shared types
components/         # feature components (search, ui helpers)
hooks/              # playback hooks (useAudioPlayback, useVideoEngine, useSleepTimer, …)
services/           # audio, video, playback, storage, downloads, search, notifications,
                    # cache, i18n, performance, updates
store/              # Zustand stores
utils/              # formatters, accessibility, error handler
__tests__/          # unit, component and integration tests
e2e/                # Detox end-to-end tests
```

Path alias `@/*` resolves to `./src/*` then `./*` (see `tsconfig.json` and the `moduleNameMapper` in `jest.config.js`), so `@/components/...` and `@/services/...` both work.

## Getting started

Requires **Node.js 22.13.0 or newer** and npm. Use the Node version supported by your installed Expo SDK; CI uses Node 22.

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go for a quick UI check, or press `a` / `i` for the Android/iOS targets.

> **Expo Go cannot load this app fully** — it uses native modules (`expo-audio`, `expo-video`, `expo-media-library`, `expo-notifications`, `expo-updates`). For real development you need a development build:
>
> ```bash
> npx expo run:android      # or: npx expo run:ios
> eas build --profile development --platform android
> ```

There is no checked-in `android/` or `ios/` directory — native projects are generated with Continuous Native Generation and native behavior is configured in `app.json` and config plugins. Never edit generated native folders by hand.

## Scripts

| Command | What it does |
|---|---|
| `npm start` | Start the dev server |
| `npm run android` / `npm run ios` | Build and run a native development build |
| `npm run web` | Run on web |
| `npm run lint` | ESLint (`expo lint`) |
| `npx tsc --noEmit` | Type check |
| `npm test` | Full Jest suite |
| `npm run test:unit` | `services` / `store` / `utils` / `hooks` tests only |
| `npm run test:ui` | Component tests |
| `npm run test:integration` | Integration tests |
| `npm run test:coverage` | Coverage report |
| `npm run test:ci` | CI mode with coverage and limited workers |
| `npm run test:e2e` | Detox on an Android emulator |

Run `npx expo-doctor` when diagnosing dependency or config issues and `npx expo install <pkg>` to add packages (never `npm install` a native Expo package directly).

## Permissions

Declared in `app.json`; a runtime permission gate runs on first launch and can redirect to system settings when a permission is permanently denied.

| Permission | Why |
|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | Media playback and network-aware behavior |
| `READ_MEDIA_AUDIO`, `READ_MEDIA_VIDEO`, `READ_MEDIA_VISUAL_USER_SELECTED` | Import audio/video from the device (Android 13+) |
| `READ_EXTERNAL_STORAGE` | Same, on Android 12 and below |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Background audio playback |
| `WAKE_LOCK` | Keep playback alive with the screen off |
| `MODIFY_AUDIO_SETTINGS` | Audio focus handling |
| `POST_NOTIFICATIONS` | Download progress and playback notifications |

## Building and versioning

`eas.json` defines three build profiles:

| Profile | Output | Channel | Notes |
|---|---|---|---|
| `development` | Debug APK | — | `developmentClient`, internal distribution |
| `preview` | APK | `preview` | Internal testing / sideloading |
| `production` | AAB | `production` | `autoIncrement: true`, `EXPO_PUBLIC_ENV=production` |
| `production-apk` | APK | `production` | Extends `production`; same env and channel, sideloadable release APK |

```bash
npx eas-cli build --platform android --profile production-apk   # release APK
npx eas-cli build --platform android --profile production       # Play Store AAB
```

Version numbers:

- `version` in `app.json` is the only number you edit by hand. It is the user-facing version **and** the runtime version (`runtimeVersion.policy: "appVersion"`).
- `versionCode` (Android) and `buildNumber` (iOS) live on the EAS server (`cli.appVersionSource: "remote"`) and increment automatically on `production`/`production-apk` builds. The values in `app.json` are ignored.
- `package.json` mirrors the version for npm tooling; keep it in sync.

Bump `version` only when you ship native changes. JS-only changes go out as an OTA update.

## Over-the-air updates

```bash
npx eas-cli update --channel preview   --message "Fix playback resume"
npx eas-cli update --channel production --message "v1.1.1 hotfix"
```

- Channels: `preview` and `production` (created automatically on first build).
- An update only reaches installs whose **runtime version** matches the update's, so a `1.1.1` update never reaches a `1.0.1` install.
- In release builds the app checks for updates ~8s after launch and downloads in the background; the new bundle is applied on the next restart. Settings has an auto-update toggle plus a manual "Check for updates" action that can download and restart.
- Emulators and dev-client debug builds do not apply OTA updates; test them on a real device.

## Testing

```bash
npm test                 # all suites
npm run test:unit        # fast, no UI rendering
npm run test:ci          # what CI runs
```

Tests live in `__tests__/` and are split into `services`, `store`, `utils`, `hooks`, `components`, and `integration`. Detox E2E specs live in `e2e/` (see `e2e/DEVICE_MATRIX.md` for the supported device matrix).

## Releases

- Tag a release and attach the sideloadable APK, e.g. `v1.1.0` built with the `production-apk` profile.
- Store submission (AAB) uses `eas submit --profile production` with `google-play-service-account.json` at the repo root. See `DEPLOYMENT_CHECKLIST.md` for the full Play Store checklist. Review `PRIVACY_POLICY.md` and replace its contact placeholder before publishing a public policy URL.

## License

Private project. All rights reserved.

## Custom branded artwork (Phase 45)
Hikmah Player custom artwork is stored in `assets/icons/icon.png` and `assets/images/`. The generated banner and portrait splash concept assets are `hikmah-splash-banner.png` and `hikmah-splash-screen.png`. See `PHASE_45_CUSTOM_BRANDED_ASSETS.md` for details and asset usage notes.


## Phase 46 — Separate branded assets

Hikmah Player now includes individually generated brand assets (app/adaptive/notification icons, splash artwork, onboarding illustrations, and tab icons). See `PHASE_46_SEPARATE_BRANDED_ASSETS_INTEGRATION.md` for the file map and verification steps.


## Clean project guide (Phase 47)

This ZIP is the cleaned source project, not a prebuilt Android APK. It intentionally excludes installed dependencies (`node_modules`) and generated native build output. Install dependencies after extracting it.

### 1. Requirements

- Node.js 22.13.0 or newer (Node 22 is used in CI)
- npm
- Android Studio + Android SDK for local Android builds, or an EAS account for cloud builds
- Git (recommended)

### 2. Install and start

From the extracted project root:

```bash
npm ci
npm run check:release
npm run check:rc
npx expo start
```

For native features such as audio/video playback, notifications, media library access and OTA updates, use a development build rather than relying on Expo Go:

```bash
npx expo run:android
# or build a development APK in EAS
npx eas-cli@latest build --platform android --profile development
```

### 3. Build Android packages

```bash
# Internal testing / installable APK
npx eas-cli@latest build --platform android --profile preview

# Play Store Android App Bundle
npx eas-cli@latest build --platform android --profile production

# Release APK, if configured in eas.json
npx eas-cli@latest build --platform android --profile production-apk
```

Review `eas.json` and `DEPLOYMENT_CHECKLIST.md` before publishing. Do not commit signing keys, service-account JSON, `.env` files, or other credentials.

### 4. Tests and quality checks

```bash
npm test
npm run test:unit
npm run test:ui
npm run test:integration
npm run test:playback
npm run lint
npx tsc --noEmit
npx expo-doctor
```

The static checks (`check:release` and `check:rc`) do not replace Jest, lint, type checking, an EAS build, or physical-device testing. Record hands-on results using `PHASE_42_DEVICE_QA_CHECKLIST.md` and the Phase 44 device validation guide. A build or test should only be reported as passed after it has actually run successfully.

### 5. Branded assets

| Purpose | File |
|---|---|
| Main app icon | `assets/icons/icon.png` |
| Android adaptive foreground | `assets/images/android-icon-foreground.png` |
| Android adaptive background | `assets/images/android-icon-background.png` |
| Android monochrome icon | `assets/images/android-icon-monochrome.png` |
| Notification icon | `assets/images/notification-icon.png` |
| Portrait splash artwork | `assets/images/hikmah-splash-screen.png` |
| Wide splash/marketing banner | `assets/images/hikmah-splash-banner.png` |
| Onboarding — listen | `assets/images/onboarding-listen.png` |
| Onboarding — library | `assets/images/onboarding-library.png` |
| Onboarding — offline | `assets/images/onboarding-offline.png` |
| Home / Explore artwork | `assets/images/tabIcons/` |

Check `app.json` for the exact asset paths used by Expo. Artwork files being present does not by itself mean every image is wired into a screen; verify references in code before removing or replacing assets. Some Expo branding/support images may remain where the app or tooling still references them.

### 6. Clean project contents

- Application source, configuration, scripts and tests are retained.
- Historical phase notes are grouped under `docs/phase-history/` where present; current setup and release guidance stays at the repository root.
- `node_modules`, generated build outputs and local secrets are not included. Run `npm ci` to recreate dependencies.
- Keep `package-lock.json` committed and use `npm ci` for reproducible installs.

### Phase 47 notes

This phase updates the project README for the cleaned project layout, branded asset map, install commands, quality checks and Android release workflow. Android build, Jest, lint, TypeScript, Expo Doctor and physical-device QA must be run separately in the target environment before declaring the release ready.
