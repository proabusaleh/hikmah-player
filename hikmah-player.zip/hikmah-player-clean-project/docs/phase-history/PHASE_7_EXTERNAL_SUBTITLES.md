# Phase 7 — External Subtitle Support

## Implemented
- Parses common SRT and WebVTT text into normalized cues.
- Displays the active cue over the video based on playback position.
- Supports subtitle delay adjustment from -10,000 ms to +10,000 ms in 250 ms steps.
- Supports readable text size from 14 to 32 px.
- Saves subtitle text and display preferences locally, scoped by media ID.
- Includes parser/active-cue tests and rejects empty/oversized input.

## Current limitations
- This phase uses pasted SRT/WebVTT text in the Tracks settings panel. A native file picker and automatic sidecar discovery are not included because the current dependency set does not include a document picker.
- Embedded subtitle selection remains separate and depends on native decoder support.
- Very large subtitle files are capped at 5 MB and 100,000 cues to avoid excessive memory use.
- Subtitle rendering is a React overlay, not a decoder-level subtitle renderer. Styling/line layout may differ from embedded subtitles.

## QA checklist
- [ ] Load a valid SRT with comma milliseconds.
- [ ] Load WebVTT using both `MM:SS.mmm` and `HH:MM:SS.mmm` timestamps.
- [ ] Confirm cue transitions while playing, pausing, seeking and resuming.
- [ ] Adjust offset earlier/later and confirm sync.
- [ ] Change text size and verify it changes the on-screen subtitle.
- [ ] Reopen settings and verify subtitle data persists for the same media ID.
- [ ] Open a different video and verify its subtitle settings are isolated.
- [ ] Test invalid, empty and oversized input.
- [ ] Verify readability in portrait, landscape and fullscreen.
