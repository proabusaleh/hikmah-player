# Hikmah Player — Phase 23: Main Player Store Integration

## What changed
- Added an explicit `playbackEngine` setting to the existing Zustand `usePlayerStore` (`expo-audio` remains the default).
- Routed the store's load/play, pause/resume, stop, seek, next/previous, and play-at-index actions to the foreground service only when that engine is explicitly selected.
- Subscribed the shared store to foreground-service status and synchronized position, duration, status, and current track by media URI.
- Synchronized store queue edits with `ForegroundPlaybackAdapter` while foreground-service mode is active.
- Prevented mixed audio/video queues from being sent to the audio-only foreground service.
- Kept unsupported speed/volume/mute operations explicit instead of silently applying them to the wrong player engine.

## Enable it
```ts
import { usePlayerStore } from '@/store/usePlayerStore';

// Optional: use only on Android builds containing HikmahNativePlayer.
await usePlayerStore.getState().setPlaybackEngine('foreground-service');

// Existing player UI actions now route to the selected engine.
await usePlayerStore.getState().playTrackAtIndex(0);
await usePlayerStore.getState().seekTo(30_000); // milliseconds

// Return to the default expo-audio engine.
await usePlayerStore.getState().setPlaybackEngine('expo-audio');
```

## Important constraints
- `expo-audio` is still the default engine; the native engine is opt-in and Android-only.
- Select the foreground-service engine before starting playback. Switching engines stops/unloads the previous engine; switching does not automatically resume the current track.
- Foreground-service playback currently accepts audio-only queues.
- Playback speed, app volume and mute are not implemented by the foreground-service engine yet; the store reports a recoverable error for those controls.
- The native service status URI must match the queue item's `url` to synchronize `currentTrack` and `currentIndex` from notification actions.
- This phase does not persist the queue across process death and does not add a UI engine toggle. Call `setPlaybackEngine` from a suitable Android settings/feature gate.
- Kotlin/TypeScript compilation, unit tests, Android build and physical-device verification were not available in this environment. Validate native notification actions, app lifecycle and audio focus on a rebuilt Android app before enabling this by default.
