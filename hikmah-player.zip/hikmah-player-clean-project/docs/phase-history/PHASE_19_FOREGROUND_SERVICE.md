# Hikmah Player — Phase 19: Android Foreground Playback Service

## What changed
- Added `HikmahPlaybackService`, declared as a non-exported Android service with `foregroundServiceType="mediaPlayback"`.
- Service creates its own `MediaPlayer`, starts a foreground media notification, and publishes a framework `MediaSession` with title/artist and playback state.
- Added native bridge calls in `services/audio/nativePlayerBridge.ts`:
  - `startNativeForegroundPlayback(uri, title, artist)`
  - `sendNativeForegroundPlaybackCommand('play' | 'pause' | 'seek' | 'stop', positionMs)`
- Required foreground-service permissions are already present in `app.json`.

## Important architecture limitation
This phase is an **opt-in native service playback path** and intentionally owns a separate `MediaPlayer` instance. It does not automatically take over or synchronize the existing `expo-audio` player, queue, progress UI, or playlists. Do not call both player engines for the same track, or audio may overlap. App UI/queue integration is a follow-up phase.

## Use
Call `startNativeForegroundPlayback()` from an Android development/release build while the app is visible. Use `sendNativeForegroundPlaybackCommand()` to control the service player. A custom native module requires a rebuilt native app; Expo Go is not sufficient.

## Validation status
- ZIP archive integrity was checked after packaging.
- Kotlin compilation, TypeScript checks, Android build, notification permission behavior, and physical-device background playback were **not** tested in this environment.
- Android may restrict starting foreground services from the background; initiate playback from a user action while the app is visible. Android 13+ notification behavior also depends on OS permission/settings.
