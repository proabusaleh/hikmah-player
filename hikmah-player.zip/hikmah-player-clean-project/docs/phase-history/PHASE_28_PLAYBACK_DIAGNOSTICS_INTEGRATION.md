# Phase 28 — Playback Diagnostics Integration

## Delivered
- Instrumented the player store for load start/success/failure, play/pause/stop/seek, status transitions, and playback-engine switching.
- Instrumented expo-audio event callbacks and foreground-service start/command/status transitions.
- Added `src/components/player/PlaybackDiagnosticsPanel.tsx`, an optional QA panel with event counts, recent sanitized events, refresh, and clear controls. It is intentionally a reusable component and is not automatically inserted into a production route.
- Added a store regression test that verifies status diagnostics are emitted without track titles or media URLs.

## Privacy and behavior
- The recorder remains bounded and in-memory. Nothing is uploaded or persisted.
- Diagnostic detail keys are filtered by `services/playback/playbackDiagnostics.ts`; do not add URLs, media titles, artist names, file paths, raw error messages, or stack traces to diagnostic details.
- The panel renders only the sanitized diagnostic snapshot. Integrators should expose it only in a developer/QA area if needed.
- Native foreground-service playback remains opt-in and requires a rebuilt native app; this phase does not certify production background playback.

## Validate locally
```bash
npm install
npm test -- --runInBand __tests__/services/playbackDiagnostics.test.ts __tests__/store/usePlayerStore.test.ts
npm test -- --runInBand __tests__/services/foregroundPlaybackAdapter.test.ts
npx tsc --noEmit
```

## Manual QA
1. Open the player and play, pause, seek, and stop a track.
2. In a developer/QA surface, render `PlaybackDiagnosticsPanel` and confirm event counts and transitions update.
3. Trigger a controlled playback failure and confirm the error event is counted without raw error text.
4. Switch to foreground-service mode on a rebuilt Android development build; verify start/command/status events.
5. Clear events and verify the panel is empty; restart the app and confirm events are not persisted.
6. Confirm no event contains media URLs, track titles, artist names, local paths, credentials, or stack traces.

## Limitations
- Jest and TypeScript checks were not run in this packaging environment because dependencies are not installed.
- The panel is reusable but not routed into Settings automatically; product access should be added behind a developer/QA gate.
- Foreground service, notification, lock-screen, interruption, and battery-optimization behavior still require physical-device validation.
