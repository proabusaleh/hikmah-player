# Phase 41 — Playback CI Automation & Coverage Improvements

## Goal
Run playback-focused regression checks automatically on pushes and pull requests, while keeping lint and TypeScript validation visible as a separate required-quality job.

## Changes
- Added `.github/workflows/ci.yml` for push, pull request, and manual runs.
- Added a `quality` job for Expo lint and TypeScript type-checking.
- Added a `playback-regression` job for queue-completion integration tests, playback-engine integration tests, and `TrackCompletionGuard` unit tests.
- Uploads `coverage/lcov.info` as a downloadable artifact when Jest produces it.
- Added `npm run test:playback` to run the focused regression suite locally.
- Uses `npm ci` with the committed lockfile and Node.js 22; no secrets are required.

## Run locally
```bash
npm ci
npm run test:playback -- --coverage --coverageReporters=text --coverageReporters=lcov
npm run lint
npx tsc --noEmit
```

## CI behavior
- Pushes to `main`, `master`, or `develop` trigger both jobs.
- Pull requests and manual workflow dispatches trigger both jobs.
- A failed command fails its job; configure branch protection to require both checks before merging.
- Coverage is retained as an artifact for 14 days when generated.

## QA status
- Workflow and package script reviewed at source level.
- ZIP integrity is validated for this handoff.
- GitHub Actions has not been run from this workspace; Jest, lint, and TypeScript results must be confirmed by CI after pushing the branch.
