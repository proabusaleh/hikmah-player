# Hikmah Player — Phase 22: Queue & Notification Controls Integration

## Added in this phase
- Added Previous/Play-or-Pause/Next actions to the Android foreground playback notification.
- Added MediaSession skip-to-next/previous callbacks in the foreground service.
- Service-originated notification and MediaSession actions are broadcast to the app using a package-scoped broadcast, then forwarded by the existing Expo native module event bridge.
- Extended the native command bridge with `next` and `previous`.
- Added an opt-in queue owned by `ForegroundPlaybackAdapter`: `setQueue(items, startIndex)`, `playTrackAt(index)`, `next()`, and `previous()`.
- Adapter handles foreground-service notification actions and starts the next/previous queued item on the same foreground-service playback engine.
- Service stop events clear adapter active/current-track state.

## Usage
```ts
import { foregroundPlaybackAdapter } from '@/services/audio/foregroundPlaybackAdapter';

foregroundPlaybackAdapter.setQueue(audioItems, 0);
await foregroundPlaybackAdapter.playTrackAt(0);
// Native notification Next/Previous now routes through this adapter queue.
```

## Important boundaries
- This queue is separate from `usePlayerStore`'s existing `expo-audio` queue. It does not silently migrate the app-wide player store. Only provide the queue to this adapter when the foreground-service engine is explicitly selected.
- Do not play the same item through the service and `expo-audio` simultaneously.
- The Android notification/service controls and broadcast bridge require a rebuilt native Android app; they cannot work in Expo Go.
- Kotlin/TypeScript compilation, Android build, and physical-device testing were not available in this environment. Validate notification actions on Android 8+ and check API-specific foreground-service permissions on the target SDK.
