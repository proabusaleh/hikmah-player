# Phase 29 — Playback Settings & Diagnostics Access

## Delivered
- Added a Developer / QA section to the Settings screen in development builds only (`__DEV__`). It does not appear in production builds.
- Embedded the reusable Playback Diagnostics panel in the gated section.
- Added a system-share export for a JSON QA report containing app version, platform, generated timestamp, the sanitized diagnostics summary, and the in-memory sanitized event snapshot.
- Export uses the existing diagnostics sanitizer; it does not intentionally add track titles, artist names, media URLs, file paths, raw error text, credentials, or stack traces.
- Added defensive error feedback if the share sheet cannot be opened.

## Privacy notes
- Events remain in memory and are not uploaded or persisted by this feature.
- Sharing is user initiated and opens the operating system share sheet. The user chooses whether and where to send the report.
- Only use the panel in development builds. The `__DEV__` guard prevents the diagnostic surface from being rendered in production builds.

## Validation
Run locally after installing dependencies:
```bash
npm install
npm test -- --runInBand __tests__/services/playbackDiagnostics.test.ts __tests__/store/usePlayerStore.test.ts
npx tsc --noEmit
npm run lint
```

Manual QA:
1. Open Settings in a development build and confirm Developer / QA appears.
2. Play, pause, seek, and stop media; refresh the panel and inspect the event stream.
3. Tap Export diagnostic report and verify the share sheet opens with JSON text.
4. Confirm the exported report contains no track title, artist, URL, local path, raw error message, or stack trace.
5. Clear events and confirm the panel is empty.
6. Verify the Developer / QA section is absent from a production build.

## Limitations
- Automated Jest, TypeScript, lint, and device checks were not run in the packaging environment because dependencies are not installed.
- Native foreground-service/background playback behavior still needs a rebuilt Android app and physical-device validation.
