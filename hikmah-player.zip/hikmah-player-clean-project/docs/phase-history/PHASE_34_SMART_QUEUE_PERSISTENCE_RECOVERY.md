# Phase 34 — Smart Queue Persistence & Recovery

## Goal
Make queue mutations safer and preserve the user's selected track as queue entries are removed or reordered.

## Implemented
- Clamp invalid queue start indexes and safely handle empty queues.
- Ignore invalid removal indexes rather than silently mutating state.
- Preserve the current track by its stable media ID when an earlier queue row is removed or rows are reordered.
- Remove one matching item from the original-order queue when a queue entry is removed, instead of removing the same numeric index from two potentially differently ordered arrays.
- Add regression tests for out-of-range start indexes, removing an item before the current track, and invalid remove indexes.
- Reuse Phase 33 persisted session format; cold-start restore remains paused and does not auto-play.

## Manual QA
1. Start a queue and select the third track; remove the first track and confirm the third track remains selected.
2. Reorder queue rows around the current track; confirm the selected track does not change.
3. Remove the current track and confirm the next valid row is selected without an out-of-range index.
4. Clear the queue, restart the app, and confirm there is no stale queue restoration after a clean empty-session save.
5. Restore a saved session and confirm playback remains paused until the user explicitly resumes.

## Validation status
- ZIP archive integrity is checked when packaged.
- Jest, TypeScript, lint, and device tests are not claimed as passed unless run in an environment with dependencies and an Android device/emulator.
