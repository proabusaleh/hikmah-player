# Phase 9 — Native Audio Effects Integration

## Included

- Added a local Expo native module for Android using Android's `Equalizer` and `BassBoost` audio effects.
- Added JS capability detection and safe wrapper methods.
- Rejects invalid audio session IDs and invalid equalizer values; no guessed session ID is used.
- Releases native audio effect objects when the module is destroyed or explicitly released.
- Adds validation tests for equalizer presets and bass boost levels.

## Important integration limitation

`expo-audio` does not currently expose a public Android audio session ID in this project. Therefore this phase supplies the native effects module and JS bridge, but the existing player does **not yet automatically apply effects**. A playback engine that exposes its real audio session ID must be connected to `applyNativeAudioEffects()` before the UI can truthfully show effects as active. Never pass `0` or a made-up ID.

Android device support also depends on the device's audio-effects implementation and may conflict with OEM audio processing. iOS and web report unsupported and use the safe fallback.

## Build steps

1. Install dependencies: `npm ci`
2. Generate native Android project: `npx expo prebuild --platform android`
3. Build a development client: `npx expo run:android`
4. Run `npx tsc --noEmit`, `npm run lint`, and `npm test`.
5. Test on a physical Android device with supported audio hardware and a real session ID supplied by the player engine.

Expo Go will not contain this local native module. Rebuild the development client after changing the native module.

## Acceptance criteria

- Unsupported platforms/builds report effects unavailable.
- Invalid session IDs never create native effects.
- Valid sessions apply only within the target playback session.
- Effect instances are released on teardown.
- Failure to create an effect does not crash playback; the UI should report that effects are unavailable.
