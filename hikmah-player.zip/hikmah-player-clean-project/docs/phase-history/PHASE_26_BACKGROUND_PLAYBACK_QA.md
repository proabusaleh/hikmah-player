# Phase 26 — Background Playback QA & Bug Fixes

## Changes
- Hardened foreground queue initialization by rejecting `NaN` and infinite start indexes while clamping finite indexes to the available range.
- Prevented unhandled promise rejections from asynchronous notification Next/Previous actions.
- Guarded the player store against stale foreground-status callbacks after the user switches engines.
- Normalized non-finite/negative native position and duration values before writing them to Zustand.
- Cleared current-track/progress state when native status indicates inactive, stopped, or ended playback.
- Added focused adapter tests for audio-only validation, queue-index safety, active-player command guards, and native status reads.

## Checks to run
```bash
npm ci
npm run test:integration -- --runInBand
npm run test:unit -- --runInBand
npx tsc --noEmit
npx expo run:android
```

## Device QA
1. Start two audio tracks, then use notification Next/Previous and confirm app title, notification title, and queue index stay aligned.
2. Switch from foreground-service to expo-audio during playback; verify native service stops before expo-audio starts.
3. Stop playback from notification, then return to the app; verify current track and progress clear.
4. Background and lock the device for two minutes; verify audio continues and progress remains monotonic.
5. Trigger audio focus loss and regain (another app/call) and verify the intended pause/resume behavior.
6. Repeat with a network stream that buffers, a local file, a missing URI, and a device reboot/process recreation.

## Verification status
The changes and test cases are included in this phase archive. This environment did not have `node_modules` installed, so Jest, TypeScript compilation, Android compilation, and physical-device checks were not executed. These are not claimed as passing.

## Known limitations
- The service queue and UI queue still rely on URL matching; duplicate URLs may be ambiguous.
- Foreground-service playback is opt-in and remains a separate native playback engine from `expo-audio`.
- Native service lifecycle, notification delivery, and audio-focus behavior require a built Android app and device verification.
