# Phase 17 — MediaSession Contract & Transport Metadata

## Added
- `services/playback/mediaSessionContract.ts`: typed metadata, playback snapshot, transport action contract, and defensive position/speed validation.
- `__tests__/services/mediaSessionContract.test.ts`: unit tests for invalid values, metadata and action filtering.
- Contract designed for the upcoming Android `MediaSession` + foreground service integration.

## Important limitation
This phase does **not** implement a real Android `MediaSession`, `MediaStyle` notification, or foreground service. It defines and tests the data contract needed to connect those pieces without conflating Expo local notifications with system media controls. The native `MediaPlayer` remains opt-in and is not the app's default `expo-audio` playback path.

## Next
1. Implement Android `MediaSession`/Media3 session and media-style notification.
2. Add a foreground playback service and manifest/service type config.
3. Route play/pause/next/previous/seek callbacks to the same player instance.
4. Integrate metadata and playback state from the app UI.
5. Test lock screen, Bluetooth/headset controls, backgrounding, Android 13+ notifications, and task removal on a physical device.

## Validation
ZIP integrity is checked after packaging. Tests and Android build have not been executed in this environment.
