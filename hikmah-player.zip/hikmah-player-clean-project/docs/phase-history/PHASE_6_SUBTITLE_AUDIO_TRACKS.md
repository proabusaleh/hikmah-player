# Phase 6 — Subtitle & Audio Track Selection

## Included
- A Tracks tab in the video settings sheet.
- Native audio-track selection using the tracks exposed by `expo-video`.
- Embedded subtitle-track selection and an Off option.
- Defensive labels when track metadata is incomplete.
- A clear empty state when the source exposes no alternate tracks.
- A web limitation notice; browser-specific track selection is not implemented here.
- Unit tests for track option construction and metadata formatting.

## Important limitations
- Track discovery is media/decoder dependent. MP4 files without multiple audio streams or embedded subtitles will correctly show no alternatives.
- External `.srt`/`.vtt` file loading and subtitle synchronization are not implemented in this phase.
- This implementation uses the `expo-video` track-selection methods available in the project's SDK version. Verify their exact typings after `npm ci` and `npx tsc --noEmit`; native device testing is required.
- If the installed Expo Video version exposes track lists asynchronously, reopen the settings sheet after the video reaches ready state to refresh the visible list.

## Validation
1. Run `npm ci`.
2. Run `npx tsc --noEmit`, `npm run lint`, and `npm test`.
3. Test a file with two audio tracks and verify switching languages.
4. Test a file with embedded subtitles and toggle between Off and each subtitle.
5. Test a file with no alternate tracks and verify the empty-state message.
6. Test web playback and verify that unsupported track selection is explained rather than failing silently.
