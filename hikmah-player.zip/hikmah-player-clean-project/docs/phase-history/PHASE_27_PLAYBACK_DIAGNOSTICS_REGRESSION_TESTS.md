# Phase 27 — Playback Diagnostics & Regression Tests

## Delivered
- Added `services/playback/playbackDiagnostics.ts`: bounded in-memory event buffer, severity counts, monotonic event IDs, defensive snapshots, and clear support.
- Diagnostic details are allowlisted to primitive values, finite numbers, bounded strings, and safe keys. URL/URI, title, artist/speaker, token, credential, path, filename, message, and stack-like fields are excluded to reduce accidental personal/media data capture.
- Added unit tests for rolling capacity, event IDs/timestamps, severity summary, sensitive-field filtering, invalid numeric values, defensive copies, and clear behavior.

## Run locally
```bash
npm install
npm test -- --runInBand __tests__/services/playbackDiagnostics.test.ts
npm test -- --runInBand __tests__/services/foregroundPlaybackAdapter.test.ts
npx tsc --noEmit
```

## Scope and limitations
- Diagnostics are in-memory only; they are not uploaded, persisted, or exposed as a user-facing screen.
- This utility is not yet wired into every playback engine. Instrument engine transitions in a later integration phase after deciding retention and opt-in support-export behavior.
- Tests and TypeScript checks must be run in an environment with dependencies installed. Packaging checks alone do not establish runtime correctness.
