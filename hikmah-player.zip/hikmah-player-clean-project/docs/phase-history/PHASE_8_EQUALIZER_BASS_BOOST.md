# Phase 8 — Equalizer & Bass Boost Preferences

## Included
- Added persistent settings for six equalizer profile preferences: Flat, Bass, Vocal, Treble, Classical, and Rock.
- Added a Bass Boost preference toggle and 0–100 intensity selection.
- Added validation helpers and unit tests for presets and intensity bounds.
- Added settings controls under **Equalizer & Bass Boost**.

## Important implementation limitation
The current app uses `expo-audio`, which does not provide a built-in parametric equalizer or bass-boost DSP API. This phase stores and validates preferences only. The UI explicitly tells users that audio effects are not yet active. Do not advertise these controls as changing the sound output until a compatible native DSP/audio-effects implementation is integrated and tested on Android/iOS.

## Verification
Run:

```bash
npm ci
npx tsc --noEmit
npm run lint
npm test -- --runInBand
```

## Acceptance criteria
- Preferences persist through app restart using the existing settings store.
- Unknown presets fall back to `flat`.
- Bass boost level is always an integer between 0 and 100.
- UI clearly discloses that native DSP is not yet integrated.
- No claim is made that sound is modified before native DSP is available.

## Next
Phase 9 should integrate a maintained native audio-effects implementation (or Android platform equalizer where supported), define capability detection and graceful fallback, then verify output with real devices. Web support may remain unavailable.
