# Phase 43 — Final Bug Fixes & Release Candidate Preflight

## Scope
This phase hardens the handoff to a release candidate without claiming that a native release build or physical-device QA has been completed.

## Changes
- Added `scripts/release-candidate-preflight.js` and `npm run check:rc`.
- The preflight checks package/app version consistency, package scripts, lockfile, Expo app identifiers, background audio configuration, Android playback foreground-service permission, EAS preview/production profiles, required playback tests/docs, and CI workflow presence.
- Added `.gitignore` coverage for dependencies, generated builds, local environment files, signing keys, provisioning profiles, and the Google Play service-account JSON.
- Added this release-candidate handoff guide and the checklist below.

## Run locally
```bash
npm ci
npm run check:release
npm run check:rc
npm run test:playback
npm run lint
npx tsc --noEmit
npx expo-doctor
```

## Create an Android preview candidate
After all checks pass and EAS credentials/project access are configured:
```bash
npx eas-cli@latest build --profile preview --platform android
```
Install the resulting APK on a clean physical device and complete `PHASE_42_DEVICE_QA_CHECKLIST.md`. Do not use a successful static preflight as a substitute for build/test results.

## Release gate
A release candidate is not approved until CI is green, the preview build installs, playback/lock-screen/audio-interruption QA is recorded, privacy/store disclosures are reviewed, and known issues are documented. No production submission was made as part of this phase.
