# Phase 31 — Audio Focus & Interruption Recovery

## What changed

- Connected the existing Android native audio-focus event stream to playback diagnostics.
- Synchronized native playback status events into the player store only while the foreground-service engine is selected, avoiding accidental updates to the separate `expo-audio` player.
- Headphone / audio-route disconnection now updates the JS player status to paused when the native module reports `headphones_disconnected`.
- Transient and permanent audio-focus loss events are reflected as paused in the store; the native Android player remains responsible for actual focus requests and transient resume, so JS does not send duplicate play/pause commands.
- Added subscription cleanup in `playerLifecycle.destroy()` and a best-effort fallback diagnostic when native listeners are unavailable.
- Diagnostics record only event state/reason categories and do not include media URLs, titles, or filenames.

## QA checklist

1. Build and install an Android app that includes `HikmahNativePlayer`.
2. Start audio using the foreground-service engine, then trigger a transient audio-focus loss (for example, an incoming call or another app taking focus). Confirm audio pauses and the JS store changes to paused.
3. End the interruption. Confirm native playback resumes only according to the native focus policy and the status event updates the store.
4. Trigger permanent focus loss; confirm playback stays paused until the user resumes it.
5. Disconnect wired/Bluetooth audio where Android emits `ACTION_AUDIO_BECOMING_NOISY`; confirm playback pauses and is not auto-resumed.
6. Switch to `expo-audio` mode and confirm native status events do not overwrite its state.
7. Initialize/destroy the lifecycle manager in a development build and confirm no duplicate event handling after reinitialization.
8. Review diagnostics for `audio_focus.changed`, `audio_focus.playback_paused`, and `audio_route.disconnected`; verify they contain no media identifiers.

## Limitations

- The native event source is Android-only and exists only in a build containing the local `HikmahNativePlayer` module.
- This phase synchronizes state and diagnostics; it does not claim to implement Bluetooth-device-specific routing controls or certify behavior across all Android vendors.
- Jest, TypeScript, lint, and physical-device tests require installed dependencies and an Android device/build environment. ZIP integrity is checked separately.
