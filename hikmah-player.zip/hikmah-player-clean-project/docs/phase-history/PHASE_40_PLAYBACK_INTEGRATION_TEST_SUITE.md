# Phase 40 — Playback Integration Test Suite

## Scope
- Add integration coverage for queue advancement through the player store's real `nextTrack` action.
- Verify normal next-track loading, Repeat One replay, Repeat All wraparound, normal queue-end state, and empty-queue safety.
- Assert queue-end diagnostics are emitted without retaining stale playback errors.
- Reuse mocked audio/native adapters so these tests do not require a physical device.

## Files changed
- `__tests__/integration/playbackQueueCompletion.test.ts` (new)
- `PHASE_40_PLAYBACK_INTEGRATION_TEST_SUITE.md` (new)
- `REPAIR_NOTES.md`

## QA status
- Source-level review and ZIP integrity validation are performed for this handoff.
- Jest, TypeScript, lint, CI, and physical-device playback are not claimed unless run in an environment with installed dependencies and a device/runtime.

## Run locally
```bash
npm install
npm run test:integration -- --runInBand
```

## Manual verification
1. Play the first item and confirm natural completion advances once.
2. Enable Repeat One and confirm the same item restarts from zero.
3. Enable Repeat All and complete the last item; confirm the first item loads.
4. Disable repeat and complete the last item; confirm playback stops without a stale error.
5. Clear the queue and confirm next-track commands do not start playback.
