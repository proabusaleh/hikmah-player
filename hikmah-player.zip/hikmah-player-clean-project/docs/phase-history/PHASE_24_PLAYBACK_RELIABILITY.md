# Phase 24 — Playback Reliability & Lifecycle Hardening

## Changes
- Prevent stale `expo-audio` events from overwriting foreground-service state after an engine switch.
- Keep `expo-audio` progress polling disabled for native foreground playback, and re-check engine ownership after asynchronous status reads.
- Synchronize shuffled/restored queue order with the foreground adapter and preserve the selected track.
- Validate playback progress values, reject non-finite numbers, and clamp position to duration where duration is known.
- Added focused tests for progress normalization and invalid values.

## Verification
- ZIP archive integrity check is run when packaging.
- Jest/TypeScript/Android compilation and physical-device lifecycle tests are not claimed unless separately run in an environment with dependencies and Android SDK available.

## Device test checklist
1. Start a track, background the app, and confirm playback continues.
2. Use notification Play/Pause/Next/Previous and confirm the main UI follows.
3. Switch engine only after playback is stopped; confirm no duplicate audio.
4. Shuffle/reorder the queue and verify notification navigation matches the UI queue.
5. Trigger an audio interruption, resume, and confirm position/status recover.
6. Stop playback, then reopen the app and verify stale status is not shown.
