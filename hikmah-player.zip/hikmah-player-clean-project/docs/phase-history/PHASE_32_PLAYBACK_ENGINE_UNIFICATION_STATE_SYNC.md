# Phase 32 — Playback Engine Unification & State Synchronization

## What changed

- Added a monotonically increasing foreground-status subscription generation. Delayed callbacks from a previous native session are ignored even if the app quickly switches engines and switches back.
- Added a selected-track URI guard to native status synchronization. A native status snapshot for an old/different URI is ignored rather than overwriting the active track's status, position, or duration.
- Kept the foreground-service adapter's polled native status as the source for its engine's state, including position/duration updates; the `expo-audio` engine remains isolated from native foreground-service status.
- Fixed a lifecycle regression where a device rotation removed native audio-focus and playback-status subscriptions. Those subscriptions now remain active across orientation changes and are removed only during lifecycle destruction.
- Added `foreground.status.ignored` diagnostics for stale URI snapshots. Diagnostic details contain a reason category only, not the URI or media title.

## QA checklist

1. In an Android development build, select foreground-service playback and start an audio track. Confirm position/duration continue to update from native status polling.
2. Switch to `expo-audio` and confirm foreground status callbacks do not change the selected engine's state.
3. Rapidly switch engines away and back; confirm delayed status callbacks from the earlier subscription are ignored.
4. Simulate/observe a native status URI that differs from the selected track URL; confirm state is unchanged and `foreground.status.ignored` is recorded without the URI.
5. Rotate the device while foreground-service playback is active. Confirm audio-focus and native-status subscriptions remain active and are not duplicated.
6. Destroy/reinitialize the lifecycle manager and confirm there is only one active set of listeners.
7. Run `npm test -- --runInBand __tests__/integration/playbackEngineIntegration.test.ts`, `npx tsc --noEmit`, and `npm run lint` after dependencies are installed.

## Limitations

- This phase hardens JavaScript-side synchronization; it does not merge the native Android player and `expo-audio` into a single underlying playback implementation.
- Android behavior still requires a rebuilt native app and device testing. Jest, TypeScript, and lint checks were not run in this workspace because dependencies are not installed.
