# Phase 25 — Playback Integration Testing

## Scope
- Add a Jest integration-contract suite for player-store routing across `expo-audio` and the opt-in Android foreground-service adapter.
- Verify audio-only queue validation, engine isolation, play/pause routing, and cleanup when switching engines.
- Add a reproducible Android manual verification checklist below.

## Run automated checks
```bash
npm ci
npm run test:integration -- --runInBand
npm run test:unit -- --runInBand
npx tsc --noEmit
```

The current working environment used to prepare this phase did not have `node_modules` installed, so these commands have **not** been executed here. The new tests are test cases, not proof that the native module compiles or that device playback works.

## Android device checklist
1. Build a development client/native app (Expo Go cannot load the custom native module): `npx expo run:android`.
2. Start an audio track while the app is visible; confirm audio plays and the notification shows the correct title/artist.
3. Press notification Pause, then Play; confirm UI status and audible playback agree.
4. Press Next and Previous with at least two audio items in the app queue; confirm the same track is shown in the UI and notification.
5. Seek from the app UI and notification; confirm the position is reflected consistently.
6. Background the app and lock the device for at least 2 minutes; confirm playback continues and progress advances.
7. Return to the app; confirm position, duration, status, and current queue index recover without duplicate audio.
8. Interrupt playback with a phone call or another audio app; verify the expected audio-focus behavior and resume policy.
9. Stop playback and dismiss the notification; confirm service and status polling are cleaned up.
10. Switch back to `expo-audio`; confirm the foreground service stops before the other engine starts.
11. Repeat after process recreation and after denying notification permission (Android version dependent); record OS version and logs.

## Acceptance criteria
- Store commands route to only the selected engine.
- Video items are rejected when foreground-service mode is selected.
- Native status subscription is removed when leaving foreground-service mode.
- Device test confirms one audible player instance, matching notification/UI metadata, and stable queue navigation.
- No production release until Kotlin compilation, TypeScript/Jest checks, and physical-device tests pass.

## Known limitations
- Jest mocks validate JS routing only; they do not exercise Android service lifecycle, notification delivery, MediaSession, or native audio decoding.
- Background playback and queue persistence still require on-device verification; do not infer success from passing JS tests alone.
