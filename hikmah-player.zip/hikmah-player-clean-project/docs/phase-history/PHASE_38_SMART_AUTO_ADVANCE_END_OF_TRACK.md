# Phase 38 — Smart Auto-Advance & End-of-Track Handling

## Scope
- Make end-of-track handling idempotent at the audio hook boundary so duplicate native completion signals cannot rapidly skip multiple queue entries.
- Reset the completion guard when a new play event begins, allowing repeat-one and subsequent track completion to work normally.
- Treat reaching the end of a non-repeating queue as a normal stopped state, clear stale playback errors, reset progress, and record a `queue.end` diagnostic event.
- Keep repeat-one, repeat-all, and ordinary next-track navigation in the existing store transport path.

## Files changed
- `hooks/useAudioPlayback.ts`
- `store/usePlayerStore.ts`
- `PHASE_38_SMART_AUTO_ADVANCE_END_OF_TRACK.md`
- `REPAIR_NOTES.md`

## QA status
- Archive integrity is checked after packaging.
- Automated Jest/TypeScript/lint checks and physical Android/iOS playback QA are not claimed; dependencies/device runtime are not available in this packaging pass.

## Manual verification checklist
1. Play a track and allow it to finish; confirm only one next-track transition occurs.
2. Finish the final queue item with repeat off; confirm playback stops without an error.
3. Finish a track with repeat one; confirm the same track restarts from the beginning.
4. Finish the last item with repeat all; confirm playback wraps to the first queue item.
5. Rapidly switch tracks near the end of a song; confirm a late completion event does not skip the newly selected track.
