# Phase 42 — Playback Release Readiness & Final QA

## Goal
Provide a repeatable pre-release checklist and a dependency-free static readiness command, while making it explicit which checks require CI, an Expo/EAS build, or a physical device.

## Added
- `scripts/release-readiness-check.js`: checks core package scripts, lockfile, Expo config, Android/iOS identifiers, background playback configuration, critical icon assets, CI workflow, playback regression tests, privacy policy, and deployment checklist.
- `npm run check:release`: runs the static release gate and exits non-zero if any required static check fails.
- `PHASE_42_DEVICE_QA_CHECKLIST.md`: manual runtime verification matrix for audio focus, lock screen, queue completion, resume, permissions, offline playback, and release build.

## Run
```bash
npm run check:release
npm ci
npm run test:playback
npm run test:coverage
npm run lint
npx tsc --noEmit
npx expo-doctor
```

## Release gate
Do not mark the app release-ready until static checks pass, CI passes, an EAS preview build installs, and device QA is recorded. The static script cannot establish actual playback behavior or store-policy compliance.
