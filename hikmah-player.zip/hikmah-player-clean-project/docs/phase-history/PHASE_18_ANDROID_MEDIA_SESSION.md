# Phase 18 — Android MediaSession & Media-Style Notification

## Implemented in this phase
- Android framework `MediaSession` with metadata and playback state.
- Android media-style notification with Previous, Play/Pause, and Next actions.
- System transport callback events emitted to JavaScript (`mediaSessionAction`).
- Native TypeScript bridge helpers to set title/artist/album, activate the session, update playback state, and subscribe to transport actions.
- Notification channel for Android 8+ and public lock-screen visibility.

## Important limitations
- This phase adds a MediaSession and notification, but **does not add an Android `Service` or call `startForeground()`**. It is not yet a reliable production background-playback solution and the OS may stop it when the app process is killed.
- The app's current `expo-audio` playback is not automatically switched to this native `MediaPlayer`; app UI actions are not automatically wired to the new transport events.
- Native notification permission behavior, lock-screen controls, Bluetooth controls, Kotlin compilation, and physical-device playback have not been verified here.
- Local native modules require an Android development/release build; Expo Go does not include this custom module.

## Build and manual verification
1. `npx expo prebuild --platform android`
2. `npx expo run:android`
3. Load a local audio URI through `loadNativePlayer(uri)`.
4. Set metadata and activate the session with `setNativeMediaMetadata(...)` and `setNativeMediaSessionActive(true)`.
5. Verify notification actions emit `mediaSessionAction` and explicitly route those actions to the same native player instance.
6. Test lock screen, headset/Bluetooth controls, backgrounding, notification permission on Android 13+, and process/task removal on physical devices.

## Next phase
Add a real Android foreground playback service, robust lifecycle ownership, and app-level transport-action routing before claiming production background playback.
