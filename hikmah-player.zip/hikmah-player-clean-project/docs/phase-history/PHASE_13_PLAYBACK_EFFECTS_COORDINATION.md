# Phase 13 — Native Playback + Effects Coordinator

## Added
- `services/audio/nativePlaybackEffectsCoordinator.ts` provides an explicit opt-in coordinator that loads the Phase 12 Android `MediaPlayer`, obtains its real audio session ID, then attempts to apply the configured EQ preset and bass boost.
- Effects failures are returned as `effectsError` rather than being misreported as successful playback effects.
- Cleanup releases effect objects before releasing the player.

## Important scope
This coordinator is not automatically wired into the existing app playback UI or `expo-audio` engine. Call it only from a deliberate Android-native playback path after choosing to use the Phase 12 `MediaPlayer` bridge. The current native player is a proof of concept: synchronous `MediaPlayer.prepare()` and no audio-focus/background-service handling mean it is not production-ready.

## Manual Android validation
1. Build a development client containing both local Expo modules (not Expo Go).
2. Load a valid local audio URI with `loadNativePlaybackWithEffects(uri, config)`.
3. Confirm returned `audioSessionId` is a positive integer.
4. Check `effects.applied` and `effectsError`; OEMs may not support every effect implementation.
5. Play the native player and listen on a physical device; compare Flat and Bass/Vocal presets at low volume.
6. Call `releaseNativePlaybackWithEffects()` and verify no crashes when called again.

## Not verified in this package
TypeScript compilation, Jest, Kotlin compilation, Android device playback, and audible effect output have not been run here. ZIP integrity checks are not a substitute for these tests.
