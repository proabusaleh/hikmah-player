# Phase 36 — Queue Management & Advanced Playback Controls

## Changes
- Added `playNextInQueue(index)` to the player store. It moves a queued item immediately after the currently selected track while preserving the current track by ID.
- Added an accessible “Play … next” action in the player queue sheet.
- Existing queue controls continue to support clearing upcoming items, removing queued tracks, and moving entries up/down.
- Queue updates continue to synchronize with the foreground playback adapter.

## Safety/behavior
- Invalid, non-integer, out-of-range, or current-track indices are ignored.
- The current track remains selected when an upcoming item is moved.
- The current track is not abruptly unloaded by queue reordering.

## Manual QA
1. Add at least three tracks to the queue and start the first.
2. Tap “Play [track] next” on a later item and confirm it appears immediately after the current track.
3. Confirm the currently playing track and position remain unchanged.
4. Try moving the current track, the first item, and the final item; confirm boundary actions are disabled/ignored.
5. Verify behavior in expo-audio and, on a rebuilt Android app, foreground-service mode.

## Validation status
Automated Jest, TypeScript, lint, and physical-device tests were not run in this environment because dependencies/device tooling are unavailable. ZIP integrity is checked separately.
