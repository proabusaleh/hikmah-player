# Phase 37 — Playback UX Polish & Queue Automation

## Delivered

- Added an **Up Next** preview to the main player screen so listeners can see the next item without opening the queue sheet.
- Preview artwork falls back to a music glyph when a track has no thumbnail.
- The preview is actionable: tapping it starts the selected next queue item.
- Added a shortcut from the preview header to open the full queue.
- Preview selection follows the active queue order and repeat behavior: the next queue item is shown normally, repeat-all wraps to the first item, and repeat-one identifies the current track as repeating.
- Added accessibility roles and labels for the new controls.

## Notes

- This is a UI-level preview based on the player store's current queue order; it does not alter queue order or playback state until the listener taps the preview.
- Shuffle is represented by the queue order already maintained by the player store.
- Automated tests and device playback QA were not run in this workspace because dependencies/device runtime are not available here. Verify next-item preview behavior on Android and iOS, including repeat-one, repeat-all, shuffle, empty queue, and a track with no artwork.
