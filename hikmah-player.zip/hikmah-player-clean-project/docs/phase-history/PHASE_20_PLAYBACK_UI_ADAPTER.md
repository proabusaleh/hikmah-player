# Hikmah Player — Phase 20: Playback UI Adapter

## Added
- `services/audio/foregroundPlaybackAdapter.ts` provides a typed, opt-in adapter around the Android foreground playback service.
- Validates platform, URI, service-start result, and command state before play/pause/seek/stop calls.
- Keeps the existing `expo-audio` engine unchanged by default; no automatic backend switching is performed.

## Safe integration contract
1. Select one engine for a given track: `audioService` (expo-audio) OR `foregroundPlaybackAdapter` (native service), never both.
2. When entering native mode, stop/unload the expo-audio player first.
3. Route play/pause/seek/stop to the adapter while native mode is active.
4. On notification next/previous actions, route the event to the store's `nextTrack` / `previousTrack`, then explicitly start the resulting track in the adapter.
5. When leaving native mode, stop the service before returning to expo-audio.

## Limitations
- This is a typed integration adapter, not a completed global player-store migration.
- The native service currently supports start/play/pause/seek/stop; its own playback position/status is not yet bridged to the React Native progress UI.
- Queue-aware notification next/previous actions are not bridged by this adapter yet.
- Do not enable it for normal playback until the store/UI migration and Android device tests are complete.

## Validation
- Source-level review only. TypeScript, Kotlin compilation, Android build, and physical-device behavior were not run in this environment.
