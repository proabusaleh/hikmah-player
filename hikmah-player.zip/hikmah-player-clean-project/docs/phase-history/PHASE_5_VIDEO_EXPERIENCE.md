# Phase 5 — Advanced Video Experience

## Included in this phase

- **Video bookmarks:** save the current playback position, jump back to saved moments, and remove bookmarks.
- **Persistent bookmark storage:** bookmarks are stored locally using AsyncStorage, validated when loaded, and scoped by media ID.
- **Duplicate protection:** prevents saving bookmarks within three seconds of an existing bookmark for the same video.
- **Picture-in-Picture capability:** enables the Expo Video PiP option on native platforms; actual support depends on OS/device behavior and app configuration.
- **Existing controls retained:** fullscreen, seek gestures, volume/brightness gestures, speed settings, and resume prompt.

## Validation checklist

1. Open a video with a stable `id` parameter.
2. Tap the bookmark icon in the bottom controls and save the current position.
3. Save a second position, close the player, reopen the same video, and confirm bookmarks remain.
4. Select a bookmark and confirm playback seeks to that timestamp.
5. Remove a bookmark and confirm it stays removed after reopening the sheet.
6. Try saving at the same position twice and confirm duplicate feedback appears.
7. Test PiP on a supported physical Android/iOS device; web does not expose the native PiP prop through this implementation.
8. Test source URLs that are unavailable and verify the existing player error UI remains usable.

## Notes and limitations

- Subtitle track discovery/selection is not wired in this phase because it must be connected to the actual track metadata exposed by the selected media source and platform. A saved subtitle preference alone does not mean a subtitle track is being rendered.
- Picture-in-Picture depends on OS support, app lifecycle, media source, and native configuration; setting `allowsPictureInPicture` is not a guarantee that every device will enter PiP.
- TypeScript, lint, Jest, and physical-device testing must be run in a dependency-installed environment before release.
