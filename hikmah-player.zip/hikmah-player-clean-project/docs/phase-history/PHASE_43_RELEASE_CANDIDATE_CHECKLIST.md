# Phase 43 — Release Candidate Checklist

## Automated checks
- [ ] `npm ci` completes from the committed lockfile.
- [ ] `npm run check:release` passes.
- [ ] `npm run check:rc` passes.
- [ ] `npm run test:playback` passes.
- [ ] `npm run lint` passes.
- [ ] `npx tsc --noEmit` passes.
- [ ] `npx expo-doctor` reviewed; warnings are documented or resolved.
- [ ] GitHub Actions CI is green for the release commit.

## Build and device
- [ ] EAS preview Android APK builds successfully.
- [ ] APK installs on a clean supported device.
- [ ] Track completion advances once; repeat modes behave as expected.
- [ ] Lock-screen/notification controls work while app is backgrounded.
- [ ] Phone call/audio focus/headphone disconnect recovery tested.
- [ ] Media permissions denied/granted flows tested.
- [ ] No unhandled exceptions in device logs during the test run.

## Handoff
- [ ] Record commit SHA, version, build ID, device model, OS version, tester, date, and test result.
- [ ] Document any known issues and reproduction steps.
- [ ] Confirm privacy policy, app-store disclosures, and signing credentials before submission.
- [ ] Do not submit to production until all release gates are reviewed.
