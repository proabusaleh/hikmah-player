# Phase 15 — Android Audio Focus & Interruption Handling

## Added
- Native player requests Android audio focus before starting playback and reports a denied request as an error.
- Transient focus loss pauses playback and resumes it on focus gain only when playback was active before the interruption.
- Duckable focus loss lowers player volume temporarily; focus gain restores normal volume.
- Permanent focus loss pauses playback and clears auto-resume intent.
- `ACTION_AUDIO_BECOMING_NOISY` pauses playback when a wired/Bluetooth output disconnects, avoiding unexpected speaker playback.
- Explicit focus abandonment and receiver cleanup during release/module destruction.
- JS bridge listeners for `audioFocus` events and a focus-abandon helper.

## Important scope
This is an opt-in native `MediaPlayer` path. The existing app playback UI still uses `expo-audio` unless separately migrated to the native bridge. Focus behavior is Android-only and can vary by device/OEM. This phase does not implement a foreground service or guarantee background playback.

## Manual Android validation
1. Build a development client including the local native module (`npx expo prebuild --platform android`, then `npx expo run:android`). Expo Go does not include this local module.
2. Start playback and verify the focus state event reports `gained`.
3. Start another app that requests audio focus; verify pause/duck behavior and focus-gain recovery.
4. Disconnect headphones while playing; verify playback pauses and does not resume automatically.
5. Release the player twice and check for crashes/leaked receiver warnings.

## Verification status
The ZIP can be integrity-checked independently. TypeScript/Jest and Android/Kotlin compilation and physical-device behavior must still be tested in the project environment; no claim of runtime verification is made here.
